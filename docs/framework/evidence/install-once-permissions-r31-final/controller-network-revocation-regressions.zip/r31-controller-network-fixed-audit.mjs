import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {pathToFileURL} from 'node:url';
const repo='/workspace/scratch/eceef8694f0a/opendesk-browser';
const git=(...args)=>execFileSync('git',args,{cwd:repo,encoding:'utf8'}).trim();
const fileURL=p=>pathToFileURL(repo+'/'+p).href;
const hash=p=>createHash('sha256').update(readFileSync(repo+'/'+p)).digest('hex');
const sourcePaths=['src/platform/host/controller-methods.js','src/platform/host/controller-network-scope.js','tests/framework/k3-controller-authority.test.mjs'];
const sourceHashes=Object.fromEntries(sourcePaths.map(p=>[p,hash(p)]));
const fixturePath='tests/framework/k3-controller-authority.test.mjs';
let prefix=readFileSync(repo+'/'+fixturePath,'utf8').split("test('installed Task v1 cannot")[0]
 .replace('async function fixture()','export async function fixture()')
 .replace('async function installedTaskFixture()','export async function installedTaskFixture()')
 .replace(/from\s+'(\.{1,2}\/[^']+)'/g,(_,relative)=>'from '+JSON.stringify(new URL(relative,fileURL(fixturePath)).href));
const {fixture,installedTaskFixture}=await import('data:text/javascript;base64,'+Buffer.from(prefix).toString('base64'));
const {encodeValue,decodeValue}=await import(fileURL('src/platform/page-port/codec.js'));
const {encodeValue:controlEncode}=await import(fileURL('src/framework/control/value.js'));
const {createRunAuthority}=await import(fileURL('src/platform/host/authority.js'));
const {CONTRACT_VERSION,CONTRACT_HASH}=await import(fileURL('src/platform/protocol.js'));
const origin='https://other.example',pattern=origin+'/*',observations=[];
const originalFetch=globalThis.fetch;
const errorCode=async promise=>{try{await promise;return null;}catch(e){return e.code??e.name;}};
const deny=async(promise,accepted=['E_PERMISSION'])=>{
  const actual=await errorCode(promise);assert.ok(accepted.includes(actual),`Expected ${accepted.join('/')} but got ${actual}`);return actual;
};
async function networkFixture(fetchImpl){
 const f=await fixture();let allowed=true;const counts={request:0,fetch:0};
 f.api.permissions.contains=async({origins})=>origins.every(p=>p!==pattern||allowed);
 f.api.permissions.request=async()=>{counts.request++;throw new Error('Runtime permission request forbidden');};
 globalThis.fetch=async(...args)=>{counts.fetch++;return fetchImpl?fetchImpl(...args):new Response(JSON.stringify({secret:'synthetic private network result'}),{status:200,headers:{'content-type':'application/json'}});};
 const revision=await f.commit(),run=await f.start(revision,undefined,{networkOrigins:[origin]});
 const envelopeFor=run=>({requestId:'network-record-'+run.runId,identity:run.identity,revision:run.revision,target:run.target,
   operation:{kind:'service',method:'AXIOS_GET',args:controlEncode([{url:origin+'/record'}])}});
 const envelope=envelopeFor(run);
 return {...f,revision,run,envelope,envelopeFor,counts,allow:v=>{allowed=v;},
   read:()=>f.authority.controllerOperation({envelope},f.sender),
   snapshot:()=>f.authority.snapshotControllerRun({runId:run.runId},f.sender),
   row:async()=> (await f.rows('runs')).find(r=>r.runId===run.runId),
   remove:()=>f.authority.invalidateControllerTarget({permissionRemoved:true,origins:[pattern]})};
}
try{
 for(const completed of [false,true]){
  const f=await networkFixture(),first=await f.read();
  for(let i=0;i<20;i++)assert.deepEqual(await f.read(),first);
  const effect=(await f.rows('commandJournal')).find(r=>r.envelope?.requestId===f.envelope.requestId);
  const valueWire=encodeValue('synthetic private network result');
  const saved=completed?(await f.finish(f.run,'succeeded',{valueWire})).result:null;
  f.allow(false);const removed=await f.remove();
  assert.equal(removed.length,completed?0:1);assert.equal((await f.row()).resultDeliveryRevoked,true);
  assert.equal((await f.row()).state,completed?'completed':'stopping');
  const replay=await deny(f.read()),finish=await deny(f.finish(f.run,'succeeded',{valueWire}));
  const result=(await f.rows('results')).find(r=>r.resultId===f.run.resultId);
  if(saved)assert.deepEqual(result,saved);else assert.equal(result.state,'stopped');
  f.allow(true);assert.equal((await f.snapshot()).results.length,0);
  await deny(f.read());await deny(f.finish(f.run,'succeeded',{valueWire}));
  assert.deepEqual((await f.rows('commandJournal')).find(r=>r.envelope?.requestId===f.envelope.requestId),effect);
  assert.deepEqual(f.counts,{request:0,fetch:1});
  observations.push({case:completed?'completed result extra Origin revocation':'active run extra Origin revocation',status:'PASS',replay,finish,
    resultState:result.state,originalCompletedResultPreserved:completed,originalServiceReceiptPreserved:true,regrantRevives:false,counts:f.counts});
 }
 for(const path of ['replay','active page operation','finish','completed snapshot']){
  const f=await networkFixture();await f.read();
  const saved=path==='completed snapshot'?(await f.finish(f.run)).result:null;
  const nativeBefore=structuredClone(f.calls);f.allow(false);let rejection;
  if(path==='replay')rejection=await deny(f.read());
  else if(path==='active page operation')rejection=await deny(f.authority.controllerOperation({envelope:{...f.envelope,requestId:'page-after-loss',
    operation:{kind:'packaged',method:'title',args:controlEncode([])}}},f.sender),['E_PERMISSION','E_CANCELLED']);
  else if(path==='finish')rejection=await deny(f.finish(f.run));
  else {assert.equal((await f.snapshot()).results.length,0);rejection='resultDeliveryDenied';}
  assert.equal((await f.row()).resultDeliveryRevoked,true);assert.deepEqual(f.calls,nativeBefore);
  if(saved)assert.deepEqual((await f.rows('results')).find(r=>r.resultId===saved.resultId),saved);
  f.allow(true);await deny(f.read());await deny(f.finish(f.run));assert.equal((await f.snapshot()).results.length,0);
  assert.deepEqual(f.counts,{request:0,fetch:1});
  observations.push({case:'contains=false without onRemoved / '+path,status:'PASS',rejection,durableRevoked:true,regrantRevives:false,
    originalCompletedResultPreserved:!!saved,counts:f.counts});
 }
 {
  const f=await networkFixture();await f.read();const saved=(await f.finish(f.run)).result;
  const transact=f.storage.transaction.bind(f.storage);let release,removal,armed=true;
  const held=new Promise(resolve=>{release=resolve;});
  f.storage.transaction=(names,mode,body)=>{
    if(mode==='readwrite'&&names.includes('runs'))return held.then(()=>transact(names,mode,body));
    const result=transact(names,mode,body);
    if(armed&&mode==='readonly'&&names.includes('results')&&!names.includes('downloadReceipts'))return result.then(value=>{
      armed=false;removal=f.remove();return value;
    });
    return result;
  };
  try{
    const snapshot=await f.snapshot();assert.equal(armed,false);
    assert.equal((await f.row()).resultDeliveryRevoked,undefined);
    assert.equal(snapshot.results.length,0);assert.ok(snapshot.resultDeliveryDenied.includes(f.run.runId));
    assert.deepEqual((await f.rows('results')).find(r=>r.resultId===saved.resultId),saved);
    observations.push({case:'onRemoved after final snapshot IDB read while durable write held',status:'PASS',durableWriteStillPendingAtDelivery:true,
      deliveredResults:0,originalResultPreserved:true,counts:f.counts});
  }finally{release();await removal;}
  assert.equal((await f.row()).resultDeliveryRevoked,true);
 }
 {
  let signal,began;const started=new Promise(resolve=>{began=resolve;});
  const f=await networkFixture((_url,options)=>new Promise((_resolve,reject)=>{
    signal=options.signal;signal.addEventListener('abort',()=>reject(signal.reason),{once:true});began();
  }));
  const pending=f.read();pending.catch(()=>{});await started;await f.remove();assert.equal(signal.aborted,true);
  const firstError=await deny(pending,['E_PERMISSION','E_CANCELLED']);
  const op=(await f.rows('commandJournal')).find(r=>r.envelope?.requestId===f.envelope.requestId);
  assert.equal(op.submissionCount,1);assert.equal(op.deliveryState,'fenced');
  const repeatError=await deny(f.read(),['E_PERMISSION','E_CANCELLED','E_EFFECT_UNKNOWN']);await deny(f.finish(f.run));
  assert.deepEqual(f.counts,{request:0,fetch:1});
  observations.push({case:'in-flight extra Origin revoke',status:'PASS',nativeSignalAborted:true,firstError,repeatError,
    receiptState:op.state,submissionCount:op.submissionCount,counts:f.counts});
 }
 {
  const f=await networkFixture();await f.finish(f.run);await f.authority.retireControllerTarget({runId:f.run.runId},f.sender);await f.remove();
  const run=await f.start(f.revision,undefined,{networkOrigins:[origin]});
  await f.authority.controllerOperation({envelope:f.envelopeFor(run)},f.sender);const saved=(await f.finish(run)).result;
  const row=(await f.rows('runs')).find(r=>r.runId===run.runId);assert.ok(row.nativeNetworkFences.some(x=>x.permissionEpoch>0));
  f.frames.set(2,[{frameId:0,documentId:'new-doc-after-completion',url:'https://a.example/after'}]);
  await f.authority.invalidateControllerTarget({tabId:2,frameId:0,documentId:'new-doc-after-completion'});
  assert.equal((await f.authority.snapshotControllerRun({runId:run.runId},f.sender)).results.length,1);
  const worker=createRunAuthority({storage:f.storage,api:f.api,session:'browser-session',clock:f.clock});
  await worker.recoverControllers();
  assert.equal((await worker.snapshotControllerRun({runId:run.runId},f.sender)).results.length,1);
  const browser=createRunAuthority({storage:f.storage,api:f.api,session:'browser-session-next',clock:f.clock});
  const sender={...f.sender,documentId:'new-browser-tool-doc'};
  await browser.registerHost({hostInstanceId:'new-browser-host',claimedContractVersion:CONTRACT_VERSION,claimedContractHash:CONTRACT_HASH},sender);
  assert.equal((await browser.snapshotControllerRun({runId:run.runId},sender)).results.length,1);
  await browser.invalidateControllerTarget({permissionRemoved:true,origins:[pattern]});
  const workerAfterRemoval=createRunAuthority({storage:f.storage,api:f.api,session:'browser-session-next',clock:f.clock});
  assert.equal((await workerAfterRemoval.snapshotControllerRun({runId:run.runId},sender)).results.length,0);
  assert.deepEqual((await f.rows('results')).find(r=>r.resultId===saved.resultId),saved);
  observations.push({case:'historical result navigation, Worker epoch reset and new browser session',status:'PASS',
    oldNetworkEpoch:row.nativeNetworkFences[0].permissionEpoch,validHistorySurvivesNavigation:true,validHistorySurvivesWorkerReset:true,
    validHistorySurvivesNewSession:true,durableRevocationSurvivesWorkerReset:true,originalResultPreserved:true,counts:f.counts});
 }
 {
  const f=await networkFixture();await f.finish(f.run);const contains=f.api.permissions.contains;
  f.api.permissions.contains=async query=>{if(query.origins.includes(pattern))throw Object.assign(new Error('Synthetic transport failure'),{code:'E_TRANSPORT'});return contains(query);};
  assert.equal((await f.snapshot()).results.length,0);assert.equal((await f.row()).resultDeliveryRevoked,undefined);
  f.api.permissions.contains=contains;assert.equal((await f.snapshot()).results.length,1);
  observations.push({case:'non-permission native failure does not synthesize permanent revocation',status:'PASS',temporaryDeliveryDenied:true,
    durableRevoked:false,validHistoryRecovers:true,counts:f.counts});
 }
 {
  const f=await installedTaskFixture();await deny(f.startTask(f.resolved,{networkOrigins:[origin]}));
  observations.push({case:'installed Task extra Origin injection',status:'PASS',rejection:'E_PERMISSION'});
 }
 for(const path of sourcePaths)assert.equal(hash(path),sourceHashes[path],'Audited source changed while repro was executing');
 console.log(JSON.stringify({audit:'R3.1 Controller network scope fix independent component verification',status:'PASS',
   repositoryHead:git('rev-parse','HEAD'),sourceHashes,
   method:'Current working-tree source and existing real Authority/storage fixture; only Chrome/fetch are doubles. No native Chrome claim.',
   observations},null,2));
}finally{globalThis.fetch=originalFetch;}
