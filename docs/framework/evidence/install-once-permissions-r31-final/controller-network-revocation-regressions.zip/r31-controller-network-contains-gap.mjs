import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
const repo='/workspace/scratch/eceef8694f0a/opendesk-browser';
const ref='7d7a856928c8a32a59f6540a2ad287107b5c595a';
const git=(...args)=>execFileSync('git',args,{cwd:repo,encoding:'utf8'});
const fileURL=p=>pathToFileURL(repo+'/'+p).href;
const fromGit=p=>git('show',ref+':'+p);
const dataURL=s=>'data:text/javascript;base64,'+Buffer.from(s).toString('base64');
function imports(source,path,replacements={}){
  return source.replace(/from\s+'(\.{1,2}\/[^']+)'/g,(_,relative)=>{
    const href=new URL(relative,fileURL(path)).href;
    return 'from '+JSON.stringify(replacements[href]??href);
  });
}
const scopePath='src/platform/host/controller-network-scope.js';
const scope=dataURL(imports(fromGit(scopePath),scopePath));
const methodsPath='src/platform/host/controller-methods.js';
const methods=dataURL(imports(fromGit(methodsPath),methodsPath,{[fileURL(scopePath)]:scope}));
const authorityPath='src/platform/host/authority.js';
const authority=dataURL(imports(fromGit(authorityPath),authorityPath,{[fileURL(methodsPath)]:methods}));
const fixturePath='tests/framework/k3-controller-authority.test.mjs';
let prefix=fromGit(fixturePath).split("test('installed Task v1 cannot")[0];
prefix=prefix.replace('async function fixture()','export async function fixture()')
  .replace('async function installedTaskFixture()','export async function installedTaskFixture()');
const {fixture,installedTaskFixture}=await import(dataURL(imports(prefix,fixturePath,{[fileURL(authorityPath)]:authority})));
const {encodeValue,decodeValue}=await import(fileURL('src/platform/page-port/codec.js'));
const {encodeValue:controlEncode}=await import(fileURL('src/framework/control/value.js'));
const observations=[];
const networkOrigin='https://other.example';
function permissions(f){
  let extraAllowed=true;
  f.api.permissions.contains=async({origins})=>origins.every(o=>!o.startsWith(networkOrigin+'/')||extraAllowed);
  f.api.permissions.request=async()=>{throw new Error('Unexpected runtime permission request');};
  return ()=>{extraAllowed=false;};
}
const originalFetch=globalThis.fetch; let dispatches=0;
globalThis.fetch=async()=>{dispatches++;return new Response(JSON.stringify({secret:'data from explicitly admitted extra Origin'}),{status:200,headers:{'content-type':'application/json'}});};
try {
  const f=await fixture(),revoke=permissions(f),run=await f.start(await f.commit(),undefined,{networkOrigins:[networkOrigin]});
  const envelope={requestId:'cross-site-once',identity:run.identity,revision:run.revision,target:run.target,
    operation:{kind:'service',method:'AXIOS_GET',args:controlEncode([{url:networkOrigin+'/record'}])}};
  const first=await f.authority.controllerOperation({envelope},f.sender);
  revoke(); // Explicit native contains=false, no onRemoved observation yet.
  const replay=await f.authority.controllerOperation({envelope},f.sender);
  assert.deepEqual(replay,first);
  const title=await f.authority.controllerOperation({envelope:{...envelope,requestId:'active-after-missing',
    operation:{kind:'packaged',method:'title',args:controlEncode([])}}},f.sender);
  assert.ok(title.value);
  const settled=await f.finish(run,'succeeded',{valueWire:encodeValue('network result collected before revocation')});
  const snapshot=await f.authority.snapshotControllerRun({runId:run.runId},f.sender);
  assert.equal(snapshot.results.length,1);
  observations.push({case:'contains=false before onRemoved',crossSiteReplayDelivered:true,
    furtherSourcePageOperationDelivered:true,finishState:settled.result.state,
    deliveredResults:snapshot.results.length,
    resultDeliveryRevoked:(await f.rows('runs')).find(r=>r.tag==='controller-run').resultDeliveryRevoked??false});
  assert.equal(dispatches,1);
  console.log(JSON.stringify({sourceRef:ref,baseRef:git('rev-parse','6d1ab8ff').trim(),
    method:'Origin Git source overlay only in memory; real Authority/storage fixture; fake Chrome/fetch, not native proof',
    dispatches,observations},null,2));
} finally {globalThis.fetch=originalFetch;}
