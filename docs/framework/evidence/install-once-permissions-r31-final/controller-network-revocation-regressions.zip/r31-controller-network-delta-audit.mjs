import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
import {readFileSync} from 'node:fs';
import {pathToFileURL} from 'node:url';
const repo='/workspace/scratch/eceef8694f0a/opendesk-browser';
const ref='7d7a856928c8a32a59f6540a2ad287107b5c595a';
const git=(...args)=>execFileSync('git',args,{cwd:repo,encoding:'utf8'});
const fileURL=p=>pathToFileURL(repo+'/'+p).href;
const fromGit=p=>git('show',ref+':'+p);
const dataURL=s=>'data:text/javascript;base64,'+Buffer.from(s).toString('base64');
function imports(source,path,replacements={}){
  return source.replace(/from\s+'(\.{1,2}\/[^']+)'/g,(_,relative)=>{
    const href=new URL(relative,fileURL(path)).href;
    return 'from '+JSON.stringify(replacements[href]??href);
  });
}
const scopePath='src/platform/host/controller-network-scope.js';
const scope=dataURL(imports(fromGit(scopePath),scopePath));
const methodsPath='src/platform/host/controller-methods.js';
const methods=dataURL(imports(fromGit(methodsPath),methodsPath,{[fileURL(scopePath)]:scope}));
const authorityPath='src/platform/host/authority.js';
const authority=dataURL(imports(fromGit(authorityPath),authorityPath,{[fileURL(methodsPath)]:methods}));
const fixturePath='tests/framework/k3-controller-authority.test.mjs';
let prefix=fromGit(fixturePath).split("test('installed Task v1 cannot")[0];
prefix=prefix.replace('async function fixture()','export async function fixture()')
  .replace('async function installedTaskFixture()','export async function installedTaskFixture()');
const {fixture,installedTaskFixture}=await import(dataURL(imports(prefix,fixturePath,{[fileURL(authorityPath)]:authority})));
const {encodeValue,decodeValue}=await import(fileURL('src/platform/page-port/codec.js'));
const {encodeValue:controlEncode}=await import(fileURL('src/framework/control/value.js'));
const observations=[];
const networkOrigin='https://other.example';
function permissions(f){
  let extraAllowed=true;
  f.api.permissions.contains=async({origins})=>origins.every(o=>!o.startsWith(networkOrigin+'/')||extraAllowed);
  f.api.permissions.request=async()=>{throw new Error('Unexpected runtime permission request');};
  return ()=>{extraAllowed=false;};
}
const originalFetch=globalThis.fetch; let dispatches=0;
globalThis.fetch=async()=>{dispatches++;return new Response(JSON.stringify({secret:'data from explicitly admitted extra Origin'}),{status:200,headers:{'content-type':'application/json'}});};
try {
  for(const finishBeforeRemove of [false,true]){
    const f=await fixture(),revoke=permissions(f),run=await f.start(await f.commit(),undefined,{networkOrigins:[networkOrigin]});
    const envelope={requestId:'cross-site-once',identity:run.identity,revision:run.revision,target:run.target,
      operation:{kind:'service',method:'AXIOS_GET',args:controlEncode([{url:networkOrigin+'/record'}])}};
    const answer=await f.authority.controllerOperation({envelope},f.sender);
    assert.ok(answer.value);
    const secret=decodeValue((await f.rows('commandJournal')).find(r=>r.envelope?.requestId==='cross-site-once').valueWire).data.secret;
    if(finishBeforeRemove)await f.finish(run,'succeeded',{valueWire:encodeValue(secret)});
    revoke();
    const invalidated=await f.authority.invalidateControllerTarget({permissionRemoved:true,origins:[networkOrigin+'/*']});
    let replayError;
    try{await f.authority.controllerOperation({envelope},f.sender);}catch(e){replayError=e.code;}
    assert.equal(replayError,'E_PERMISSION');
    let finishState,finishError;
    try{finishState=(await f.finish(run,'succeeded',{valueWire:encodeValue(secret)})).result.state;}catch(e){finishError=e.code;}
    const snapshot=await f.authority.snapshotControllerRun({runId:run.runId},f.sender);
    const persisted=(await f.rows('runs')).find(r=>r.tag==='controller-run');
    observations.push({case:finishBeforeRemove?'completed result then extra Origin removal':'extra Origin removal then finish',
      invalidatedCount:invalidated.length,replayError,finishState,finishError:finishError??null,
      resultDeliveryRevoked:persisted.resultDeliveryRevoked??false,deliveredResults:snapshot.results.length,
      deliveredValue:snapshot.results[0]?decodeValue(snapshot.results[0].outcome.valueWire):null});
    assert.equal(invalidated.length,0,'Reproduces missing network-origin durable invalidation');
    assert.equal(finishState,'completed','Reproduces late/repeated finish escaping new network fence');
    assert.equal(snapshot.results.length,1,'Reproduces unauthorized durable result delivery');
  }
  const task=await installedTaskFixture();
  await assert.rejects(task.startTask(task.resolved,{networkOrigins:[networkOrigin]}),{code:'E_PERMISSION'});
  observations.push({case:'installed Task extra Origin injection',rejected:'E_PERMISSION'});
  assert.equal(dispatches,2);
  console.log(JSON.stringify({sourceRef:ref,baseRef:git('rev-parse','6d1ab8ff').trim(),
    method:'Origin Git source overlay only in memory; unchanged real Authority/storage fixture; fake Chrome/fetch, not native proof',
    dispatches,observations},null,2));
} finally {globalThis.fetch=originalFetch;}
