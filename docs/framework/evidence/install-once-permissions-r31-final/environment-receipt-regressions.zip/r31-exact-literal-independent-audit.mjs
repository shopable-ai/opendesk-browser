import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import {createRequire} from 'node:module';
import {pathToFileURL} from 'node:url';
const root='/workspace/scratch/eceef8694f0a',repo=root+'/opendesk-browser';
const require=createRequire(pathToFileURL(repo+'/package.json'));const {parse,version:acornVersion}=require('acorn');
const digest=x=>createHash('sha256').update(x).digest('hex');
const proofPath=root+'/r31-evidence/exact-literal-budget-equivalence.json';
const proofBytes=readFileSync(proofPath),proof=JSON.parse(proofBytes);
const readGit=(ref,path)=>execFileSync('git',['show',ref+':'+path],{cwd:repo});
const walk=(node,visit,parent=null,key=null)=>{
 if(Array.isArray(node)){for(const child of node)walk(child,visit,parent,key);return;}
 if(!node||typeof node!=='object')return;
 if(node.type)visit(node,parent,key);
 for(const [k,v]of Object.entries(node))if(v&&typeof v==='object')walk(v,visit,node,k);
};
const allowedReferences={
 ArrayExpression:['elements'],BinaryExpression:['left','right'],LogicalExpression:['left','right'],
 ConditionalExpression:['test','consequent','alternate'],CallExpression:['arguments','callee'],NewExpression:['arguments','callee'],
 Property:['value'],VariableDeclarator:['init'],ReturnStatement:['argument'],ThrowStatement:['argument'],
 AssignmentExpression:['right'],AssignmentPattern:['right'],ArrowFunctionExpression:['body'],
 TemplateLiteral:['expressions'],SwitchCase:['test'],UnaryExpression:['argument'],AwaitExpression:['argument'],
 SequenceExpression:['expressions'],SpreadElement:['argument']
};
const reports=[];
for(const spec of proof.files){
 const beforeBytes=readGit(proof.baseCommit,spec.path),afterBytes=readFileSync(repo+'/'+spec.path);
 assert.equal(digest(beforeBytes),spec.beforeSha256);assert.equal(digest(afterBytes),spec.afterSha256);
 const before=parse(beforeBytes.toString(),{ecmaVersion:'latest',sourceType:'module'});
 const after=parse(afterBytes.toString(),{ecmaVersion:'latest',sourceType:'module'});
 const priorIdentifiers=new Set();walk(before,node=>{if(node.type==='Identifier')priorIdentifiers.add(node.name);});
 const names=new Set(Object.keys(spec.bindings));for(const name of names)assert.equal(priorIdentifiers.has(name),false,'Binding existed before: '+name);
 const bindings={},declarationNodes=new Set(),newDeclarationIdentifiers=new Set();let beforeFirstOriginalStatement=true;
 for(const statement of after.body){
   if(statement.type==='ImportDeclaration')continue;
   const additions=statement.type==='VariableDeclaration'?statement.declarations.filter(d=>d.id.type==='Identifier'&&names.has(d.id.name)):[];
   if(additions.length){
     assert.equal(beforeFirstOriginalStatement,true,'Constant must initialize before original top-level statements');
     assert.equal(statement.kind,'const');assert.equal(additions.length,statement.declarations.length,'Cannot remove an original declarator');
     declarationNodes.add(statement);
     for(const d of additions){assert.equal(d.init.type,'Literal');assert.equal(typeof d.init.value,'string');
       assert.equal(Object.hasOwn(bindings,d.id.name),false);bindings[d.id.name]=d.init.value;newDeclarationIdentifiers.add(d.id);}
   }else beforeFirstOriginalStatement=false;
 }
 assert.deepEqual(bindings,spec.bindings);
 let references=0;const referenceContexts={};
 walk(after,(node,parent,key)=>{
   if(node.type!=='Identifier'||!names.has(node.name)||newDeclarationIdentifiers.has(node))return;
   // Reject shadow declarations, export/property renaming, non-computed member names,
   // shorthand properties, writes and all non-value contexts before substitution.
   const computedKey=(parent?.type==='MemberExpression'&&key==='property'&&parent.computed)||
     (parent?.type==='Property'&&key==='key'&&parent.computed);
   assert.ok(computedKey||allowedReferences[parent?.type]?.includes(key),`Non-value use ${node.name} at ${parent?.type}.${key}`);
   if(parent?.type==='Property')assert.equal(parent.shorthand,false);
   references++;const context=parent.type+'.'+key;referenceContexts[context]=(referenceContexts[context]||0)+1;
 });
 assert.equal(references,spec.replacements);
 const normalize=(node,changed)=>{
   if(Array.isArray(node))return node.filter(n=>!changed||!declarationNodes.has(n)).map(n=>normalize(n,changed));
   if(!node||typeof node!=='object')return node;
   if(node instanceof RegExp)return {$regexp:node.source,flags:node.flags};
   if(changed&&node.type==='Identifier'&&names.has(node.name))return {type:'Literal',value:bindings[node.name]};
   const output={};
   for(const [key,value]of Object.entries(node)){
     if(node.type&&['start','end','loc','range'].includes(key))continue;
     if(node.type==='Literal'&&key==='raw')continue; // Preserve TemplateElement.value.raw.
     output[key]=normalize(value,changed);
   }
   return output;
 };
 const canonicalBefore=JSON.stringify(normalize(before,false)),canonicalAfter=JSON.stringify(normalize(after,true));
 assert.equal(canonicalAfter,canonicalBefore,'Normalized executable AST differs');
 assert.equal(digest(readFileSync(repo+'/'+spec.path)),spec.afterSha256,'File changed during audit');
 reports.push({path:spec.path,beforeSha256:spec.beforeSha256,afterSha256:spec.afterSha256,
   constantBindings:Object.keys(bindings).length,constantDeclarationStatements:declarationNodes.size,replacements:references,
   bindings,referenceContexts,normalizedASTSha256:digest(canonicalBefore),normalizedASTEqual:true,
   namesAbsentFromOriginalAST:true,allConstantsPrivateAndEagerlyInitialized:true,allUsesValueReferencesWithoutShadowOrWrites:true,
   noPropertyMangling:true,errorMessageValuesAndPermissionConditionsUnchanged:true});
}
const result={kind:'independent-exact-literal-budget-review',status:'PASS',baseCommit:proof.baseCommit,
 parser:'acorn '+acornVersion,inputProofPath:proofPath,inputProofSha256:digest(proofBytes),files:reports,
 totals:{constantBindings:reports.reduce((n,r)=>n+r.constantBindings,0),declarationStatements:reports.reduce((n,r)=>n+r.constantDeclarationStatements,0),
 replacements:reports.reduce((n,r)=>n+r.replacements,0)},
 scope:'Only exact string-literal reuse in these two source files. No build, native proof, jQuery audit expansion or score change.'};
assert.equal(result.totals.constantBindings,15);assert.equal(result.totals.replacements,268);
const path=root+'/r31-exact-literal-independent-audit.json';writeFileSync(path,JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify({status:result.status,baseCommit:result.baseCommit,totals:result.totals,output:path,sha256:digest(readFileSync(path))},null,2));
