# OpenDesk Browser R3.1 独立安全审计简报

审计日期：2026-10-10。审计者：独立只读子任务 `authorization_audit`。

## 结论与适用范围

**在本次审查的 Page 安装自动运行、已安装 Task 的 Controller 执行、安装/恢复 UI 和既有 Authority 边界内，历史上实际复现的高优先级越权或旧授权复活路径均已修复；本次最终复审未发现仍可复现的 P1/P2。** 此结论以源码审查、审计期间的独立组件复现及修复后复测为依据，不能替代尚未完成的真实 Chrome 异常场景验收。

审计固定的 R3.1 运行实现为 `13e02a689e2a3db77ff444e75e7a41d595fb1f93`。另已审查并行 main 变更 `92ddeeb43a129942226d2d5c5c2967d7c305a9e8` 的默认全部 HTTP(S) 网站范围。此次补充组件检查实际运行时的 HEAD 为 `6f5516dbc058d88df185a1374d5566cf384bf9fc`；此提交补充测试、原生驱动和 CI shell 设置，没有改写本次审计的 R3.1 授权实现。

不将“测试数量”折算成总体完成度。本简报暂不出具总体数值评分，待当前固定版本的原生结果及原始证据完成核验后再定。主执行者应同时发布最新实际测试数量、构建结果和原始 CI 链接；本简报不虚构链接或将先前版本的通过记录冒充当前版本通过。

## 已关闭的实际问题

| 原可复现路径 | 最小安全修复 | 修复后独立验证结论 |
| --- | --- | --- |
| Page 在停用再启用、撤销再授予后，旧 bootstrap token 恢复可用 | 在原 `page-installed-v1` 内保存安装身份、generation、status、exact scope；安装、恢复、停用和撤销轮换 token/代次 | 旧消息被拒绝，不能借新一代授权再次派发源码 |
| 权限移除发生在最后一次异步校验与派发之间 | `onRemoved` 同步增加内存 fence，随后有序持久 suspend；最后提交后、调用 Chrome 前再次同步核对 epoch | 已移除权限不能通过迟到 contains 结果跨越最后派发边界；`onAdded` 不复活 suspended Page |
| User Scripts API 关闭或 contains 返回 false，但没有 `onRemoved`，原安装仍可自动恢复 | 仅针对真实 `E_USER_SCRIPTS_UNAVAILABLE` 或内部 `pageAccessLost` 标记，按 namespace/nativeId/token 做 CAS 持久 suspend | API 恢复及 Worker 重建后旧消息仍拒绝；显式恢复产生新身份代次；伪造 marker 错误不会停用其他安装，无有序队列重入死锁 |
| Page 已发生效果，但在最后 contains 等待期间停用后仍交付成功 | 原生结果后重新授权；持久结果提交再核对当前 token/status/epoch | 保留已确认效果事实，结果为失败、成功值不交付；不声称回滚，不自动重放 |
| 安装 Task 只声明 page.automation，却可借普通 Controller 调用共享宿主存储、HTTP、Cookie 或 URL 下载上传 | 持续核验绑定的安装记录；已安装 Task 的 service 路径和特权 Cookie/uploadFromUrl 路径在派发前拒绝 | APPSTORAGE/AXIOS/Cookie/uploadFromUrl 组件调用以 `E_CAPABILITY` 拒绝，无特权 native 派发 |
| Task 停用后仍继续调用、重用旧回复，或迟到 finish 将其变成 completed | owner(active)、准入、重放及前后校验均核对 Task 安装身份；安装变更与活动 run 的 stopping/cancel fence 同事务提交 | 老操作/老回复不能继续；停用后 finish 收敛为 stopped，不能伪造成功 |
| Task 停用启用代次变化，以及卸载同版本重装导致 generation 重用后，旧 Run/Toggle/Install/Uninstall 点击被接受 | 全链绑定 `expectedGeneration` 和 `expectedInstallationId`，UI 在首个 await 前冻结选择，Authority 再 CAS | 同版本重装即使 generation 都为 1，旧四类请求均 `E_REVISION`；当前安装的新 Run 可准入 |
| 旧记录迁移或 Worker 恢复借机取得新授权、重放未知副作用 | Page 仅迁移完整固定来源和原验证证明匹配的安装；Task 仅在新 Run 的受控事务中迁移；旧 run/receipt/slot 维持失效或 unknown | 旧 live run 不能附着新安装授权；同 manifest/document 不重放；服务重建、session 改变或 BFCache 枚举遗漏不能证明原文档已消失 |

这些结论分别落在 `src/scripting/user-scripts/installed-programs.js`、`page-install-authorization.js`、`preview.js`、`src/platform/tasks/service.js`、`src/platform/host/controller-methods.js`、`src/run-host.js`、`src/ui/task-workbench.js`、`src/ui/page-program-library.js` 和 `sw.js` 的既有路径中。本次没有引入第二套权限数据库、执行器或给整页装 SDK 来代替脚本授权。

主执行者已把核心复现固化到 `tests/environment/page-installed-programs.test.mjs`、`tests/framework/k3-controller-authority.test.mjs` 和 `tests/environment/page-program-library.test.mjs`；本审计期间的独立复现使用真实组件和替身 Chrome API，不标为原生 Chrome 通过。

## 授权复用成立的条件

Chrome 网站权限是扩展级的原生权限，允许复用已有批准；OpenDesk 程序授权仍绑定独立安装身份、冻结源码/依赖/规则和当前状态。Chrome 对某网站或全部网站的批准，不会自动创建另一个程序的安装授权。

正常 Run、Verify、Preview、Enable 只做静默 `contains` 检查。可信 Install/Restore 点击根据预先观察的缺失子集同步请求；过期观察不会自动转化为新弹窗。内部创建 RunAuthority 是一次执行的绑定与校验，不是再次要求用户同意。

Page 当前授权能力为隔离 `page.dom`，Task 当前为 `page.automation`，两者 networkOrigins 均为空。**这里拒绝的是额外的宿主网络、浏览器 Cookie、宿主存储、Native 服务能力；不能把它宣传成阻止 DOM 程序访问其获准网页本来可访问的数据、Cookie 或网页网络行为。** 已授权 DOM 执行本身可以产生网页效果；独立网页 SDK 的文档级授权仍是另一条边界。

停用或撤销不能撤销已经发生的网页效果。现有 Page 源码创建的任意监听器、计时器或界面不承诺即时消失，界面已提示刷新原网页；后续派发和迟到成功交付会被挡住。未知结果继续保留，恢复操作不会自动重放当前文档。

## 并行变更 92ddeeb：默认全部 HTTP(S) 网站

该产品变更将新普通 JavaScript、没有 `@match` 的兼容导入默认范围设为 `*://*/*`、顶层、`USER_SCRIPT`；未另声明运行时机时默认 `document_idle`，显式时机仍受既有安装限制。它扩大了新候选的默认调度范围，仍通过明确的安装 UI 展示和确认；没有扩大 Manifest。已存在的显式规则与冻结安装保持原范围，不会因重新读取而变成全部网站。旧 GM 元数据继续只作为兼容输入，未实现的 grant 仍不能形成 OpenDesk 能力。

本次独立只读 stdin 检查实际通过：

- 新普通 JS 与无 `@match` 导入的默认范围正确；显式窄规则仍冻结。
- 窄 scope 升级为 `*://*/*` 被列为新增范围；同一 broad scope 不重复要求程序范围确认。
- 给 broad row 配窄 grant 被 `E_PAGE_AUTHORIZATION` 拒绝。
- 全 HTTP(S) 安装与 HTTPS 单站、localhost 端口、子域 wildcard、`<all_urls>`、IPv6 端口撤销均被判为有交集；file 范围不混入 HTTP(S)。
- 原生替身仅有窄站点权限时，Run 静默拒绝；可信 Install 同步申请 broad 一次；之后同 scope 确认和 20 次静默检查新增 request 为 0。

旧 legacy adapter 正例需要先冻结 broad candidate，再生成匹配的 authority proof。原先“窄 proof 后改 broad candidate”的测试失败是安全拒绝正确生效，不能通过放宽生产校验来修；主执行者已保留该负例并修正正例 fixture。

原文和实际输出保存在仓库外，复查方式为从仓库根目录执行 `node --input-type=module < /workspace/scratch/eceef8694f0a/r31-fullscope-audit.stdin.mjs`：

| 文件 | SHA-256 |
| --- | --- |
| `/workspace/scratch/eceef8694f0a/r31-fullscope-audit.stdin.mjs` | `e673b402ec89b29ecf99556822c1b48746a3465461b9d5867652f91849525d23` |
| `/workspace/scratch/eceef8694f0a/r31-fullscope-audit.output.json` | `6ad89ef6463155a5dd73f5317bd0d058f3ba57287ad0f0ec96b299ea9cf45785` |

## 原生证据与仍未完成的验收

主执行者此前报告真实 Chrome 已完成两程序安装、停用 B、20 个独立自动文档且 request 为 0；该证据的准确版本、观察窗口和原始日志仍应随最终原生报告一并发布。本次审计不自行把这条报告扩展成完整浏览器重启已通过。

主执行者在最终运行提交 13e02a6 阶段报告 262 项定向测试、`npm run check`、production/dev 构建及 10 条相关 CI 通过。后续并行 main 新增默认范围使个别旧测试 fixture 需要更新；应以主执行者随后发布的最终版本完整结果为准，而不是沿用旧计数。独立审计没有重跑无关全套测试。

截至本简报形成时，完整浏览器原生 driver 的 live registration/启动等待仍在修复和验收，以下不能标为当前版本原生 PASS：

- Worker 真正终止重建及浏览器退出后使用同一 profile 重启，对持久授权和不重放的完整实测结论。
- Chrome 网站访问真实撤销/恢复、User Scripts 开关关闭后恢复，以及相应原生权限交互与晚到事件的异常排列。
- 默认全部网站下，同范围升级和窄范围扩大为全站的真实 UI 权限确认。
- 普通 Controller/本地项目各 20 次运行的原生 request 计数；实际跨程序恶意 RPC 穿透测试。
- 新权限观察器附着前的浏览器启动阶段：若没有原始观察，必须标为 NOT_OBSERVED。

这些原生缺口不等于已观察到运行实现失效，也不能靠组件通过替代。主执行者提供最新原始证据后可以逐项更新状态；未运行的项继续保留 NOT_TESTED/BLOCKED。

## 当前能力边界

目前正式 Installed Page 仅支持顶层、`document_idle` 的隔离执行。早期时序、多 frame 和更多能力不在本次准入范围。程序私有的特权跨站 HTTP、Cookie、宿主存储和 Native Messaging 桥未实现，不应列为本轮已交付能力。

Native 直接以 `task:` 保存来源启动的路径还没有安装快照传递能力，当前安全拒绝缺少身份/代次的调用；不能记作已安装 Task 的 Native E2E 通过。普通 Native 草稿/已保存来源与本次无关，没有据此重新验收。完整 F3/ZIP 等扩大范围的测试也不在本简报的通过声明中。

审计未修改共享仓库、dist、Git 状态、Manifest 或任何 SDK/Native 实现。保留精确来源、单一 Authority、未知副作用保护与程序间授权隔离，是本次源码/组件结论的前提。
