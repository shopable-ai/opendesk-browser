# R3.1 独立质量与证据对照草稿

状态：DRAFT / NOT_FINAL。不得将本文的条件评分作为最终 PASS。
审核者：entrypoints_review（只读审查仓库及原始证据；仅本草稿写在仓库外）。
日期：2026-10-10。

## 1. 身份与当前结论

- 已核验的主要候选：`13e02a689e2a3db77ff444e75e7a41d595fb1f93`。
- 该候选真实开发包 packageHash：`ddadcddd11074091bf3d4f6fbff2910ed0759335e5978a22f0c598a049a0f415`。
- 对应本地产包生产 packageHash：`023865c2842898da71600ac8efd347237c9f2ae7e27099c49288de9157fb010f`；生产构建继续受原 320 KiB 上限约束。
- 本次读取仓库过程中 main 已从 `7a42933d15b9e54f96cacf599b248bd432a9ff2e` 正常合并至 `913fd6c9baf99062c522f01b398076cab5111832`。测试驱动另有 root 正在修改的未提交差异，不能借用旧 sourceCommit。
- 新合入 `92ddeeb43a129942226d2d5c5c2967d7c305a9e8` 将普通 JS/无 @match 的默认范围改为 `*://*/*`，显式 @match 仍保留；原生第二轮仍是旧 `http://127.0.0.1/*` 范围。最终候选必须保存新的输入、包和原生证据绑定。
- 已支持范围仅为 Installed Page `page.dom` 与 Installed Task `page.automation`；程序私有 HTTP/Cookie/宿主存储/Native Messaging 桥未实现。

对 13e02a6 已闭合事实的阶段评分为 **93/100**。新默认范围整合候选仍为 **最终复核待完成**，不继承该数值为正式签署。最终实际 native PASS、相关输入影响复核及 CI 条件全部满足后，可按同一 rubric 得到 **96/100（已支持范围的质量评分）**，不是全部权限能力或整体 F3/ZIP 完成率。

## 2. 固定评分规则

| 维度 | 满分 | 13e02a6 已核验阶段 | 最终条件全部满足 |
| --- | ---: | ---: | ---: |
| 功能与恢复体验 | 25 | 25 | 25 |
| 安全设计与组件边界 | 35 | 35 | 35 |
| 回归与交付门槛 | 20 | 20 | 20 |
| 真实 Chrome 证据 | 20 | 13 | 16 |
| 合计 | 100 | 93 | 96 |

- 功能 25：普通 Run/本地 Run/Page Preview/Task Run 的静默检查；安装复用；Page 恢复、升级确认与现有持久模型；主视图共用恢复行。原 2 分恢复可发现性问题已修复并只读复核。
- 安全 35：这是源码与组件边界栏。固定来源/安装身份/代次、撤销最终派发 fence、共享 Authority、跨程序拒绝、未知效果与旧回执保护已核对。原生对抗性证明另列，不把此栏满分叫作完整安全认证。
- 回归 20：13e 的产品/包回归工作流及全环境 gate、check、开发/生产构建已提供原始结果。该分不自动转移给新默认规则和新 driver 输入；需对应最新门槛与影响核对。
- 原生 20 的权重：正常安装后 20 个文档自动执行且 request=0 为 7；两个独立安装身份及 B 停用不执行为 3；真实 Worker 恢复为 3；完整浏览器同 profile 恢复及后续新文档执行为 3；原生撤权/恢复、升级/扩权、Controller/本地 20 循环、对抗边界尚缺合计 4。
- 13e 的完整浏览器操作已经证明新 PID 和原 profile，但注册恢复/无重放/第 22 文档的整体验收尚未闭合，因此上述完整浏览器 3 分尚不授予。
- 不按测试数、CI 条数、跳过数量计算完成百分比。

## 3. 原生证据逐项对照

原始 CI：[R3.1 13e02a6 真实 Chrome](https://github.com/shopable-ai/opendesk-browser/actions/runs/38041934574)。
本地原件：`ci-13e02a6/acceptance.json`、`permission-observations.json`、`launcher.cleanup.json`、`document-01.json` 至 `document-21.json`。

| 项目 | 原始状态 | 可作出的结论 |
| --- | --- | --- |
| 正式 Side Panel 保存、验证、安装两个普通 JS 程序 | PASS | 原始源码未被改写；两个 installationId 独立；B 由可信点击停用 |
| 20 次 installed auto run | PASS | 20 个不同 document；request=0；停用的 B 执行数为 0 |
| Worker stop/start 与恢复 | PASS | native lifecycle 为 stopped→running；target ID 可复用，但 execution context uniqueId 与观察器 ID 确实变化；安装批准不变；原 20 回执不重放；第 21 文档完成 |
| 完整浏览器重启 | FAIL（整轮仍 FAIL） | PID 3264→3484；同 profile device=16777231/inode=3527344；实际注册恢复检查失败，未执行完成第 22 文档 |
| 清理 | PASS | 两个自有 Chrome 子进程退出，profile 移除，无残留、无清理错误 |
| 观察器窗口 | 有边界 | 已观测运行窗口累计 request=0；启动时观察器附加前仍是 NOT_OBSERVED |

Worker 细节：旧 uniqueId `-4649600347816734432.4775941024498822660`，新 uniqueId `8132305438448346399.-7126870741427307015`；第 21 documentId `16F0AAC96BB4A171BCBBFB96CA396078`。

根因应写成“驱动只等待持久 nativeState=registered，早于本次 Chrome 注册完成”，同时保留原 FAIL；不能仅凭根因推断实际完整恢复已通过。拟修正的等待条件读实际 `chrome.userScripts.getScripts()`，保留安装/会话/回执/新文档所有断言；严格等待本身不是 PASS 证据。

首轮 `a88919c` 的 FAIL 与两个 PASS 案例也永久保留。第二轮通过的 Worker 证明关闭首轮 target ID 假设问题，不能改写首轮原始结果。

## 4. CI 与组件证据

API 原始映射：`ci-13e02a6/workflow-status.json`。
共有 11 条运行：9 条产品/包工作流 success，1 条分支清理 success，1 条 R3.1 native failure。分支清理不计功能回归。

| 工作流 | 原始链接 | 13e02a6 结果 |
| --- | --- | --- |
| Site access targeted checks | https://github.com/shopable-ai/opendesk-browser/actions/runs/38041934537 | success |
| R7 axiosx HTTP page + fixture contracts | https://github.com/shopable-ai/opendesk-browser/actions/runs/38041934473 | success |
| OpenDesk multi-file source contract | https://github.com/shopable-ai/opendesk-browser/actions/runs/38041934490 | success |
| Sidebar R1 P0 targeted checks | https://github.com/shopable-ai/opendesk-browser/actions/runs/38041934534 | success |
| SDK grant authority and revocation regression | https://github.com/shopable-ai/opendesk-browser/actions/runs/38041934496 | success |
| Native Page program source and authorization boundaries | https://github.com/shopable-ai/opendesk-browser/actions/runs/38041934535 | success |
| Page userscript dependencies and package | https://github.com/shopable-ai/opendesk-browser/actions/runs/38041934506 | success |
| Sidebar user tools R1 - package and build | https://github.com/shopable-ai/opendesk-browser/actions/runs/38041934466 | success |
| Native Agent R1 components and package | https://github.com/shopable-ai/opendesk-browser/actions/runs/38041934553 | success |

Native 全环境 job：[114183740058](https://github.com/shopable-ai/opendesk-browser/actions/runs/38041934553/job/114183740058)，624 total / 617 pass / 0 fail / 7 skip。
本地 `affected-r31-final.log` 为 262 pass / 0 fail / 0 skip；与全环境集合重叠，分别报告，不能相加。
`check-r31-final.log`、`build-production-r31-final.log`、`build-development-r31-final.log` 均通过。
原 Linux 全环境 595 pass / 20 fail / 7 skip 的日志保持不变，后来的 CI 是新环境新记录。

## 5. 文档的最小精确更新范围

### 必须更新：docs/framework/workstreams/install-once-authorization-r31.md

- 第 3 行状态：区分“被测 13e 的 3 项原生 PASS/整轮 FAIL”“新默认范围最终候选待验收”；收到最终 artifact 后再改当前结论。
- 第 9 行资源：补真实 CI 独占 CFT/profile/PID 与清理 receipt，不再使用“启动前补充”的将来时。
- 第 14 行“尚无运行零弹窗的实现验收”改为启动时基线说明；当前已有的原生 PASS 不应被这句话否认。
- 已完成实现补充全视图条件恢复行，说明复用同一 siteAccess.grant(event)，恢复后不自动续跑。
- 已完成实现/能力边界补充 main 合入的新默认 `*://*/*`、显式 @match 保留、安装前披露与确认、既有窄安装不被默默扩权。此项等 authority_audit 和新原生证据复核。
- 第 37 行“各普通运行入口连续 20 次”改为精确集合：组件明确覆盖普通 Controller/Task 各 20 次、Page Preview 20 次、Installed Page 20 文档；本地项目定向覆盖与本地原生 20 循环缺口单列。
- 保留第 41 行 0094 的 230 测试和旧 packageHash 为历史记录，追加 13e 的 262、全环境 617/624、CI 原链接及精确 packageHash，不覆盖或相加。
- 增加两轮原生证据矩阵，保留失败原因、范围、sourceCommit、原始哈希、清理；最终轮另追加。
- 第 47–53 行待完成改为真实剩余项，避免把已经通过的 Worker 恢复继续笼统叫未完成，也避免提前关闭完整浏览器恢复。
- 最终质量评分注明 rubric、独立审核者、适用范围和原生未测项；96 条件未满足前不得写正式 PASS。

### 必须更新：docs/architecture/browser-framework/install-once-script-authorization-r3.zh-CN.md

- 第 3 节标题“当前 main 已有事实”及表格实际记录实施前重复 request 基线：明确标“实施前基线”，保留历史事实。
- 第 5 节加入恢复行和新的 plain-JS 默认范围；维持已支持 `page.dom` / `page.automation` 与私有桥未实现边界。
- 保留本文是设计/合同的定位；最终结果链接到工作流。95/96 不能等于统一能力桥已交付。

### 必须更新：docs/architecture/browser-framework/site-permission-onboarding.zh-CN.md

- 第 29 行旧“三个主页签”改为实际“我的/发现/工作流/开发/工具”五个；说明缺权时所有视图可见恢复行，原高级完整面板保留。
- 第 25 行“网页自动化任务 HTTP 走宿主 Network Service”易被读成 Installed Task 已支持；明确为已有手工 Controller/独立 SDK 合同，Installed Task v1 不继承该能力。
- 说明恢复仍是明确点击、无自动续跑；不修改原验收门槛，不把本轮未测的撤权/恢复打勾。

### 小范围更新：docs/architecture/browser-framework/native-program-authorization-r2.zh-CN.md

- 第 96 行“默认范围仍从用户已试运行网页提出”仅适用于 R2 原候选，须标历史或加 R3.1/new-main 覆盖说明：新普通脚本默认全 HTTP(S)，显式规则保留，旧安装授权不能被此默认替换。
- 第 108 行原生待测清单保留 R2 原身份；增加链接说明 R3.1 已覆盖的独立证据，不把新证据冒充 R2 原候选重跑。
- 程序私有桥与统一能力模型未完成的声明不删除。

### 导航更新：docs/framework/testing-guide.md

- 仅在顶部“跨对话测试复用入口”表新增“安装一次授权 R3.1（本工作流）”及证据/复用范围。
- 不覆盖表中另一个“Program R3.1 / PR #23”工作流。
- 不改后面明确标为 2026-10-05 历史快照的 603/19/F3/ZIP 数字和身份。

## 6. 最终 native PASS 到达后的独立核验条件

1. 新 acceptance 的 sourceCommit、输入 hash、packageHash 与实际最终候选一致；新默认范围是 `*://*/*`，安装 UI 真实披露后有可信 Install 输入。
2. 保存真实普通 JS 原始字节；A/B 安装身份独立，B 停用后零执行；20 文档 request=0。
3. Worker 停止/启动有真实 native lifecycle/context/observer 证明；安装批准不变、旧回执无重放、第 21 文档完成。
4. 完整浏览器旧进程退出/新 PID/同 profile device+inode；当前 Chrome 的实际注册集与 A 启用、B 停用一致；新 browserSessionIncarnation；旧回执未重放；第 22 文档完成且累计 request=0。
5. 总报告真实 PASS、观察器无错误、清理 PASS；不能用启动前未观测区间声称全过程零 request。
6. 新默认宽规则的撤销/升级/旧安装兼容由 authority_audit 结论和定向结果支持；最终相关 CI 或明确输入一致的可复用 CI 有原始记录。
7. 以下缺口继续保留：原生站点撤权/拒绝/主动恢复、同范围升级/扩权、Controller/本地 20 循环、真实对抗跨程序/旧回执/多标签竞态、程序私有桥、完整 F3/ZIP、Native run.start 直传 task: 安装快照兼容。

## 7. 已读取证据文件哈希

所有相对路径均基于 /workspace/scratch/eceef8694f0a/r31-evidence。

| 文件 | SHA-256 |
| --- | --- |
| ci-13e02a6/acceptance.json | c2b93e914abbfd9edb7d054e6ee8c514a6594534ce8131cd1896bb7fc41954b1 |
| ci-13e02a6/workflow-status.json | cd3699d2d6c8c046133350164dc5584cb9f8638c7ef6cd29683b860447f03182 |
| ci-13e02a6/permission-observations.json | 607c46ab15d1863edc52862d1e322fb690e089cc04659ccd7ce8813231e77bef |
| ci-13e02a6/launcher.cleanup.json | 11a061d4b59d21275802dec9a0d22fd84144eb5d0263d6b32bb194a278e60737 |
| affected-r31-final.log | 7fa8e01df2250871cdaea401de15dbe61cf9e51294c12631cdd76695bdaf157f |
| build-production-r31-final.log | 773e8da9ec44d5eeb65c615242856dc3070bbbb9f7c3e6d035992d1f5e9168ae |
| build-development-r31-final.log | 695d6e480eada32cdc3caffa89b8975c30c564439f5315c56e74c6c8dcc3c206 |
| recovery-accessibility-final.log | a790664ea802735c7166ea1b3c309b3f2b7bf3ff2919778463ac7f82a7043b26 |

本草稿未修改仓库、未运行 Chrome、未改写测试结果。后续正式评分必须追加新原始证据核验，不凭“已修等待”或“预期 CI 通过”直接签署。

