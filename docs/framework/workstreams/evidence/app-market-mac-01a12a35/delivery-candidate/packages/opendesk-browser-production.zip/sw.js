var sw=function(){"use strict"
const e="opendesk.environment.v1"
class t extends Error{constructor(e,t){super(t),this.code=e}}function a(e){let a
try{a=new URL(e)}catch{throw new t("E_TARGET","目标地址无效")}if(!["http:","https:"].includes(a.protocol)||a.username||a.password)throw new t("E_TARGET","仅支持无账户信息的 HTTP(S) 顶层页面")
return a}function n(e){const t=a(e)
return`${t.protocol}//${t.hostname}/*`}function r(e,t){const a=t?.tab?0===t.frameId:void 0===t?.frameId||0===t.frameId
return t?.id===e.runtime.id&&i(e,t.url)&&"string"==typeof t.documentId&&t.documentId.length>0&&a&&(!t.documentLifecycle||"active"===t.documentLifecycle)&&!t.tab?.incognito}function i(e,t){try{const a=new URL(t),n=new URL(e.runtime.getURL("ui/tool.html"))
return a.protocol===n.protocol&&a.host===n.host&&a.pathname===n.pathname&&!a.hash&&(!a.search||1===[...a.searchParams].length&&/^[A-Za-z0-9._:-]{1,128}$/.test(a.searchParams.get("hostInstanceId")||""))}catch{return!1}}async function o(e,a){if(r(e,a))return a
if(a?.documentId||a?.id!==e.runtime.id||a.tab||void 0!==a.frameId&&0!==a.frameId||!i(e,a.url)||!new URL(a.url).searchParams.has("hostInstanceId"))throw new t("E_OWNER","Unresolved packaged tool sender")
const n=(await e.runtime.getContexts({contextTypes:["SIDE_PANEL"],documentUrls:[a.url]})).filter((e=>"SIDE_PANEL"===e.contextType&&e.documentUrl===a.url&&0===e.frameId&&!e.incognito&&"string"==typeof e.documentId&&e.documentId.length>0))
if(1!==n.length)throw new t("E_OWNER","Side Panel document is missing or ambiguous")
return Object.freeze({...a,documentId:n[0].documentId,frameId:n[0].frameId})}const s={type:"integer",minimum:1,maximum:50},c={type:"string",minLength:1,maxLength:128,pattern:"^[A-Za-z0-9._:-]+$"},d={type:"integer",minimum:1,maximum:9007199254740991},l={type:"string",pattern:"^[0-9a-f]{64}$"},u={type:"integer",minimum:0,maximum:9007199254740991},p={type:["string","null"],format:"date-time"},m={type:"integer",minimum:0,maximum:1e4},f={type:"object",properties:{pageNumber:s,url:{type:"string"},lastSnapshotId:c},required:["pageNumber","url","lastSnapshotId"],additionalProperties:!1},g={type:"integer",minimum:0,maximum:8388608},I={type:"array",items:c,minItems:1},w={type:"array",items:c},h={type:"object",properties:{maxPages:s,maxRecords:{type:"integer",minimum:1,maximum:1e4},maxDurationMs:{type:"integer",minimum:1,maximum:6e5},maxStoredBytes:{type:"integer",minimum:1,maximum:20971520}},required:["maxPages","maxRecords","maxDurationMs","maxStoredBytes"],additionalProperties:!1},E={type:"object",properties:{targetSessionId:c,tabId:u,frameId:{const:0},documentId:c,allowedOrigin:{type:"string"},targetVersion:d,browserSessionIncarnation:c,creationId:c},required:["targetSessionId","tabId","frameId","documentId","allowedOrigin","targetVersion","browserSessionIncarnation","creationId"],additionalProperties:!1},y={type:"object",properties:{policyVersion:{const:"1.0.0"},tier:{enum:["free","pro"]},approvedAt:{type:"string",format:"date-time"},claimHash:{type:["string","null"],pattern:"^[0-9a-f]{64}$"},offlineAgeMs:{type:"integer",minimum:0,maximum:2592e5},effectiveLimits:{$ref:"#/$defs/Limits"},maxSavedTemplates:{enum:[1,50]},approvedCapabilities:{type:"array",items:c,uniqueItems:!0},runExpiryRevokes:{const:!1}},required:["policyVersion","tier","approvedAt","claimHash","offlineAgeMs","effectiveLimits","maxSavedTemplates","approvedCapabilities","runExpiryRevokes"],additionalProperties:!1},b={type:"object",properties:{runId:c,ownerEpoch:d,runRevision:d,eventSeq:u,commitSeq:u,hostInstanceId:c,hostDocumentId:c,templateHash:l,state:{enum:["preparing","running","stopping","paused_unknown","retiring","completed","limit_reached","stopped","failed","interrupted","abandoned_unknown"]},cancelSeq:u,committedCount:m,committedPages:{type:"integer",minimum:0,maximum:50},storedBytes:{type:"integer",minimum:0,maximum:20971520},checkpoint:{oneOf:[{$ref:"#/$defs/Checkpoint"},{type:"null"}]},target:{oneOf:[{$ref:"#/$defs/Target"},{type:"null"}]},entitlementSnapshot:{$ref:"#/$defs/EntitlementSnapshot"},retirementState:{enum:["not-started","fenced","closing","absence-proven","released"]},terminalReason:{type:["string","null"]},tombstoned:{type:"boolean"}},required:["runId","ownerEpoch","runRevision","eventSeq","commitSeq","hostInstanceId","hostDocumentId","templateHash","state","cancelSeq","committedCount","committedPages","storedBytes","checkpoint","target","entitlementSnapshot","retirementState","terminalReason","tombstoned"],additionalProperties:!1},v={type:"object",properties:{run:{oneOf:[{$ref:"#/$defs/Run"},{type:"null"}]},pendingCommandIds:w,exportJobIds:w,eventSeq:u,slotAvailable:{type:"boolean"}},required:["run","pendingCommandIds","exportJobIds","eventSeq","slotAvailable"],additionalProperties:!1,allOf:[{if:{properties:{run:{type:"null"}}},then:{properties:{pendingCommandIds:{maxItems:0}}}}]},_={$defs:{DownloadAttempt:{type:"object",properties:{attemptId:c,exportJobId:c,runId:c,artifactId:c,artifactHash:l,artifactBytes:g,rowCount:m,hostInstanceId:c,hostDocumentId:c,ownerEpochAtCreation:d,blobUrl:{type:"string",pattern:"^blob:chrome-extension://"},filename:{type:"string"},preparedAt:{type:"string",format:"date-time"},dispatchAt:p,mappingDeadline:p,downloadDeadline:p,state:{enum:["prepared","dispatched","mapping_unknown","in_progress","complete","interrupted","deadline_unknown","abandoned","conflict"]},downloadId:{type:["integer","null"],minimum:0},resourceReleasedAt:p,timedOutAt:p,candidateDownloadIds:{type:"array",items:u,uniqueItems:!0},mappedAt:p,submissionCount:{type:"integer",minimum:0,maximum:1}},required:["attemptId","exportJobId","runId","artifactId","artifactHash","artifactBytes","rowCount","hostInstanceId","hostDocumentId","ownerEpochAtCreation","blobUrl","filename","preparedAt","dispatchAt","mappingDeadline","downloadDeadline","state","downloadId","resourceReleasedAt","timedOutAt","candidateDownloadIds","mappedAt","submissionCount"],additionalProperties:!1}}},S={$defs:{Receipt:{type:"object",properties:{attemptId:c,downloadId:u,observedState:{enum:["in_progress","complete","interrupted"]},observedAt:{type:"string",format:"date-time"},evidence:{enum:["onChanged+search","search"]},byExtensionId:c,late:{type:"boolean"},browserDownloadComplete:{type:"boolean"},diskHashVerified:{const:!1},interruptReason:{type:["string","null"]}},required:["attemptId","downloadId","observedState","observedAt","evidence","byExtensionId","late","browserDownloadComplete","diskHashVerified","interruptReason"],additionalProperties:!1}}},A={$defs:{ExportJob:{type:"object",properties:{exportJobId:c,runId:c,templateHash:l,sealWatermark:u,committedCount:m,format:{enum:["csv","json"]},csvMode:{enum:["spreadsheet-safe","raw"]},partial:{type:"boolean"},artifactIds:I,activeAttemptIds:I,state:{enum:["preparing","ready","delivering","delivery_complete","delivery_partial","delivery_unknown","delivery_failed","abandoned"]}},required:["exportJobId","runId","templateHash","sealWatermark","committedCount","format","csvMode","partial","artifactIds","activeAttemptIds","state"],additionalProperties:!1}}},O={$defs:{Artifact:{type:"object",properties:{artifactId:c,exportJobId:c,volumeIndex:u,format:{enum:["csv","json"]},mime:{enum:["text/csv;charset=utf-8","application/json"]},bytes:g,rowCount:m,sha256:l,storageEncoding:{const:"Uint8Array-chunks"},chunkKeys:I,filename:{type:"string",maxLength:128},templateHash:l,sealWatermark:u},required:["artifactId","exportJobId","volumeIndex","format","mime","bytes","rowCount","sha256","storageEncoding","chunkKeys","filename","templateHash","sealWatermark"],additionalProperties:!1}}},k={$defs:{Limits:h,Target:E,EntitlementSnapshot:y,Checkpoint:f,Run:b,Projection:v}},T={$defs:{Limits:h,Target:E,EntitlementSnapshot:y,Checkpoint:f,Run:b,Projection:v,RegisterHostResponse:{type:"object",properties:{hostDocumentId:c,registrationId:c,projection:{$ref:"#/$defs/Projection"}},required:["hostDocumentId","registrationId","projection"],additionalProperties:!1}}},R="opendesk.foundation.v1",N=Object.freeze({activeRuns:1,executionTabs:1,maxPages:50,maxRecords:1e4,maxDurationMs:6e5,maxStoredBytes:20971520,maxBatchBytes:262144,maxPendingACKs:2,maxArtifactBytes:8388608,profileStoredBytes:209715200,retentionDays:7,mappingWindowMs:6e4,downloadDeadlineMs:6e5,commandReconcileMs:3e4,maxRecordBytes:65536,maxRawFrameBytes:131072})
class C extends Error{constructor(e,t){super(t),this.name="FoundationError",this.code=e}}function U(e){const t={code:e?.code??"E_EFFECT_UNKNOWN",message:e?.message??"SDK response unavailable"}
for(const a of["stage","status","response"])Object.hasOwn(e??{},a)&&(t[a]=e[a])
if(Object.hasOwn(e??{},"invocation")){const a=e.invocation,n=["requestId","runId","opId","grantIncarnation"]
a&&n.every((e=>Object.hasOwn(a,e)&&"string"==typeof a[e]&&a[e].length>0))&&(t.invocation=Object.fromEntries(n.map((e=>[e,a[e]]))))}return t}function P(e,t="E_SCHEMA",a=t){if(!e)throw new C(t,a)}const D=()=>crypto.randomUUID(),x=new Set(["__proto__","prototype","constructor"])
function L(e){for(let t=0;t<e.length;t++){const a=e.charCodeAt(t)
if(a>=55296&&a<=56319){const a=e.charCodeAt(++t)
P(a>=56320&&a<=57343,"E_SCHEMA","Unpaired UTF-16 surrogate")}else P(a<56320||a>57343,"E_SCHEMA","Unpaired UTF-16 surrogate")}return JSON.stringify(e)}function H(e,{maxDepth:t=12}={}){return P(Number.isSafeInteger(t)&&t>=0&&t<=48,"E_SCHEMA","Invalid JSON depth budget"),function e(a,n){if(P(n<=t,"E_SCHEMA","JSON exceeds depth limit"),null===a)return"null"
if("string"==typeof a)return L(a)
if("boolean"==typeof a)return a?"true":"false"
if("number"==typeof a)return P(Number.isFinite(a),"E_SCHEMA","Non-finite number"),JSON.stringify(a)
if(P("object"==typeof a,"E_SCHEMA","Non-JSON value"),Array.isArray(a))return"["+Array.from(a,(t=>e(t,n+1))).join(",")+"]"
P(Object.getPrototypeOf(a)===Object.prototype||null===Object.getPrototypeOf(a),"E_SCHEMA","Only plain JSON objects are allowed")
const r=Object.keys(a).sort()
for(const t of r)P(!x.has(t)&&/^[\x20-\x7e]+$/.test(t),"E_SCHEMA","Unsafe JSON key")
return"{"+r.map((t=>L(t)+":"+e(a[t],n+1))).join(",")+"}"}(e,0)}async function M(e,t){const a=(new TextEncoder).encode(H(e,t)),n=await crypto.subtle.digest("SHA-256",a)
return Array.from(new Uint8Array(n),(e=>e.toString(16).padStart(2,"0"))).join("")}async function j(e){P("string"==typeof e,"E_VALUE_SERIALIZATION","Expected UTF-8 text"),L(e)
const t=await crypto.subtle.digest("SHA-256",(new TextEncoder).encode(e))
return Array.from(new Uint8Array(t),(e=>e.toString(16).padStart(2,"0"))).join("")}function q(e,t,a,n={active:[],steps:0}){P(++n.steps<=1e6&&n.active.length<128,"E_SCHEMA",a+": schema traversal budget exceeded"),P(!n.active.some((a=>a.rule===e&&a.value===t)),"E_SCHEMA",a+": cyclic schema reference"),n.active.push({rule:e,value:t})
try{return function(e,t,a,n){const r=e=>P(!1,"E_SCHEMA",`${a}: ${e}`)
if(!0===e)return
if(!1===e)return r("value forbidden")
if(P(null!==e&&"object"==typeof e,"E_SCHEMA",a+": invalid schema"),Object.hasOwn(e,"$ref"))return q(function(e,t){P("string"==typeof e&&e.startsWith("#/"),"E_SCHEMA","Only local schema references are supported")
let a=t
for(const n of e.slice(2).split("/")){P(!/~(?:[^01]|$)/.test(n),"E_SCHEMA","Invalid schema reference")
const t=n.replace(/~1/g,"/").replace(/~0/g,"~")
P(null!==a&&"object"==typeof a&&Object.hasOwn(a,t),"E_SCHEMA","Unknown schema reference "+e),a=a[t]}return a}(e.$ref,n.schema),t,a,n)
Object.hasOwn(e,"const")&&H(t)!==H(e.const)&&r("wrong constant"),e.enum&&!e.enum.some((e=>H(e)===H(t)))&&r("unknown enum")
const i=e=>{try{return q(e,t,a,n),!0}catch(r){if("E_SCHEMA"!==r.code)throw r
return!1}}
e.oneOf&&1!==e.oneOf.filter(i).length&&r("must match exactly one variant"),e.anyOf&&!e.anyOf.some(i)&&r("no matching variant")
for(const s of e.allOf||[])q(s,t,a,n)
e.if&&(i(e.if)&&e.then?q(e.then,t,a,n):!i(e.if)&&e.else&&q(e.else,t,a,n)),e.not&&i(e.not)&&r("forbidden variant")
const o=Array.isArray(e.type)?e.type:e.type?[e.type]:[]
if(o.length&&!o.some((e=>"null"===e?null===t:"array"===e?Array.isArray(t):"object"===e?null!==t&&"object"==typeof t&&!Array.isArray(t):"integer"===e?Number.isSafeInteger(t):"number"===e?"number"==typeof t&&Number.isFinite(t):typeof t===e))&&r("wrong type"),"string"==typeof t&&(void 0!==e.minLength&&[...t].length<e.minLength&&r("too short"),void 0!==e.maxLength&&[...t].length>e.maxLength&&r("too long"),e.pattern&&!RegExp(e.pattern).test(t)&&r("pattern mismatch"),"date-time"!==e.format||function(e){const t=/^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(Z|[+-](\d{2}):(\d{2}))$/.exec(e)
if(!t)return!1
const[,a,n,r,i,o,s,,c,d]=t,[l,u,p,m,f,g]=[a,n,r,i,o,s].map(Number)
return u>=1&&u<=12&&p>=1&&p<=[31,l%4!=0||l%100==0&&l%400!=0?28:29,31,30,31,30,31,31,30,31,30,31][u-1]&&m<=23&&f<=59&&g<=59&&(void 0===c||Number(c)<=23&&Number(d)<=59)&&Number.isFinite(Date.parse(e))}(t)||r("invalid timestamp"),"uri"===e.format))try{new URL(t)}catch{r("invalid URL")}if("number"==typeof t&&(void 0!==e.minimum&&t<e.minimum&&r("below minimum"),void 0!==e.maximum&&t>e.maximum&&r("above maximum"),void 0!==e.exclusiveMinimum&&t<=e.exclusiveMinimum&&r("below exclusive minimum"),void 0!==e.exclusiveMaximum&&t>=e.exclusiveMaximum&&r("above exclusive maximum")),Array.isArray(t))void 0!==e.minItems&&t.length<e.minItems&&r("too few items"),void 0!==e.maxItems&&t.length>e.maxItems&&r("too many items"),e.uniqueItems&&new Set(t.map(H)).size!==t.length&&r("duplicate items"),e.items&&t.forEach(((t,r)=>q(e.items,t,`${a}[${r}]`,n)))
else if(null!==t&&"object"==typeof t){for(const a of e.required||[])Object.hasOwn(t,a)||r("missing "+a)
for(const[i,o]of Object.entries(t))e.properties&&Object.hasOwn(e.properties,i)?q(e.properties[i],o,`${a}.${i}`,n):!1===e.additionalProperties?r("unknown "+i):"object"==typeof e.additionalProperties&&q(e.additionalProperties,o,`${a}.${i}`,n),e.propertyNames&&q(e.propertyNames,i,`${a}.${i}`,n)
void 0!==e.minProperties&&Object.keys(t).length<e.minProperties&&r("too few properties"),void 0!==e.maxProperties&&Object.keys(t).length>e.maxProperties&&r("too many properties")}}(e,t,a,n)}finally{n.active.pop()}}function F(e,t,a){return P(Object.hasOwn(e.$defs,t),"E_SCHEMA","Unknown schema "+t),H(a),q(e.$defs[t],a,t,{active:[],steps:0,schema:e}),a}const W=e=>new Date(e.now()).toISOString(),z=new Set(["completed","limit_reached","stopped","failed","interrupted","abandoned_unknown"]),V=Object.freeze({templates:{templateRevision:[["template.templateId","template.revision"],!0],contentHash:["template.contentHash",!1]},runs:{runId:["runId",!0],slotKey:["slotKey",!0],retirementId:["retirementId",!1],state:["state",!1]},commandJournal:{commandId:["commandId",!0],runId:["identity.runId",!1],runOwnerState:[["identity.runId","identity.ownerEpoch","state"],!1]},pageSnapshots:{snapshotId:["snapshotId",!0],runSealSeq:[["runId","sealSeq"],!1],runPageSequence:[["runId","pageSequence"],!0],readCommandId:["readCommandId",!1]},records:{snapshotRow:[["snapshotId","rowIndex"],!0],runId:["runId",!1]},batches:{batchId:["batchId",!0],snapshotBatch:[["snapshotId","batchIndex"],!0]},exportJobs:{exportJobId:["exportJobId",!0],runId:["runId",!1]},artifacts:{artifactId:["artifact.artifactId",!0],exportJobId:["artifact.exportJobId",!1]},downloadReceipts:{downloadId:["attempt.downloadId",!0],fullBlobUrl:["fullBlobUrl",!1]},entitlements:{subject:["subject",!0]}})
Object.freeze(Object.keys(V))
const K=Object.freeze({...V,commandJournal:{...V.commandJournal,commandId:[["identity.runId","commandId"],!0]},scriptHeads:{},scriptRevisions:{},results:{},frameworkKV:{}})
function B(e){if(e instanceof C)return e
const t=new C("QuotaExceededError"===e?.name?"E_QUOTA":"E_SCHEMA","QuotaExceededError"===e?.name?"Storage quota exceeded":"IndexedDB operation failed")
return t.cause=e,t}function G(e,t=!1,a=new Set){if(null===e)return P(!t,"E_VERSION","Invalid backup key"),{type:"null"}
if(void 0===e)return P(!t,"E_VERSION","Invalid backup key"),{type:"undefined"}
if("string"==typeof e||"boolean"==typeof e)return P(!t||"string"==typeof e,"E_VERSION","Invalid backup key"),{type:typeof e,value:e}
if("number"==typeof e)return P(!t||!Number.isNaN(e),"E_VERSION","Invalid backup key"),{type:"number",value:Object.is(e,-0)?"-0":e+""}
if(e instanceof Date)return P(Number.isFinite(e.getTime()),"E_VERSION","Invalid backup date"),{type:"date",value:e.getTime()}
if(e instanceof ArrayBuffer||ArrayBuffer.isView(e)){const a=e instanceof ArrayBuffer?new Uint8Array(e):new Uint8Array(e.buffer,e.byteOffset,e.byteLength)
return P(t||e instanceof ArrayBuffer,"E_VERSION","Unsupported backup value view"),{type:"binary",value:Array.from(a)}}let n
return P("object"==typeof e&&!a.has(e),"E_VERSION","Unsupported or cyclic backup value"),a.add(e),Array.isArray(e)?(P(Object.keys(e).length===e.length&&Array.from({length:e.length},((t,a)=>Object.hasOwn(e,a))).every(Boolean),"E_VERSION","Unsupported sparse backup array"),n={type:"array",value:e.map((e=>G(e,t,a)))}):(P(!t&&(Object.getPrototypeOf(e)===Object.prototype||null===Object.getPrototypeOf(e)),"E_VERSION","Unsupported backup value"),n={type:"object",value:Object.keys(e).sort().map((t=>[t,G(e[t],!1,a)]))}),a.delete(e),n}function J(e){switch(e.type){case"null":return null
case"undefined":return
case"number":return Number(e.value)
case"string":case"boolean":return e.value
case"date":return new Date(e.value)
case"binary":return new Uint8Array(e.value).buffer
case"array":return e.value.map(J)
case"object":return Object.fromEntries(e.value.map((([e,t])=>[e,J(t)])))
default:throw new C("E_VERSION","Invalid backup encoding")}}function $(e){return JSON.stringify({format:"opendesk.raw-backup.v1",name:e.name,version:e.version,stores:e.stores.map((e=>({name:e.name,records:e.records.map((e=>({key:G(e.key,!0),value:G(e.value)})))})))})}async function Y(e,{readOnly:t=!1}={}){const a=Array.from(e.objectStoreNames),n={name:e.name,version:e.version,readOnly:t,stores:a.length?await Q(e,a,"readonly",null,{raw:!0}):[]},r=$(n),i=(new TextEncoder).encode(r),o=Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",i)),(e=>e.toString(16).padStart(2,"0"))).join("")
return P($(function(e){const t=JSON.parse(e)
return P("opendesk.raw-backup.v1"===t.format,"E_VERSION","Unsupported backup format"),{name:t.name,version:t.version,stores:t.stores.map((e=>({name:e.name,records:e.records.map((e=>({key:J(e.key),value:J(e.value)})))})))}}(r))===r,"E_VERSION","Backup roundtrip failed"),{...n,encoding:{format:"opendesk.raw-backup.v1",utf8:r,byteLength:i.length,sha256:o}}}function Z(e,t,a,n,r){return new Promise(((i,o)=>{let s,c,d=!1,l=0
try{s=void 0===a?e.open(t):e.open(t,a)}catch(u){return void o(u)}s.onupgradeneeded=e=>{if(l=e.oldVersion,d){try{s.transaction.abort()}catch{}return}const t=e=>{c||=e
try{s.transaction.abort()}catch{}}
try{P(n,"E_VERSION","Cannot create a recovery database")
const e=()=>function(e,t,a){P(1===e.version||2===e.version,"E_VERSION","No reviewed migration exists for this database version")
const n=1===e.version?V:K
if(1===a&&2===e.version){const e=t.objectStore("commandJournal")
P(e.indexNames.contains("commandId"),"E_VERSION","Missing legacy command index")
const a=e.index("commandId")
P("commandId"===a.keyPath&&a.unique&&!a.multiEntry,"E_VERSION","Incompatible legacy command index"),e.deleteIndex("commandId")}for(const[r,i]of Object.entries(n)){const a=e.objectStoreNames.contains(r)?t.objectStore(r):e.createObjectStore(r)
P(null===a.keyPath&&!a.autoIncrement,"E_VERSION","Storage requires explicit keys")
for(const[e,[t,n]]of Object.entries(i))if(a.indexNames.contains(e)){const r=a.index(e)
P(JSON.stringify(r.keyPath)===JSON.stringify(t)&&r.unique===n&&!r.multiEntry,"E_VERSION","Incompatible storage index")}else a.createIndex(e,t,{unique:n})}}(s.result,s.transaction,l)
1===l&&2===s.result.version?function(e,t,a,n,r,i){const o=Array.from(e.objectStoreNames),s=[],c={count:o.length},d=()=>{try{P(n&&n.version===a&&n.name===e.name,"E_VERSION","Missing migration backup"),P($({name:e.name,version:a,stores:s})===n.encoding.utf8,"E_VERSION","Database changed after migration backup"),r()}catch(u){i(u)}}
if(o.length)for(const l of o){const e=[],a=t.objectStore(l).openCursor()
s.push({name:l,records:e}),a.onerror=()=>i(a.error),a.onsuccess=()=>{const t=a.result
t?(e.push({key:t.primaryKey,value:t.value}),t.continue()):0==--c.count&&d()}}else d()}(s.result,s.transaction,l,r,e,t):e()}catch(u){t(u)}},s.onblocked=()=>{d=!0
const e=new C("E_VERSION","Storage upgrade blocked by another connection")
e.blocked=!0,e.migrationBackup=r,o(e)},s.onerror=()=>{if(d)return
d=!0
const e=c||s.error||new C("E_VERSION","Storage upgrade failed")
e.previousVersion=l,o(e)},s.onsuccess=()=>{d?s.result.close():(d=!0,i(s.result))}}))}function Q(e,t,a,n,{raw:r=!1}={}){return new Promise(((i,o)=>{let s,c,d,l=!1,u=!1
const p=[]
try{s=e.transaction(t,a)}catch(y){return void o(B(y))}const m=e=>new Promise(((t,a)=>{u||l?a(new C("E_SCHEMA","Transaction already finished")):p.push({action:e,yes:t,no:a})})),f=e=>(P(t.includes(e),"E_SCHEMA","Store outside transaction scope"),s.objectStore(e)),g=e=>P(null!=e,"E_SCHEMA","Explicit key required"),I=Object.freeze({get:(e,t)=>m((()=>(g(t),f(e).get(t)))),put:(e,t,a)=>m((()=>(g(a),f(e).put(t,a)))),delete:(e,t)=>m((()=>(g(t),f(e).delete(t)))),all:e=>m((()=>f(e).getAll()))}),w=e=>{d||=e
try{s.abort()}catch{}},h=e=>{u=!0
for(const t of p.splice(0))t.no(e||new C("E_SCHEMA","Transaction finished"))
e?o(e):i(c)}
s.onabort=()=>h(B(d||s.error)),s.onerror=()=>{d||=s.error},s.oncomplete=()=>h(l?d:new C("E_SCHEMA","Transaction completed before work"))
const E=()=>{if(!u){for(const e of p.splice(0))try{const t=e.action()
t.onsuccess=()=>e.yes(t.result),t.onerror=()=>{const a=t.error
e.no(B(a)),w(a)}}catch(y){return e.no(B(y)),void w(y)}if(!l)try{const e=s.objectStore(t[0]).get("@storage-keepalive")
e.onsuccess=E,e.onerror=()=>w(e.error)}catch(y){w(y)}}}
r?Promise.all(t.map((e=>new Promise(((t,a)=>{const n=[],r=s.objectStore(e).openCursor()
r.onerror=()=>a(r.error),r.onsuccess=()=>{const a=r.result
a?(n.push({key:a.primaryKey,value:a.value}),a.continue()):t({name:e,records:n})}}))))).then((e=>{c=e,l=!0}),w):(E(),Promise.resolve().then((()=>n(I))).then((e=>{c=e,l=!0}),w))}))}function X(e){return t=e.identity?.runId,a=e.commandId,P("string"==typeof t&&t.length>0&&"string"==typeof a&&a.length>0,"E_SCHEMA","Command keys require a run and command ID"),"command:"+H([t,a])
var t,a}Object.freeze(Object.keys(K))
const ee="opendesk.value.v1",te=new TextEncoder,ae={maxDepth:12,maxBytes:N.maxBatchBytes}
function ne({profile:e="foundation",ErrorType:t,maxDepth:a=12,maxBytes:n=262144}={}){const r="control"===e,i=Reflect.apply,o=Object.prototype,s=Object.keys,c=Object.getOwnPropertyNames,d=Object.getOwnPropertySymbols,l=Object.getOwnPropertyDescriptor,u=Object.getPrototypeOf,p=Object.hasOwn,m=Object.defineProperty,f=Object.freeze,g=Array.isArray,I=Array.prototype.sort,w=Number.isFinite,h=Object.is,E=JSON.stringify,y=String.prototype.charCodeAt,b=Set,v=Error,_=Set.prototype.has,S=Set.prototype.add,A=Set.prototype.delete,O=new TextEncoder,k=O.encode,T=r?"t":"type",R=r?"v":"value"
function N(e,a,n=!1){const i=r&&"decode"===e&&!n?"E_RESULT_FORMAT":"E_VALUE_SERIALIZATION",o=t?new t(i,a):new v(a)
throw t||(o.name=r?"PageError":"FoundationError",o.code=i),r||(o.stage=e),o}function C(e,t="encode"){"string"!=typeof e&&N(t,"Expected a string")
for(let a=0;a<e.length;a++){const n=i(y,e,[a])
if(n>=55296&&n<=56319){const n=i(y,e,[++a])
n>=56320&&n<=57343||N(t,"Unpaired UTF-16 surrogate")}else n>=56320&&n<=57343&&N(t,"Unpaired UTF-16 surrogate")}return e}function U(e={}){return{maxDepth:r?a:e.maxDepth??a,maxBytes:e.maxBytes??n}}function P(e,t,a){let n
try{n=E(e)}catch{N(a,"Wire value is not JSON",!0)}return i(k,O,[n]).byteLength>t.maxBytes&&N(a,"Wire byte budget exceeded",!0),e}function D(e,t,a){const n=l(e,t)
if(n)return p(n,"value")||N(a,"Accessors are not supported"),n.value}function x(e,t,a=!1){e&&"object"==typeof e&&g(e)===a||N(t,"Invalid wire shape"),d(e).length&&N(t,"Symbol keys are not supported")
const n=c(e)
for(let r=0;r<n.length;r++)D(e,n[r],t)}function L(e,t){if(!r){s(e).length!==t.length&&N("decode","Invalid wire shape")
for(let a=0;a<t.length;a++)p(e,t[a])||N("decode","Invalid wire shape")}}function H(e,t,a=!0){return a?{[T]:e,[R]:t}:{[T]:e}}function M(e,t){const a=U(t),n=new b
return P(function e(t,c){if(c>a.maxDepth&&N("encode","Value depth exceeded"),void 0===t)return H("undefined",void 0,!1)
if(null===t)return H("null",void 0,!1)
if("string"==typeof t)return H("string",C(t))
if("boolean"==typeof t)return H("boolean",t)
if("number"==typeof t&&w(t))return h(t,-0)?r?H("negative-zero",void 0,!1):{type:"number",value:0,negativeZero:!0}:H("number",t)
t&&"object"==typeof t||N("encode","Value is not serializable"),i(_,n,[t])&&N("encode","Cyclic value")
const l=g(t)
l||u(t)===o||null===u(t)||N("encode","Only plain objects are supported"),d(t).length&&N("encode","Symbol keys are not supported"),i(S,n,[t])
const p=[]
if(l)for(let a=0;a<t.length;a++)p[a]=e(D(t,a,"encode"),c+1)
else{const a=s(t)
r||i(I,a,[])
for(let n=0;n<a.length;n++)p[n]=[C(a[n]),e(D(t,a[n],"encode"),c+1)]}return i(A,n,[t]),H(l?"array":"object",p)}(e,0),a,"encode")}return"foundation"===e||r||N("encode","Unknown value wire profile"),f({encodeValue:M,decodeValue:function(e,t){const a=U(t)
let n=0
const o=function e(t,o){(o>a.maxDepth||++n>65536)&&N("decode","Value depth or node budget exceeded"),x(t,"decode")
const s=D(t,T,"decode")
if("undefined"===s||"null"===s||r&&"negative-zero"===s)return L(t,[T]),"undefined"===s?void 0:"null"===s?null:-0
const c=!r&&"number"===s&&p(t,"negativeZero")
L(t,c?[T,R,"negativeZero"]:[T,R])
const d=D(t,R,"decode")
if("string"===s)return C(d,"decode")
if("boolean"===s)return"boolean"!=typeof d&&N("decode","Invalid boolean"),d
if("number"===s)return"number"==typeof d&&w(d)||N("decode","Invalid number"),c?(0===d&&!0===D(t,"negativeZero","decode")||N("decode","Invalid negative zero"),-0):d
"array"!==s&&"object"!==s&&N("decode","Unknown value tag"),x(d,"decode",!0)
const l="array"===s?[]:{},u=new b
for(let a=0;a<d.length;a++){const t=D(d,a,"decode")
if("array"===s)l[a]=e(t,o+1)
else{x(t,"decode",!0),2!==t.length&&N("decode","Invalid object entry")
const a=C(D(t,0,"decode"),"decode")
i(_,u,[a])&&N("decode","Duplicate object key"),i(S,u,[a]),m(l,a,{value:e(D(t,1,"decode"),o+1),enumerable:!0,writable:!0,configurable:!0})}}return l}(e,0)
return r?M(o,t):P(e,a,"decode"),o},validateString:C})}const re=ne({ErrorType:C,...ae}),ie=re.encodeValue,oe=re.decodeValue
function se(e,t){const a=new C("E_VALUE_SERIALIZATION",t)
throw a.stage=e,a}function ce(e,t,a){e&&"object"==typeof e&&!Array.isArray(e)&&Object.keys(e).length===t.length&&t.every((t=>Object.hasOwn(e,t)))||se(a,"Invalid wire shape")}function de(e,t){return re.validateString(e,t)}function le(e,t,a){let n
try{n=JSON.stringify(e)}catch{se(a,"Wire value is not JSON")}return te.encode(n).byteLength>t.maxBytes&&se(a,"Wire byte budget exceeded"),e}function ue(e,t={}){if(!0===e?.ok)return ce(e,["ok","value"],"outcome"),le({protocol:ee,ok:!0,value:ie(e.value,t)},{...ae,...t},"outcome")
ce(e,["ok","error"],"outcome"),!1!==e.ok&&se("outcome","Invalid outcome status")
const a=e.error,n={name:(a?.name||"Error")+"",code:(a?.code||"E_PAGE_EXECUTION")+"",message:(a?.message??a)+""}
for(const r of Object.values(n))de(r,"outcome")
return le({protocol:ee,ok:!1,error:n},{...ae,...t},"outcome")}function pe(e,t={}){if(e?.protocol!==ee&&se("outcome","Unknown outcome protocol"),le(e,{...ae,...t},"outcome"),!0===e.ok)return ce(e,["protocol","ok","value"],"outcome"),{ok:!0,value:oe(e.value,t)}
ce(e,["protocol","ok","error"],"outcome"),!1!==e.ok&&se("outcome","Invalid outcome status"),ce(e.error,["name","code","message"],"outcome")
for(const a of Object.values(e.error))de(a,"outcome")
return{ok:!1,error:{...e.error}}}const me=(e,t)=>JSON.stringify(ie(e,t))
function fe(e,{maxBytes:t=N.maxRawFrameBytes}={}){e instanceof Uint8Array&&!(e.byteLength>t)||se("base64","Invalid or oversized bytes")
let a=""
for(const n of e)a+=String.fromCharCode(n)
return btoa(a)}const ge="commandJournal",Ie=Object.freeze({slot:"@slot",host:e=>"host:"+e,templateHead:e=>"head:"+e,templateRevision:(e,t)=>`${e}:${t}`,begin:(e,t)=>`begin:${e}:${t}`,reader:e=>"reader:"+e,tombstone:e=>"tombstone:"+e,retention:e=>"retention:"+e,migration:e=>"migration:"+e}),we=new TextEncoder,he=e=>structuredClone(e)
Ie.templateHead,Ie.templateRevision
const Ee=e=>P("string"==typeof e&&/^[A-Za-z0-9._:-]{1,128}$/.test(e),"E_SCHEMA","Invalid id"),ye=["frameworkKV",ge,"results","runs"],be=(e,t,a)=>"kv:"+H([e,t,a]),ve=(e,t,a)=>"script:"+H(void 0===a?[e,t]:[e,t,a]),_e=(e,t,a)=>"script-pin:"+H([e.namespace,e.runId,e.opId,t,a]),Se=["namespace","principal","grantIncarnation","runId","opId","requestId","resultId","browserSessionIncarnation"],Ae=new WeakMap,Oe="1.0.0",ke=Object.freeze({relay:"agents/page-relay.js",main:"framework/sdk-main.js"}),Te=Object.freeze({pending:100,requestBytes:65536,responseBytes:262144,timeoutMs:3e4,maxTimeoutMs:6e4,serviceBudgetMs:15e3}),Re=(e,t=e,a={})=>{const n=new C(e,t)
return Object.assign(n,a),n}
function Ne(e,t="E_SCHEMA"){if(!e||"object"!=typeof e||Array.isArray(e)||![Object.prototype,null].includes(Object.getPrototypeOf(e)))throw Re(t,"Expected plain object")
return e}function Ce(e,t,a=[],n="E_SCHEMA"){if(Ne(e,n),Object.keys(e).some((e=>!t.includes(e)))||a.some((t=>!Object.hasOwn(e,t))))throw Re(n,"Unknown or missing argument")}function Ue(e){if("string"!=typeof e||!e.length||e.length>256||["__proto__","constructor","prototype"].includes(e))throw Re("E_SCHEMA","Unsafe storage key")
return e}function Pe(e,t=new Set,a=0){if(a>12)throw Re("E_VALUE_SERIALIZATION","Value exceeds depth limit")
if(null==e||"string"==typeof e||"boolean"==typeof e)return e
if("number"==typeof e&&Number.isFinite(e))return e
if(!e||"object"!=typeof e||t.has(e))throw Re("E_VALUE_SERIALIZATION","Expected JSON value or undefined")
t.add(e),Array.isArray(e)||Ne(e,"E_VALUE_SERIALIZATION")
for(const n of Object.keys(e)){if(["__proto__","constructor","prototype"].includes(n))throw Re("E_VALUE_SERIALIZATION","Unsafe object key")
Pe(e[n],t,a+1)}return t.delete(e),e}function De(e){let t
try{t=new URL(e)}catch{throw Re("E_SCHEMA","Expected absolute HTTP URL")}if(!["http:","https:"].includes(t.protocol)||t.username||t.password)throw Re("E_SCHEMA","Unsupported URL")
return t.href}function xe(e={}){Ce(e,["params","headers","timeout","responseType","withCredentials"],[],"E_CONFIG_UNSUPPORTED")
const t={}
if(void 0!==e.params){Ne(e.params,"E_CONFIG_UNSUPPORTED"),t.params={}
for(const[a,n]of Object.entries(e.params)){if(Ue(a),(Array.isArray(n)?n:[n]).some((e=>null!=e&&!["string","number","boolean"].includes(typeof e)||"number"==typeof e&&!Number.isFinite(e))))throw Re("E_CONFIG_UNSUPPORTED","Unsupported query parameter")
t.params[a]=n}}if(void 0!==e.headers){Ne(e.headers,"E_CONFIG_UNSUPPORTED"),t.headers={}
for(const[a,n]of Object.entries(e.headers)){if(!/^[!#$%&'*+.^_`|~0-9a-z-]+$/i.test(a)||"string"!=typeof n||/[\r\n]/.test(n)||/^(cookie|authorization|proxy-authorization|host|origin|referer|sec-.*)$/i.test(a))throw Re("E_CONFIG_UNSUPPORTED","Unsupported header")
t.headers[a.toLowerCase()]=n}}if(void 0!==e.timeout){if(!Number.isInteger(e.timeout)||e.timeout<1||e.timeout>Te.maxTimeoutMs)throw Re("E_CONFIG_UNSUPPORTED","Invalid timeout")
t.timeout=e.timeout}if(void 0!==e.responseType){if(!["json","text"].includes(e.responseType))throw Re("E_CONFIG_UNSUPPORTED","Unsupported responseType")
t.responseType=e.responseType}if(void 0!==e.withCredentials){if(!1!==e.withCredentials)throw Re("E_CONFIG_UNSUPPORTED","Credentials are unavailable to page SDK")
t.withCredentials=!1}return t}const Le=(e,t=!1)=>(Ce(e,t?["key","value"]:["key"],t?["key","value"]:["key"]),Ue(e.key),Pe(e),e),He=(e,t=!1)=>{Ce(e,t?["url","data","config"]:["url","config"],["url"])
const a={url:De(e.url),config:xe(e.config)}
return t&&Object.hasOwn(e,"data")&&(Pe(e.data),a.data=e.data),a},Me=e=>(Ce(e,[]),e),je=(e,t,a)=>Object.freeze({capability:e,effect:t,normalize:a}),qe=Object.freeze({AXIOS_GET:je("network","read",(e=>He(e))),AXIOS_POST:je("network","write",(e=>He(e,!0))),AXIOS_PUT:je("network","write",(e=>He(e,!0))),AXIOS_DELETE:je("network","write",(e=>He(e))),APPSTORAGE_GETITEM:je("storage.persistent","read",(e=>Le(e))),APPSTORAGE_SETITEM:je("storage.persistent","write",(e=>(Le(e,!0),{key:e.key,value:e.value+""}))),APPSTORAGE_REMOVEITEM:je("storage.persistent","write",(e=>Le(e))),APPSTORAGE_CLEAR:je("storage.persistent","write",Me),APPLOCAL_GETITEM:je("storage.session","read",(e=>Le(e))),APPLOCAL_SETITEM:je("storage.session","write",(e=>Le(e,!0))),APPLOCAL_REMOVEITEM:je("storage.session","write",(e=>Le(e))),CHROME_LOCAL_CLEAR:je("storage.persistent","write",Me),CHROME_LOCAL_GET:je("storage.persistent","read",(e=>(Ce(e,["key"],["key"]),null!==e.key&&Ue(e.key),e))),CHROME_LOCAL_SET:je("storage.persistent","write",(e=>(Ce(e,["values"],["values"]),Ne(e.values),Object.keys(e.values).forEach(Ue),Pe(e.values),e))),CHROME_LOCAL_REMOVE:je("storage.persistent","write",(e=>{Ce(e,["keys"],["keys"])
const t="string"==typeof e.keys?[e.keys]:e.keys
if(!Array.isArray(t)||t.length>100)throw Re("E_SCHEMA")
return t.forEach(Ue),{keys:t}})),CREATE_NOTIFY:je("notifications","write",(e=>{if(Ce(e,["title","content"],["title","content"]),"string"!=typeof e.title||"string"!=typeof e.content||e.title.length>256||e.content.length>4096)throw Re("E_SCHEMA")
return e})),SERVER_CHECK:je("network","read",(e=>{Ce(e,["server","timeout"],["server"])
const t=xe({timeout:e.timeout??5e3})
return{server:De(e.server),timeout:t.timeout}})),DEVICE_GET_APP_ID:je("device.id","write",Me),NETWORK_INFO_GET:je("network.info","read",(e=>{if(Ce(e,["ip"]),void 0!==e.ip&&"string"!=typeof e.ip)throw Re("E_SCHEMA")
return e}))}),Fe=Object.freeze({log:je("service.log","write",(e=>{if(Ce(e,["message","data"],["message"]),"string"!=typeof e.message||Object.hasOwn(e,"data")&&!Array.isArray(e.data))throw Re("E_SCHEMA")
if((new TextEncoder).encode(e.message).byteLength>4096||(e.data?.length??0)>100)throw Re("E_LIMIT")
return e.data&&Pe(e.data),e})),getTime:je("service.time","read",Me),bexUrl:je("resources.packaged","read",Me),requestResource:je("resources.packaged","read",(e=>{if(Ce(e,["url"],["url"]),"string"!=typeof e.url||!e.url||e.url.length>1024)throw Re("E_SCHEMA")
return e}))}),We=Object.freeze({...qe,...Fe})
function ze(e,t={}){if(!Object.hasOwn(We,e))throw Re("E_SERVICE_UNSUPPORTED","Unknown SDK service")
return We[e].normalize(t)}function Ve(e){if(Ce(e,["requestId","method","args","deadlineAt"],["requestId","method","args","deadlineAt"]),"string"!=typeof e.requestId||!/^[a-zA-Z0-9:_-]{1,128}$/.test(e.requestId)||!Number.isSafeInteger(e.deadlineAt))throw Re("E_SCHEMA")
return{...e,args:ze(e.method,e.args)}}function Ke(e,t,a,...n){return"function"!=typeof t?.[a]?Promise.reject(Re("E_CAPABILITY",`Chrome ${a} unavailable`)):new Promise(((r,i)=>{try{t[a](...n,(t=>{try{!function(e=globalThis.chrome){const t=e?.runtime?.lastError
if(t)throw Re("E_CHROME",t.message)}(e),r(t)}catch(a){i(a)}}))}catch(o){i(o.code?o:Re("E_CHROME",o.message))}}))}const Be=new WeakMap
function Ge({api:e}){const t=e?.storage?.session
if(P(t,"E_RESOURCE_UNAVAILABLE","Native storage.session unavailable"),Be.has(t))return Be.get(t)
const a=Object.freeze({async executeSdk(a,n,r){P(["APPLOCAL_GETITEM","APPLOCAL_SETITEM","APPLOCAL_REMOVEITEM"].includes(a),"E_CAPABILITY","Unsupported session storage method"),P(r?.namespace&&r.browserSessionIncarnation&&"function"==typeof r.recordNativeReceipt&&"function"==typeof r.recordEffect,"E_OWNER","Session storage requires the original authority context")
const i="framework-session:"+H([r.browserSessionIncarnation,r.namespace,n.key]),o="APPLOCAL_SETITEM"===a?ie(n.value):void 0
let s
if(await r.authorize({capability:"storage.session",phase:"pre"}),r.assertDispatch?.(),"APPLOCAL_GETITEM"===a){const a=await Ke(e,t,"get",i)
s=Object.hasOwn(a,i)?oe(a[i]):void 0}else"APPLOCAL_SETITEM"===a?await Ke(e,t,"set",{[i]:o}):await Ke(e,t,"remove",i)
return await r.recordNativeReceipt({method:a,value:s}),await r.recordEffect(s),await r.authorize({capability:"storage.session",phase:"post"}),s}})
return Be.set(t,a),a}globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome
const Je="E_TARGET"
function $e(e){let t
try{t=new URL(e)}catch{P(!1,Je,"Invalid document URL")}return P(["https:","http:"].includes(t.protocol)&&!t.username&&!t.password,Je,"HTTP(S) URL required"),t.hash="",t}async function Ye(e,t){const a=$e(t)
P(await e.permissions.contains({origins:[`${a.protocol}//${a.hostname}/*`]}),"E_PERMISSION","Formal execution requires an optional origin grant")}async function Ze({api:e,tabId:t,frameId:a=0,documentId:n,allowExtensionUrl:r=null,expectedUrl:i,expectedWindowId:o}){P(Number.isSafeInteger(t)&&t>=0&&Number.isSafeInteger(a)&&a>=0,Je)
const s=await e.tabs.get(t),c=async()=>{if(void 0===o)return
const a=await e.tabs.query({active:!0,windowId:o})
P(1===a.length&&a[0].id===t&&a[0].windowId===o&&a[0].active&&!a[0].incognito&&!a[0].pendingUrl&&"loading"!==a[0].status&&"unloaded"!==a[0].status&&a[0].url===i,"E_DOCUMENT_STALE","Captured window Current Page changed before admission")}
await c(),P(s&&!1===s.incognito,Je,"A normal selected tab is required")
const d=await e.webNavigation.getAllFrames({tabId:t})
let l=d?.find((e=>e.frameId===a&&(!n||e.documentId===n)))
if(!l&&null!==r&&0===a&&"function"==typeof e.runtime.getContexts){const a=(await e.runtime.getContexts({})).filter((e=>e.tabId===t&&0===e.frameId&&e.documentUrl===r&&(!n||e.documentId===n)))
1===a.length&&(l={frameId:0,documentId:a[0].documentId,url:a[0].documentUrl})}if(P(l&&!l.errorOccurred&&(!l.documentLifecycle||"active"===l.documentLifecycle)&&"string"==typeof l.documentId&&l.documentId,void 0===o?"E_DOCUMENT_REPLACED":"E_DOCUMENT_STALE","Selected frame document is no longer current"),null!==r)return P(0===a&&l.url===r&&s.url===r,Je,"Owned bootstrap URL differs"),{tabId:t,frameId:0,documentId:l.documentId,url:l.url}
const u=$e(l.url)
P(void 0===i||!s.pendingUrl&&u.href===$e(i).href&&(0!==a||s.url===i),"E_DOCUMENT_STALE","Captured page is navigating or its URL changed"),P(0===a?$e(s.url).origin===u.origin&&(!s.pendingUrl||$e(s.pendingUrl).origin===u.origin):!s.pendingUrl,"E_DOCUMENT_REPLACED","Selected tab is navigating outside its document"),await Ye(e,u.origin),await c()
const p=d.find((e=>0===e.frameId))
return P(p&&"string"==typeof p.documentId&&p.documentId,"E_DOCUMENT_REPLACED"),{tabId:t,frameId:a,documentId:l.documentId,url:l.url,allowedOrigin:u.origin,...void 0===o?{}:{windowId:o},...a>0?{rootDocumentId:p.documentId}:{}}}async function Qe({api:e,target:t,expectedUrl:a,expectedWindowId:n}){P(Number.isSafeInteger(t?.frameId)&&t.frameId>=0,Je)
const r=await Ze({api:e,tabId:t.tabId,frameId:t.frameId,documentId:t.documentId,expectedUrl:a,expectedWindowId:n})
return P(r.allowedOrigin===t.allowedOrigin,Je,"Controller origin differs"),t.rootDocumentId&&P(t.rootDocumentId===r.rootDocumentId,"E_DOCUMENT_REPLACED"),r}async function Xe(e){P(e instanceof Uint8Array,"E_SCHEMA","Artifact bytes must be Uint8Array")
const t=await globalThis.crypto.subtle.digest("SHA-256",e)
return[...new Uint8Array(t)].map((e=>e.toString(16).padStart(2,"0"))).join("")}function et(e,t=Date.now(),{readerPinned:a=!1}={}){return!a&&(!!["complete","interrupted","abandoned"].includes(e.state)||null!==e.downloadDeadline&&Number(t)>=Date.parse(e.downloadDeadline))}const tt="exportJobs",at="commandJournal",nt="downloadReceipts",rt=["runs",at,tt,"artifacts",nt],it=[...rt,"results"],ot=e=>"controller-artifact"===e?.kind,st=["application/json","text/plain;charset=utf-8","application/octet-stream"],ct=["preparing","ready","delivering","delivery_complete","delivery_partial","delivery_unknown","delivery_failed","abandoned"],dt=e=>P("string"==typeof e&&/^[A-Za-z0-9._:-]{1,128}$/.test(e),"E_SCHEMA","Invalid artifact id"),lt=(e,t)=>`${e}:${t}`,ut=e=>lt("export-intent",e),pt=e=>lt("export",e),mt=e=>lt("reader",pt(e)),ft=e=>["complete","interrupted","abandoned","conflict"].includes(e),gt=e=>["abandoned","conflict"].includes(e),It=e=>new Date(e).toISOString(),wt=e=>structuredClone(e)
function ht(e,t){P(e&&"object"==typeof e&&!Array.isArray(e),"E_SCHEMA","Expected object"),P(Object.keys(e).length===t.length&&t.every((t=>Object.hasOwn(e,t))),"E_SCHEMA","Unexpected request fields")}function Et(e){P("string"==typeof e&&e.length>0&&e.length<=128&&!/[\\/\u0000-\u001f\u007f]/.test(e)&&![".",".."].includes(e),"E_SCHEMA","Filename must be a safe basename")}function yt(e){if(!ot(e))return F(A,"ExportJob",e)
ht(e,["kind","exportJobId","runId","resultId","namespace","principal","format","artifactIds","activeAttemptIds","state"])
for(const t of["exportJobId","runId","resultId"])dt(e[t])
P("string"==typeof e.namespace&&e.namespace&&"string"==typeof e.principal&&e.principal&&["typed-json","data"].includes(e.format)&&ct.includes(e.state),"E_SCHEMA","Invalid controller artifact job"),P(Array.isArray(e.artifactIds)&&1===e.artifactIds.length&&Array.isArray(e.activeAttemptIds)&&e.activeAttemptIds.length<=1,"E_SCHEMA","Generic job requires one artifact and at most one active attempt")
for(const t of[...e.artifactIds,...e.activeAttemptIds])dt(t)
return P(e.activeAttemptIds.length>0||["preparing","abandoned"].includes(e.state),"E_SCHEMA","Missing active artifact attempt"),e}function bt(e){if(!ot(e))return F(O,"Artifact",e)
ht(e,["kind","artifactId","exportJobId","runId","resultId","namespace","principal","format","mime","bytes","byteCount","sha256","storageEncoding","chunkKeys","filename"])
for(const t of["artifactId","exportJobId","runId","resultId"])dt(e[t])
return Et(e.filename),P("string"==typeof e.namespace&&e.namespace&&"string"==typeof e.principal&&e.principal&&["typed-json","data"].includes(e.format)&&st.includes(e.mime)&&("typed-json"!==e.format||"application/json"===e.mime),"E_SCHEMA","Invalid generic artifact type"),P(Number.isSafeInteger(e.bytes)&&e.bytes>=0&&e.bytes<=N.maxArtifactBytes&&e.byteCount===e.bytes&&/^[a-f0-9]{64}$/.test(e.sha256)&&"Uint8Array-chunks"===e.storageEncoding,"E_SCHEMA","Invalid generic artifact bytes"),P(Array.isArray(e.chunkKeys)&&e.chunkKeys.length>=1&&e.chunkKeys.length<=64&&new Set(e.chunkKeys).size===e.chunkKeys.length,"E_SCHEMA","Artifact exceeds chunk budget"),e.chunkKeys.forEach(dt),e}function vt(e){const t=new TypeError(e)
throw t.code="E_SCHEMA",t}function _t(e){let t;("string"!=typeof e||0===e.length||e.length>2048)&&vt("An SDK target must be a nonempty origin string within the length budget"),!/[\u0000-\u0020\u007f-\u009f\s\\@*?#%]/u.test(e)&&/^https?:\/\/[^/]+\/?$/i.test(e)||vt("SDK origins require HTTP(S), without credentials, wildcards, paths, query or fragment")
try{t=new URL(e)}catch{vt("Invalid SDK target origin")}return(!["http:","https:"].includes(t.protocol)||!t.hostname||"null"===t.origin||t.username||t.password||"/"!==t.pathname||t.search||t.hash)&&vt("Only exact HTTP(S) origins can be approved"),t.origin}function St(e,t=[]){const a=_t(e);(!Array.isArray(t)||t.length>8)&&vt("SDK approval accepts at most 8 additional origin entries")
const n=[...new Set(Array.from(t,_t))].filter((e=>e!==a)).sort()
return Object.freeze({sourceOrigin:a,targetOrigins:Object.freeze(n),allowedOrigins:Object.freeze([a,...n].sort())})}function At(e,t){let a
try{a=new URL(e)}catch{return null}return!["http:","https:"].includes(a.protocol)||a.username||a.password?null:0===t&&"http:"===a.protocol&&"127.0.0.1"===a.hostname&&["43111","43112"].includes(a.port)&&"/demo-form.html"===a.pathname?["https://httpbingo.org","https://api.ipify.org"]:[]}const Ot="commandJournal",kt="E_PERMISSION",Tt="E_EFFECT_UNKNOWN",Rt="E_GRANT_REVOKED",Nt="effect_unknown",Ct="http://whois.pconline.com.cn/ipJson.jsp?json=true"
function Ut(e,t){return new Promise(((a,n)=>{if(t.aborted)return void n(t.reason)
const r=()=>{t.removeEventListener("abort",r),n(t.reason)}
t.addEventListener("abort",r,{once:!0}),Promise.resolve(e).then((e=>{t.removeEventListener("abort",r),a(e)}),(e=>{t.removeEventListener("abort",r),n(e)}))}))}function Pt({fetchImpl:e=globalThis.fetch,authorize:t,clock:a=Date,maxResponseBytes:n=Te.responseBytes,setTimer:r=setTimeout,clearTimer:i=clearTimeout,networkInfoEnabled:o=!1}={}){async function s({method:o,url:s,data:c,config:d},l={}){if(!["GET","POST","PUT","DELETE"].includes(o))throw Re("E_SERVICE_UNSUPPORTED")
const u=xe(d)
void 0!==c&&Pe(c)
const p=new URL(De(s))
for(const[e,t]of Object.entries(u.params??{}))if(null!=t)for(const a of Array.isArray(t)?t:[t])null!=a&&p.searchParams.append(Array.isArray(t)?e+"[]":e,a+"")
if(!t)throw Re("E_PERMISSION","HTTP driver requires broker authorization")
if(l.signal?.aborted)throw Re("E_CANCELLED")
const m=new AbortController,f=()=>m.abort(Re("E_CANCELLED"))
l.signal?.addEventListener("abort",f,{once:!0})
const g=Math.min(u.timeout??Te.serviceBudgetMs,Te.serviceBudgetMs,void 0===l.deadlineAt?Te.maxTimeoutMs:l.deadlineAt-a.now())
if(g<=0)throw l.signal?.removeEventListener("abort",f),Re("E_TIMEOUT")
const I=r((()=>m.abort(Re("E_TIMEOUT"))),g)
try{await Ut(t({capability:"network",url:p.href,method:o,phase:"pre"},l),m.signal)
const a={...u.headers}
let r
if(void 0!==c&&["POST","PUT"].includes(o)){if(r="string"==typeof c?c:JSON.stringify(c),(new TextEncoder).encode(r).byteLength>Te.requestBytes)throw Re("E_LIMIT")
"string"==typeof c||a["content-type"]||(a["content-type"]="application/json")}l.assertDispatch?.()
const i=await e(p.href,{method:o,headers:a,body:r,credentials:"omit",redirect:"manual",signal:m.signal})
if("opaque"===i.type||"opaqueredirect"===i.type)throw Re("E_NETWORK","HTTP response is not observable")
const s=await async function(e,t,a){if(!e.body)return""
const n=e.body.getReader(),r=[]
let i=0
const o=()=>{n.cancel().catch((()=>{}))}
a.addEventListener("abort",o,{once:!0})
try{for(;;){if(a.aborted)throw a.reason
const{value:e,done:o}=await n.read()
if(o)break
if(i+=e.byteLength,i>t)throw await n.cancel(),Re("E_LIMIT","HTTP response exceeds byte budget")
r.push(e)}if(a.aborted)throw a.reason
const e=new Uint8Array(i)
let o=0
for(const t of r)e.set(t,o),o+=t.length
try{return new TextDecoder("utf-8",{fatal:!0}).decode(e)}catch{throw Re("E_VALUE_SERIALIZATION","Invalid HTTP UTF8",{stage:"utf8"})}}finally{a.removeEventListener("abort",o),n.releaseLock()}}(i,n,m.signal)
let d=s
if("json"===u.responseType)try{d=s?JSON.parse(s):""}catch{throw Re("E_VALUE_SERIALIZATION","Invalid HTTP JSON",{stage:"json"})}else if("text"!==u.responseType&&s)try{d=JSON.parse(s)}catch{}const f={}
for(const[e,t]of i.headers.entries())/^(set-cookie|set-cookie2|www-authenticate|proxy-authenticate)$/i.test(e)||(f[e]=t)
const g={data:d,status:i.status,statusText:i.statusText,headers:f,config:{...u,method:o.toLowerCase(),url:p.href}}
if(await Ut(l.recordNativeReceipt?.(g),m.signal),!i.ok)throw await Ut(t({capability:"network",url:p.href,method:o,phase:"post"},l),m.signal),Re("E_HTTP","HTTP "+i.status,{status:i.status,response:g})
if(l.method?.startsWith("AXIOS_")&&await(l.recordEffect?.(g)),await Ut(t({capability:"network",url:p.href,method:o,phase:"post"},l),m.signal),m.signal.aborted)throw m.signal.reason
return g}catch(w){if(m.signal.aborted)throw m.signal.reason
if(w?.code)throw w
throw Re("E_NETWORK","HTTP transport failed")}finally{i(I),l.signal?.removeEventListener("abort",f)}}return Object.freeze({request:s,checkServer:async function({server:e,timeout:t=5e3},n){const r=a.now()
try{return await s({method:"GET",url:e,config:{timeout:t}},n),{server:e,latency:Math.max(0,a.now()-r),available:!0}}catch(i){if(!["E_NETWORK","E_HTTP","E_TIMEOUT","E_VALUE_SERIALIZATION","E_LIMIT"].includes(i.code))throw i
return{server:e,latency:null,available:!1,error:i.message,errorCode:i.code}}},getIpInfo:async function({ip:e}={},a){if(!o||!t)throw Re("E_CAPABILITY","External network information is disabled")
const n=e?`${Ct}&ip=${e}`:Ct
return await t({capability:"network.info",url:n,method:"GET",phase:"pre"},a),(await s({method:"GET",url:n,config:{}},a)).data}})}class Dt extends Error{constructor(e,t=e,a){super(t,void 0===a?void 0:{cause:a}),this.name="PageError",this.code=e}}function xt(e,t,a){if(!e)throw new Dt(t,a)}const Lt=Object.freeze({depth:12,bytes:65536,uploadBytes:1048576,chunkBytes:49152}),Ht=crypto.getRandomValues.bind(crypto)
function Mt(){const e=Ht(new Uint8Array(16))
return Array.from(e,(e=>e.toString(16).padStart(2,"0"))).join("")}const jt=ne({profile:"control",ErrorType:Dt,maxDepth:Lt.depth,maxBytes:Lt.bytes}),qt=jt.encodeValue,Ft=jt.decodeValue
function Wt(e,t){xt(e&&"object"==typeof e&&!Array.isArray(e),"E_ARGUMENT_TYPE","Options must be an object")
for(const a of Object.keys(e))xt(t.includes(a),"E_OPTION_UNSUPPORTED","Unsupported option: "+a)
return e}function zt(e){return xt("string"==typeof e&&e.length>0&&e.length<=4096,"E_ARGUMENT_TYPE","Expected a nonempty CSS selector"),e}function Vt(e){return xt("number"==typeof e&&Number.isFinite(e)&&e>=0,"E_ARGUMENT_TYPE","Expected a finite nonnegative duration"),e}function Kt(e){let t
xt("string"==typeof e,"E_ARGUMENT_TYPE")
try{t=new URL(e)}catch{throw new Dt("E_URL_UNSUPPORTED")}return xt(["http:","https:"].includes(t.protocol)&&!t.username&&!t.password,"E_URL_UNSUPPORTED"),t.href}const Bt=structuredClone,Gt=Object.freeze,Jt=Object.keys
function $t(e){let t
try{t=Bt(e)}catch(a){throw new Dt("E_VALUE_SERIALIZATION",a.message)}return function e(t,a=0){if(xt(a<=64,"E_VALUE_SERIALIZATION"),t&&"object"==typeof t){xt(Array.isArray(t)||Object.getPrototypeOf(t)===Object.prototype||null===Object.getPrototypeOf(t),"E_VALUE_SERIALIZATION")
for(const n of Jt(t))e(t[n],a+1)
Gt(t)}return t}(t)}const Yt=new Set(["button","link","textbox","searchbox","checkbox","radio","combobox","option","heading","dialog","form","region","list","listitem","table","row","cell","columnheader","rowheader","img","article","navigation","main","banner","contentinfo","status","alert"]),Zt=new Set(["css","role","label","text","testId","placeholder","title","alt"]),Qt=new Set(["label","text","placeholder","title","alt"])
function Xt(e){return xt("string"==typeof e&&e.length>0&&e.length<=1024,"E_ARGUMENT_TYPE","Text required"),e}function ea(e){return zt(e),xt(!/^\s*(?:xpath\s*=|text\s*=|role\s*=|\/\/|\/html\b)/i.test(e)&&!/(?:>>>|>>|\/deep\/|:has-text\s*\(|:text(?:-is|-matches)?\s*\(|:nth-match\s*\(|:visible\b|::-p-)/i.test(e),"E_SELECTOR_UNSUPPORTED","CSS only"),e}function ta(e={}){return Wt(e,["exact"]),xt(void 0===e.exact||"boolean"==typeof e.exact,"E_ARGUMENT_TYPE"),!0===e.exact}function aa(e,t=0){xt(t<8&&e&&"object"==typeof e&&!Array.isArray(e)&&Zt.has(e.kind),"E_SELECTOR_UNSUPPORTED"),xt(void 0===e.index||Number.isSafeInteger(e.index)&&Math.abs(e.index)<=1e4,"E_ARGUMENT_TYPE")
const a=["kind","value","parent","index"]
"role"===e.kind?a.push("name","exact"):Qt.has(e.kind)&&a.push("exact"),xt(Object.keys(e).every((e=>a.includes(e))),"E_OPTION_UNSUPPORTED")
const n="role"===e.kind?{name:e.name,exact:e.exact}:Qt.has(e.kind)?{exact:e.exact}:{},r=void 0===e.parent?null:aa(e.parent,t+1),i=function(e,t,a={},n=null){let r
if(xt(Zt.has(e),"E_SELECTOR_UNSUPPORTED"),"css"===e)ea(t),Wt(a,[]),r={kind:e,value:t}
else if("role"===e){xt("string"==typeof t&&Yt.has(t),"E_ROLE_UNSUPPORTED")
const n=function(e={}){return Wt(e,["name","exact"]),xt(void 0===e.name||"string"==typeof e.name&&e.name.length<=1024,"E_ARGUMENT_TYPE"),{name:e.name,exact:ta({exact:e.exact})}}(a)
r={kind:e,value:t,...void 0!==n.name?{name:n.name}:{},exact:n.exact}}else Qt.has(e)?(Xt(t),r={kind:e,value:t,exact:ta(a)}):(Xt(t),Wt(a,[]),r={kind:e,value:t})
return null!==n&&(r.parent=aa(n)),Object.freeze(r)}(e.kind,e.value,n,r)
return void 0===e.index?i:Object.freeze({...i,index:e.index})}function na(e){var t,a
xt((a=["action","value","name","state","timeout"],(t=e)&&"object"==typeof t&&!Array.isArray(t)&&Object.keys(t).every((e=>a.includes(e)))),"E_ARGUMENT_TYPE")
const{action:n}=e
xt(["click","fill","check","uncheck","selectOption","count","textContent","innerText","inputValue","getAttribute","isVisible","isEnabled","isChecked","waitFor"].includes(n),"E_OPERATION_UNSUPPORTED"),"fill"!==n&&"selectOption"!==n||xt("string"==typeof e.value,"E_ARGUMENT_TYPE"),"getAttribute"===n&&xt("string"==typeof e.name&&/^[^\s"'<>/=]+$/.test(e.name),"E_ARGUMENT_TYPE"),"waitFor"===n&&xt(["attached","detached","visible","hidden"].includes(e.state),"E_OPTION_UNSUPPORTED"),void 0!==e.timeout&&(Vt(e.timeout),xt(e.timeout<=12e4,"E_ARGUMENT_TYPE"))
const r="fill"===n||"selectOption"===n?["action","value","timeout"]:"getAttribute"===n?["action","name","timeout"]:"waitFor"===n?["action","state","timeout"]:["action","timeout"]
return xt(Object.keys(e).every((e=>r.includes(e))),"E_OPTION_UNSUPPORTED"),Object.freeze({...e})}function ra(e){if("string"!=typeof e)throw Re("E_SCHEMA")
return new URL(De(/^https?:\/\//i.test(e)?e:"http://"+e)).hostname}function ia(e){if(xt(e&&"boolean"==typeof e.ok,"E_RESULT_FORMAT"),!e.ok)throw new Dt(e.error?.code||"E_PAGE_EXECUTION",e.error?.message,e.error?.cause)
return Ft(e.value)}const oa="E_COOKIE_FORMAT",sa="E_RESULT_FORMAT",ca="E_ARGUMENT_TYPE",da="OPENDESK_CONTROLLER_PAGE_SESSION_V1",la=new WeakMap,ua=Object.freeze({packaged:new Set(["title","content","contentOpen","contentRead","contentClose","url","snapshot","snapshots","click","type","keyboard","waitForTimeout","waitForSelector","uploadChunk","uploadCommit","addScriptTag","addStyleTag","locatorRead","locatorWait","locatorAction","locatorObserve"]),browser:new Set(["goto","reload","cookies","setCookie","deleteCookie","screenshot","uploadFromUrl"]),"user-script":new Set(["evaluate","$eval","$$eval","evaluateExpression","eval","waitForFunction"])}),pa=e=>JSON.stringify([e.runId,e.ownerEpoch]),ma=e=>({tabId:e.tabId,documentIds:[e.documentId]}),fa=e=>({documentId:e.documentId,frameId:e.frameId}),ga=e=>new Dt(e),Ia=Object.freeze(["cookies","setCookie","deleteCookie"]),wa=Object.freeze([oa,"E_COOKIE_SCOPE","E_COOKIE_PARTITION_UNSUPPORTED","E_PERMISSION_DENIED"])
function ha({api:e=globalThis.chrome,authorize:t,clock:a=Date,withWrite:n=async(e,t)=>t()}={}){xt(e&&"function"==typeof t&&"function"==typeof a.now&&"function"==typeof n,"E_PAGE_CONTEXT_REQUIRED")
const r=new Map,i=new Set,o=new WeakMap
la.has(e)||la.set(e,new Set)
const s=la.get(e)
function c(e){if(e.controller.signal.aborted)throw e.controller.signal.reason
if(e.run.closed)throw e.run.closed
if(null!==e.deadlineAt&&a.now()>=e.deadlineAt)throw ga("E_TIMEOUT")
if(e.locatorAbort?.signal.aborted)throw e.locatorAbort.signal.reason
if(void 0!==e.locatorExpiryAt&&a.now()>=e.locatorExpiryAt)throw ga("E_TIMEOUT")}async function d(e,a,n={}){c(e),xt(!1!==await l(e,t(e.envelope,{phase:a,...!e.navigationPending||e.handoff&&"pre"!==a?{}:{navigationPending:!0},...e.handoff&&"post"===a?{handoff:e.handoff}:{},...n})),"E_PERMISSION"),c(e)}function l(e,t){const a=e.locatorAbort?.signal||e.controller.signal
return new Promise(((e,n)=>{const r=()=>{a.removeEventListener("abort",r),n(a.reason)}
Promise.resolve(t).then((t=>{a.removeEventListener("abort",r),e(t)}),(e=>{a.removeEventListener("abort",r),n(e)})),a.aborted?r():a.addEventListener("abort",r,{once:!0})}))}async function u(e,t,a={}){let n,r=!1
n=setTimeout((async function t(){try{await d(e,"pre",a),r||(n=setTimeout(t,25))}catch(i){e.locatorAbort&&"E_TIMEOUT"===i?.code&&!e.controller.signal.aborted?e.locatorAbort.abort(i):e.controller.abort(i)}}),25)
try{const n=await l(e,t)
return await d(e,"post",a),n}finally{r=!0,clearTimeout(n)}}async function p(e,t,a){e.recordReceipt&&await e.recordReceipt({requestId:e.envelope.requestId,stage:t,receipt:$t(a)})}async function m(e,t,a={},n){await d(e,"pre",a),c(e)
const r=Promise.resolve(t()).then((async t=>(n&&await p(e,n,t),t)))
return u(e,r,a)}async function f(t,a,n,r,i){const o=["tabs","windows","cookies","scripting","webNavigation"].find((t=>e[t]===a))
return m(t,(()=>Ke(e,a,n,...r)),i,["locatorAction","locatorWait"].includes(t.envelope.operation.method)&&("webNavigation"===o||"tabs"===o&&"locatorCommit"!==r[1]?.envelope?.operation.method)?void 0:`${o}.${n}`)}async function g(t,a=t.handoff?.to||t.envelope.target){const n=await f(t,e.webNavigation,"getAllFrames",[{tabId:a.tabId}]),r=n?.find((e=>e.frameId===a.frameId))
xt(r&&r.documentId===a.documentId&&!r.errorOccurred&&(!r.documentLifecycle||"active"===r.documentLifecycle),"E_DOCUMENT_REPLACED")
const i=Kt(r.url)
return xt(!a.allowedOrigin||new URL(i).origin===a.allowedOrigin,"E_DOCUMENT_REPLACED"),await d(t,"post",{url:i}),i}async function I(t,a=t.envelope.operation.method,n=t.args){await async function(t){const a=t.envelope.target,n=JSON.stringify([a.tabId,a.documentId])
if(t.run.pages.has(n))return void(await u(t,t.run.pages.get(n)))
const r=(async()=>{let n
await g(t)
try{n=await f(t,e.tabs,"sendMessage",[a.tabId,{type:da,action:"ping"},fa(a)])}catch(r){if("E_CHROME"!==r.code||!/Receiving end does not exist|Could not establish connection|^The message port closed before a response was received\.$/i.test(r.message))throw r}if(void 0!==n)xt(n?.type===da&&!0===n.ready,sa)
else{await g(t)
const n=await f(t,e.scripting,"executeScript",[{target:ma(a),world:"ISOLATED",files:["scripting/packaged/page-session.js"]}])
xt(Array.isArray(n)&&1===n.length&&n[0].documentId===a.documentId&&n[0].frameId===a.frameId,"E_TARGET"),await g(t)
const r=await f(t,e.tabs,"sendMessage",[a.tabId,{type:da,action:"ping"},fa(a)])
xt(r?.type===da&&!0===r.ready,sa)}await g(t)})()
t.run.pages.set(n,r),t.run.pageTargets.set(n,t.envelope)
try{await u(t,r)}catch(i){throw t.run.pages.delete(n),i}}(t),await g(t)
const r=a===t.envelope.operation.method&&n===t.args?t.envelope:{...t.envelope,requestId:Mt(),operation:{kind:"packaged",method:a,args:qt(n,{maxBytes:"uploadChunk"===a?131072:65536})}},i=await f(t,e.tabs,"sendMessage",[r.target.tabId,{type:da,action:"execute",envelope:r},fa(r.target)])
if(await g(t),xt(i?.requestId===r.requestId&&i.runId===r.identity.runId&&i.ownerEpoch===r.identity.ownerEpoch,sa),i.error){xt("string"==typeof i.error.code&&i.error.code&&"string"==typeof i.error.message,sa)
const e=new Dt(i.error.code,i.error.message)
if("packaged"!==t.envelope.operation.kind||r!==t.envelope)throw e
const a={code:e.code,name:e.name,message:e.message}
await p(t,"packaged.finalFailure",{frameId:r.target.frameId,documentId:r.target.documentId,runId:i.runId,ownerEpoch:i.ownerEpoch,error:a})
const n={}
return o.set(n,a),n}return Ft(i.value)}async function w(t){let a
xt(!s.has(pa(t.envelope.identity)),"E_USER_SCRIPTS_UNAVAILABLE"),await d(t,"pre")
try{xt("function"==typeof e.userScripts?.getScripts&&"function"==typeof e.userScripts?.execute,"E_USER_SCRIPTS_UNAVAILABLE"),a=await l(t,e.userScripts.getScripts())}catch(n){if(t.controller.signal.aborted)throw t.controller.signal.reason
throw s.add(pa(t.envelope.identity)),new Dt("E_USER_SCRIPTS_UNAVAILABLE",n.message)}xt(Array.isArray(a),sa),await d(t,"post")}async function h(e,t,a){xt("function"==typeof t?.addListener&&"function"==typeof t.removeListener,"E_CAPABILITY_UNAVAILABLE"),await d(e,"pre"),c(e),t.addListener(a),e.cleanups.push((()=>t.removeListener(a)))}const E=globalThis.fetch?.bind(globalThis)
async function y(e,a){let n
try{await Promise.race([(async()=>{xt(!1!==await t(e,{phase:"pre"}),"E_PERMISSION"),await a(),await t(e,{phase:"post"})})(),new Promise((e=>{n=setTimeout(e,250)}))])}catch{}finally{clearTimeout(n)}}async function b(t){const a=t?.identity||t
xt("controller-run"===a?.tag&&"string"==typeof a.runId&&Number.isSafeInteger(a.ownerEpoch),"E_OWNER_CHANGED")
const n=pa(a)
i.add(n)
const o=r.get(n)
if(!o){if(!a.target||!t?.revision)return
const r={requestId:Mt(),identity:a,revision:t.revision,target:a.target,operation:{kind:"packaged",method:"cancel",args:qt([])}}
return await y(r,(()=>Ke(e,e.tabs,"sendMessage",r.target.tabId,{type:da,action:"cancel",run:a},fa(r.target)))),void(s.has(n)||await v(r,{world:"USER_SCRIPT",runId:n}))}if(o.cancelling)return o.cancelling
o.closed=ga("E_CANCELLED")
for(const e of o.pending)e.controller.abort(o.closed)
return o.cancelling=(async()=>{for(const t of o.pageTargets.values())await y(t,(()=>Ke(e,e.tabs,"sendMessage",t.target.tabId,{type:da,action:"cancel",run:a},fa(t.target))))
for(const{envelope:e,descriptor:t}of o.waits.values())s.has(n)||await v(e,t)
o.pages.clear(),o.pageTargets.clear(),o.waits.clear(),r.delete(n)})(),o.cancelling}async function v(a,n){await y(a,(async()=>{try{await e.userScripts.getScripts()}catch(i){throw s.add(pa(a.identity)),i}var r
xt(!1!==await t(a,{phase:"pre"}),"E_PERMISSION"),await e.userScripts.execute({target:ma(a.target),world:n.world,js:[{code:(r=n.runId,xt("string"==typeof r,"E_ARGUMENT_TYPE"),`(()=>{const waits=globalThis[Symbol.for('opendesk.userScripts.waits.v1')];if(waits)for(const owner of waits.values())if(owner.runId===${JSON.stringify(r)})owner.cancel();return true;})()`)}]}),await t(a,{phase:"pre"})
try{await e.userScripts.getScripts()}catch(i){throw s.add(pa(a.identity)),i}}))}return Object.freeze({execute:async function(t,{signal:s,deadlineAt:l=null,recordReceipt:y}={}){const v=$t(t),_=function(e){xt(e?.operation&&Object.hasOwn(ua,e.operation.kind)&&ua[e.operation.kind].has(e.operation.method),"E_OPERATION_UNSUPPORTED")
const{identity:t,revision:a,target:n,requestId:r}=e
xt("controller-run"===t?.tag&&"string"==typeof t.runId&&t.runId&&Number.isSafeInteger(t.ownerEpoch)&&t.ownerEpoch>0,"E_OWNER_CHANGED"),xt("string"==typeof r&&r&&a&&"string"==typeof a.scriptId&&a.scriptId&&Number.isSafeInteger(a.revision)&&a.revision>0&&/^[a-f0-9]{64}$/.test(a.sourceHash)&&("draft"===a.kind?a.scriptId==="draft:"+t.runId&&void 0===a.pinKey:void 0===a.kind&&"string"==typeof a.pinKey&&a.pinKey),"E_PAGE_CONTEXT_REQUIRED"),xt(Number.isSafeInteger(n?.tabId)&&n.tabId>=0&&Number.isSafeInteger(n.frameId)&&n.frameId>=0&&"string"==typeof n.documentId&&n.documentId,"E_TARGET"),void 0!==t.target&&xt(JSON.stringify(t.target)===JSON.stringify(n),"E_TARGET")
const i=Ft(e.operation.args,{maxBytes:"uploadChunk"===e.operation.method?131072:65536})
return xt(Array.isArray(i),ca),i}(v),{kind:S,method:A}=v.operation
let O
if(xt(null===l||Number.isFinite(l),ca),xt(void 0===y||"function"==typeof y,ca),"packaged"===S&&A.startsWith("locator"))if("locatorObserve"===A)xt(1===_.length,ca),function(e={}){Wt(e,["root","maxDepth","maxNodes","maxChars"])
const{root:t="body",maxDepth:a=5,maxNodes:n=80,maxChars:r=1e4}=e
ea(t),xt(Number.isInteger(a)&&a>=1&&a<=8&&Number.isInteger(n)&&n>=1&&n<=200&&Number.isInteger(r)&&r>=256&&r<=16e3,"E_ARGUMENT_TYPE"),Object.freeze({root:t,maxDepth:a,maxNodes:n,maxChars:r})}(_[0])
else{xt(2===_.length,ca),aa(_[0])
const e=na(_[1])
xt("locatorAction"===A?["click","fill","check","uncheck","selectOption"].includes(e.action):"locatorWait"===A?"waitFor"===e.action:["count","textContent","innerText","inputValue","getAttribute","isVisible","isEnabled","isChecked"].includes(e.action),"E_OPERATION_UNSUPPORTED")}if("user-script"===S&&(O=function(e,t,{operationId:a,runId:n}={}){xt("string"==typeof a&&a&&"string"==typeof n&&n,"E_ARGUMENT_TYPE"),xt(Array.isArray(t),"E_ARGUMENT_TYPE")
const r=e=>JSON.stringify(qt(e))
let i,o="USER_SCRIPT",s=!1
switch(e){case"evaluate":{const[e,a]=t
xt(e&&"string"==typeof e.source,"E_ARGUMENT_TYPE"),xt(!e.source.includes("[native code]"),"E_FUNCTION_SOURCE_UNSUPPORTED"),"legacy-statement"===e.mode?i=e.source+"\n;return true;":(xt("function"===e.mode,"E_ARGUMENT_TYPE"),i=`return await (${e.source})(...decodeValue(${r(a)}));`)
break}case"$eval":case"$$eval":{const[a,n,o]=t
zt(a),xt("string"==typeof n&&!n.includes("[native code]"),"E_FUNCTION_SOURCE_UNSUPPORTED"),i="$eval"===e?`const el=document.querySelector(${JSON.stringify(a)});requireValue(el,'E_SELECTOR_NOT_FOUND');return await (${n})(el,...decodeValue(${r(o)}));`:`return await (${n})(Array.from(document.querySelectorAll(${JSON.stringify(a)})),...decodeValue(${r(o)}));`
break}case"evaluateExpression":xt(1===t.length&&"string"==typeof t[0]&&t[0].trim(),"E_ARGUMENT_TYPE"),o="MAIN",i=`return await (${t[0]}\n);`
break
case"eval":{const[e,a]=t
xt("string"==typeof e&&e.length,"E_ARGUMENT_TYPE"),Wt(a,["mode"]),xt(["expression","statement"].includes(a.mode),"E_LEGACY_AMBIGUOUS_EXECUTION"),o="MAIN",i="expression"===a.mode?`return await (${e}\n);`:`await (async()=>{${e}\n})();return undefined;`
break}case"waitForFunction":{const[e,a,n]=t
xt("string"==typeof e&&!e.includes("[native code]"),"E_FUNCTION_SOURCE_UNSUPPORTED"),Wt(a,["timeout","polling"]),Vt(a.timeout),xt("raf"===a.polling||Number.isFinite(a.polling)&&a.polling>0,"E_ARGUMENT_TYPE"),s=!0,i=`const predicate=(${e}),values=decodeValue(${r(n)});const started=performance.now();for(;;){check();if(await Promise.race([Promise.resolve().then(()=>predicate(...values)),cancelled])){check();return true;}check();if(${a.timeout}!==0&&performance.now()-started>=${a.timeout})throw new PageError('E_TIMEOUT');await tick(${JSON.stringify(a.polling)});}`
break}default:throw new Dt("E_OPERATION_UNSUPPORTED")}const c=`(async()=>{const PageError=${Dt.toString()};const requireValue=${xt.toString()};const createValueCodec=${ne.toString()};const {encodeValue,decodeValue}=createValueCodec({profile:'control',ErrorType:PageError,maxDepth:12,maxBytes:65536});${s?`\n    const key=Symbol.for('opendesk.userScripts.waits.v1');const waits=globalThis[key]||(globalThis[key]=new Map());\n    let stopped=false,timer=null,raf=null,deadlineTimer=null,rejectCancel;const cancelled=new Promise((_,reject)=>rejectCancel=reject);cancelled.catch(()=>{});\n    const owner={runId:${JSON.stringify(n)},cancel(){if(stopped)return;stopped=true;clearTimeout(timer);clearTimeout(deadlineTimer);if(raf!==null)cancelAnimationFrame(raf);rejectCancel(new PageError('E_CANCELLED'));}};\n    ${s&&t[1].timeout>0?`deadlineTimer=setTimeout(()=>{stopped=true;rejectCancel(new PageError('E_TIMEOUT'));},${t[1].timeout});`:""}\n    requireValue(!waits.has(${JSON.stringify(a)}),'E_OPERATION_CONFLICT');waits.set(${JSON.stringify(a)},owner);\n    function check(){requireValue(!stopped,'E_CANCELLED');}\n    function tick(polling){return Promise.race([new Promise(resolve=>{if(polling==='raf')raf=requestAnimationFrame(()=>{raf=null;resolve();});else timer=setTimeout(()=>{timer=null;resolve();},polling);}),cancelled]);}\n  `:""}try{const value=await(async()=>{${i}\n})();return {ok:true,value:encodeValue(value)};}catch(error){return {ok:false,error:{code:error.code||'E_PAGE_EXECUTION',name:error.name,message:String(error.message),cause:{name:error.name,message:String(error.message)}}};}${s?`finally{clearTimeout(timer);clearTimeout(deadlineTimer);if(raf!==null)cancelAnimationFrame(raf);waits.delete(${JSON.stringify(a)});}`:""}})()`
return Object.freeze({world:o,code:c,wait:s,operationId:a,runId:n})}(A,_,{operationId:v.requestId,runId:pa(v.identity)})),"browser"===S&&["goto","reload"].includes(A)){xt(0===v.target.frameId,"E_TOP_FRAME_REQUIRED"),xt(_.length===("goto"===A?2:1),ca),"goto"===A&&(_[0]=Kt(_[0]))
const e=_["goto"===A?1:0]
Wt(e,["timeout","waitUntil"]),Vt(e.timeout),xt(["complete","load","domcontentloaded"].includes(e.waitUntil),"E_OPTION_UNSUPPORTED"),e.timeout>0&&(l=Math.min(l??1/0,a.now()+e.timeout))}"screenshot"===A&&(xt(0===v.target.frameId,"E_TOP_FRAME_REQUIRED"),xt(1===_.length,ca),Wt(_[0],["format","fullPage"]),xt(void 0===_[0].fullPage||"boolean"==typeof _[0].fullPage,ca),xt(!_[0].fullPage,"E_FULL_PAGE_UNSUPPORTED"),xt(["png","jpeg"].includes(_[0].format),"E_OPTION_UNSUPPORTED")),"uploadFromUrl"===A&&(xt(2===_.length,ca),zt(_[0]),Kt(_[1]))
const k=pa(v.identity)
xt(!i.has(k),"E_CANCELLED")
let T=r.get(k)
T||(T={pending:new Set,requests:new Set,pages:new Map,pageTargets:new Map,waits:new Map,userScriptsUnavailable:!1},r.set(k,T)),xt(!T.requests.has(v.requestId),"E_OPERATION_REPLAY"),T.requests.add(v.requestId)
const R=new AbortController,N={envelope:v,args:_,descriptor:O,run:T,controller:R,deadlineAt:l,recordReceipt:y,cleanups:[]}
"packaged"!==S||"locatorAction"!==A&&"locatorWait"!==A||(N.locatorExpiryAt=Math.min(l??1/0,a.now()+(_[1].timeout??3e4)),N.locatorAbort=new AbortController,R.signal.addEventListener("abort",(()=>N.locatorAbort?.abort(R.signal.reason)),{once:!0}),N.locatorTimer=setTimeout((()=>N.locatorAbort?.abort(ga("E_TIMEOUT"))),Math.max(0,N.locatorExpiryAt-a.now())))
const C=()=>R.abort(s.reason?.code?s.reason:ga("E_CANCELLED"))
let U
s?.aborted?C():s?.addEventListener("abort",C,{once:!0}),null!==l&&(U=setTimeout((()=>R.abort(ga("E_TIMEOUT"))),Math.max(0,l-a.now()))),T.pending.add(N)
try{let t
await d(N,"pre"),await g(N),t="packaged"===S?"locatorAction"===A||"locatorWait"===A?await async function(e){const{method:t}=e.envelope.operation,[r,i]=e.args
xt(2===e.args.length,ca)
const s=aa(r),l=na(i)
xt("locatorWait"===t?"waitFor"===l.action:"locatorAction"===t&&["click","fill","check","uncheck","selectOption"].includes(l.action),"E_OPERATION_UNSUPPORTED")
const m=e.locatorExpiryAt
let f=!1,w="E_SELECTOR_NOT_FOUND"
try{for(;;){if(c(e),a.now()>=m)throw new Dt("E_TIMEOUT","Locator timeout: "+w)
if("locatorWait"===t){const t=await I(e,"locatorRead",[s,{action:"waitFor",state:l.state}])
if(t?.ready)return
w="E_WAIT_CONDITION"}else{const t=await I(e,"locatorPrepare",[s,l])
if(xt(t&&"boolean"==typeof t.ready,sa),t.ready){xt("string"==typeof t.token,sa)
const a=await n(e.envelope.identity,(async()=>(await d(e,"pre"),await g(e),await p(e,"locator.commitIntent",{documentId:e.envelope.target.documentId}),f=!0,I(e,"locatorCommit",[s,l,t.token]))))
if(xt(a&&"boolean"==typeof a.committed,sa),a.committed){if(!1===a.stateReached)throw new Dt("E_ACTION_STATE_NOT_REACHED")
return}await p(e,"locator.commitNoEffect",{documentId:e.envelope.target.documentId}),f=!1,w=a.reason||"E_ELEMENT_DETACHED"}else w=t.reason||"E_WAIT_CONDITION"}const r=m-a.now()
r<=0||await u(e,new Promise((e=>setTimeout(e,Math.min(40,r)))))}}catch(h){if(f||!["E_TIMEOUT","E_STRICT_MODE_VIOLATION","E_SELECTOR_INVALID","E_SELECTOR_NOT_FOUND","E_INPUT_TARGET_UNSUPPORTED","E_WRITE_CONFLICT"].includes(h.code))throw h
clearTimeout(e.locatorTimer),delete e.locatorAbort,delete e.locatorExpiryAt,await d(e,"pre"),await g(e)
const t={code:h.code,name:"PageError",message:h.message}
await p(e,"packaged.finalFailure",{frameId:e.envelope.target.frameId,documentId:e.envelope.target.documentId,runId:e.envelope.identity.runId,ownerEpoch:e.envelope.identity.ownerEpoch,error:t})
const a={}
return o.set(a,t),a}}(N):await I(N):"user-script"===S?await async function(t){const a=t.descriptor
await g(t),await w(t),a.wait&&t.run.waits.set(t.envelope.requestId,{envelope:t.envelope,descriptor:a})
try{const r=await m(t,(()=>e.userScripts.execute({target:ma(t.envelope.target),world:a.world,js:[{code:a.code}]})),{},"userScripts.execute")
if(await w(t),await g(t),xt(Array.isArray(r)&&1===r.length&&r[0].frameId===t.envelope.target.frameId&&r[0].documentId===t.envelope.target.documentId,"E_TARGET"),r[0].error)throw new Dt("E_PAGE_EXECUTION",r[0].error)
if(!1===r[0].result?.ok){const e=r[0].result.error
let a
xt(e&&"string"==typeof e.code&&e.code&&"string"==typeof e.message&&e.cause&&"string"==typeof e.cause.message,sa)
try{ia(r[0].result)}catch(n){a=n}xt(a instanceof Dt&&"string"==typeof a.code&&"string"==typeof a.message,sa)
const i=a.cause,s={code:a.code,name:a.name,message:a.message,...i&&"string"==typeof i.message?{cause:{..."string"==typeof i.name?{name:i.name}:{},message:i.message}}:{}}
await p(t,"userScripts.finalFailure",{frameId:r[0].frameId,documentId:r[0].documentId,error:s})
const c={}
return o.set(c,s),c}return ia(r[0].result)}finally{t.controller.signal.aborted||t.run.waits.delete(t.envelope.requestId)}}(N):["goto","reload"].includes(A)?await async function(t){const{method:a}=t.envelope.operation,n=t.envelope.target,r="goto"===a?t.args[1]:t.args[0],i=await g(t),o="goto"===a?t.args[0]:i
let s,l,p,m=Promise.resolve(),I=!1
const w=new Promise(((e,t)=>{l=e,p=t}))
function E(e,a){if(I&&a.tabId===n.tabId&&0===a.frameId){if("commit"===e&&"string"==typeof a.documentId&&a.documentId!==n.documentId)try{const e=Kt(a.url)
s={...n,documentId:a.documentId,url:e,allowedOrigin:new URL(e).origin,targetVersion:(n.targetVersion||0)+1},t.handoff={from:n,to:$t(s)}}catch(i){return p(i),void t.controller.abort(i)}m=m.then((async()=>{if(c(t),"error"===e)throw ga("E_NAVIGATION")
const i=Kt(a.url)
if(await d(t,"pre",{url:i}),"commit"===e&&xt("string"==typeof a.documentId&&a.documentId&&a.documentId!==n.documentId,"E_DOCUMENT_REPLACED"),"dom"===e&&"domcontentloaded"===r.waitUntil||"complete"===e&&"domcontentloaded"!==r.waitUntil){if(!s||s.documentId!==a.documentId)return
t.handoff={from:n,to:$t(s)},await g(t),await d(t,"post",{url:i}),l()}})).catch((e=>{p(e),t.controller.abort(e)}))}}w.catch((()=>{}))
for(const[c,d]of[["onBeforeNavigate","before"],["onCommitted","commit"],["onDOMContentLoaded","dom"],["onCompleted","complete"],["onErrorOccurred","error"]])await h(t,e.webNavigation?.[c],(e=>E(d,e)))
await g(t),await d(t,"pre",{url:o}),I=!0,t.navigationPending=!0,await f(t,e.tabs,"goto"===a?"update":"reload","goto"===a?[n.tabId,{url:o}]:[n.tabId],{url:o}),await u(t,w,{url:o}),await g(t)}(N):"screenshot"===A?await async function(t){let a,n=!1
async function r(r=!1){await g(t)
const i=await f(t,e.tabs,"get",[t.envelope.target.tabId])
xt(i?.id===t.envelope.target.tabId&&i.active&&!i.hidden&&Number.isInteger(i.windowId),r?"E_CAPTURE_TARGET_CHANGED":"E_CAPTURE_TARGET_UNAVAILABLE"),void 0!==a&&xt(a===i.windowId,"E_CAPTURE_TARGET_CHANGED"),a=i.windowId
const o=await f(t,e.windows,"get",[a])
xt(o?.id===a&&"minimized"!==o.state,r?"E_CAPTURE_TARGET_CHANGED":"E_CAPTURE_TARGET_UNAVAILABLE"),void 0!==t.envelope.target.windowId&&xt(a===t.envelope.target.windowId,"E_CAPTURE_TARGET_CHANGED"),xt(!n,"E_CAPTURE_TARGET_CHANGED")}await h(t,e.tabs.onActivated,(e=>{void 0!==a&&e.windowId!==a||(n=!0)})),await h(t,e.tabs.onUpdated,((e,a)=>{e!==t.envelope.target.tabId||void 0===a.url&&"loading"!==a.status||(n=!0)})),await h(t,e.webNavigation.onCommitted,(e=>{e.tabId===t.envelope.target.tabId&&0===e.frameId&&(n=!0)})),await r()
const i=await f(t,e.tabs,"captureVisibleTab",[a,{format:t.args[0].format}])
return await r(!0),xt("string"==typeof i&&i.startsWith(`data:image/${t.args[0].format};base64,`),sa),i}(N):"uploadFromUrl"===A?await async function(e){const[t,a]=e.args
zt(t)
let n,r=Kt(a)
xt("function"==typeof E,"E_CAPABILITY_UNAVAILABLE"),await g(e)
for(let d=0;;d++){try{n=await m(e,(()=>E(r,{method:"GET",redirect:"manual",credentials:"omit",signal:e.controller.signal}).then((async t=>(await p(e,"fetch.response",{url:r,status:t.status,type:t.type}),t)))),{url:r})}catch(u){if(u.code)throw u
throw new Dt("E_NETWORK",u.message)}if(xt(!["opaque","opaqueredirect"].includes(n.type),"E_NETWORK"),![301,302,303,307,308].includes(n.status))break
await(n.body?.cancel()),xt(d<5,"E_LIMIT")
const t=n.headers.get("location")
xt(t,"E_NETWORK")
const a=Kt(new URL(t,r).href)
xt(!(r.startsWith("https:")&&a.startsWith("http:")),"E_UPLOAD_URL_UNSUPPORTED"),r=a}if(!n.ok)throw await(n.body?.cancel()),new Dt("E_HTTP","HTTP "+n.status)
if(Number(n.headers.get("content-length"))>Lt.uploadBytes)throw await(n.body?.cancel()),ga("E_LIMIT")
const i=[]
let o=0
if(n.body){const t=n.body.getReader(),a=()=>{t.cancel().catch((()=>{}))}
e.controller.signal.addEventListener("abort",a,{once:!0})
try{for(;;){const{done:a,value:n}=await m(e,(()=>t.read()),{url:r})
if(a)break
o+=n.byteLength,xt(o<=Lt.uploadBytes,"E_LIMIT"),i.push(n)}}catch(u){if(await t.cancel().catch((()=>{})),u.code)throw u
throw ga("E_NETWORK")}finally{e.controller.signal.removeEventListener("abort",a),t.releaseLock()}}await d(e,"post",{url:r}),await g(e)
const s=Mt(),c=new Uint8Array(o)
let l=0
for(const d of i)c.set(d,l),l+=d.byteLength
i.length=0
try{for(l=0;l<o;l+=Lt.chunkBytes){let t=""
for(const e of c.subarray(l,l+Lt.chunkBytes))t+=String.fromCharCode(e)
await d(e,"pre",{url:r}),await I(e,"uploadChunk",[s,l,o,btoa(t)])}return await d(e,"pre",{url:r}),await I(e,"uploadCommit",[t,s,o]),!0}finally{c.fill(0)}}(N):await async function(t){const n=await g(t),r=t.envelope.operation.method
let i
try{"cookies"===r?(xt(1===t.args.length&&Array.isArray(t.args[0])&&t.args[0].length<=100,"E_COOKIE_SCOPE"),i=[...new Set((t.args[0].length?t.args[0]:[n]).map(Kt))]):i=t.args.map((e=>function(e,t,a,n){let r
if("string"==typeof e)if(a)xt(e&&!/[;=\s]/.test(e),oa),r={name:e,path:"/"}
else{const[t,...a]=e.split(";"),i=t.indexOf("=")
xt(i>0,oa),r={name:t.slice(0,i).trim(),value:t.slice(i+1).trim()}
const o=new Set
for(const e of a){const t=e.indexOf("="),a=(t<0?e:e.slice(0,t)).trim().toLowerCase(),i=t<0?void 0:e.slice(t+1).trim()
if(xt(!o.has(a),oa),o.add(a),"secure"===a)xt(void 0===i,oa),r.secure=!0
else if("path"===a||"domain"===a)xt(i,oa),r[a]=i
else if("samesite"===a)r.sameSite=i
else if("expires"===a){const e=Date.parse(i)
xt(Number.isFinite(e),oa),r.expires=e/1e3}else{if("max-age"!==a)throw ga("partitioned"===a?"E_COOKIE_PARTITION_UNSUPPORTED":oa)
xt(/^-?\d+$/.test(i),oa),r.expirationDate=n/1e3+Number(i)}}}else{xt(e&&"object"==typeof e&&!Array.isArray(e),oa),r={...e},xt(!Object.hasOwn(r,"partitionKey")&&!Object.hasOwn(r,"partitioned"),"E_COOKIE_PARTITION_UNSUPPORTED")
for(const e of Object.keys(r))xt(["name","value","url","domain","path","secure","httpOnly","sameSite","expires","expirationDate","session","storeId","hostOnly"].includes(e),oa)}xt("string"==typeof r.name&&r.name&&!/[;=\s\x00-\x1f\x7f]/.test(r.name),oa),a||xt("string"==typeof r.value&&!/[;\r\n\x00]/.test(r.value),oa),r.url=Kt(r.url??t)
const i=new URL(r.url)
void 0!==r.domain&&(xt("string"==typeof r.domain,"E_COOKIE_SCOPE"),xt(r.domain.replace(/^\./,"")===i.hostname,"E_PERMISSION_DENIED")),a&&void 0===r.path&&(r.path=i.pathname.slice(0,i.pathname.lastIndexOf("/"))||"/"),void 0!==r.path&&xt("string"==typeof r.path&&r.path.startsWith("/")&&!/[;\r\n]/.test(r.path),oa),a&&(i.pathname=r.path,i.search="",i.hash="",r.url=i.href)
for(const o of["secure","httpOnly","session","hostOnly"])void 0!==r[o]&&xt("boolean"==typeof r[o],oa)
if(void 0!==r.sameSite){const e={lax:"lax",strict:"strict",none:"no_restriction",no_restriction:"no_restriction",unspecified:"unspecified"}
xt("string"==typeof r.sameSite&&Object.hasOwn(e,r.sameSite.toLowerCase()),oa),r.sameSite=e[r.sameSite.toLowerCase()]}return void 0!==r.expires&&(xt(Number.isFinite(r.expires),oa),r.expirationDate??=r.expires,delete r.expires),void 0!==r.expirationDate&&xt(Number.isFinite(r.expirationDate),oa),r}(e,n,"deleteCookie"===r,a.now())))
for(const e of i){const a="string"==typeof e?e:e.url
xt(new URL(a).origin===t.envelope.target.allowedOrigin,"E_PERMISSION_DENIED"),await d(t,"pre",{url:a})}}catch(E){if(!wa.includes(E.code))throw E
c(t)
const e={code:E.code,name:"PageError",message:(E.message||E.code)+""},{identity:a,target:n}=t.envelope
await p(t,"cookies.preflightFailure",{phase:"input-preflight",method:r,frameId:n.frameId,documentId:n.documentId,runId:a.runId,ownerEpoch:a.ownerEpoch,error:e})
const i={}
return o.set(i,e),i}const s=await f(t,e.cookies,"getAllCookieStores",[]),l=s?.filter((e=>e.tabIds?.includes(t.envelope.target.tabId)))
xt(1===l?.length&&"string"==typeof l[0].id,"E_COOKIE_SCOPE")
const m=l[0].id
for(const e of i)"string"!=typeof e&&(xt(void 0===e.storeId||e.storeId===m,"E_COOKIE_SCOPE"),e.storeId=m)
let I,w
const h=function({api:e=globalThis.chrome,authorize:t}={}){const a=async(e,a,n,r)=>{if(!t)throw Re("E_PERMISSION")
await t({capability:"cookies",url:De(e),method:a,phase:n},r)}
async function n(t,n){t=De(t),await a(t,"get","pre",n)
const r=await Ke(e,e.cookies,"getAll",{url:t})
if(!Array.isArray(r))throw Re("E_CHROME","Missing native cookie read receipt")
return await a(t,"get","post",n),r}return Object.freeze({getCookies:n,setCookies:async function(t,n){if(!Array.isArray(t)||t.length>100)throw Re("E_SCHEMA")
const r=t.map((e=>{if(Ce(e,["url","name","value","domain","path","secure","httpOnly","sameSite","expirationDate","session","storeId","hostOnly"]),"string"!=typeof e.name||"string"!=typeof e.value)throw Re("E_SCHEMA")
const t=De(e.url??`${e.secure?"https":"http"}://${((e.domain??"")+"").replace(/^\./,"")}${e.path??"/"}`),a=new URL(t).hostname,n=e.domain?.replace(/^\./,"")
if(void 0!==n&&n!==a)throw Re("E_SCHEMA","Cookie may not broaden authorized hostname")
const r={url:t,name:e.name,value:e.value}
for(const i of["path","secure","httpOnly","sameSite","storeId"])void 0!==e[i]&&(r[i]=e[i])
if(void 0!==e.domain&&!0!==e.hostOnly&&(r.domain=e.domain),void 0!==e.expirationDate&&!0!==e.session){if(!Number.isFinite(e.expirationDate))throw Re("E_SCHEMA")
r.expirationDate=e.expirationDate}if(e.name.startsWith("__Host-")){if("https:"!==new URL(t).protocol)throw Re("E_SCHEMA","__Host- cookies require HTTPS")
delete r.domain,r.path="/",r.secure=!0}return r}))
for(const e of r)await a(e.url,"set","pre",n)
for(const i of r){if(await a(i.url,"set","pre",n),!(await Ke(e,e.cookies,"set",i)))throw Re("E_CHROME","Missing native cookie write receipt")
await a(i.url,"set","post",n)}},deleteCookiesByUrl:async function(t,r){const i=await n(t,r)
for(const n of i){const i=new URL(t)
i.pathname=n.path,i.search="",i.hash="",await a(i.href,"remove","pre",r),await Ke(e,e.cookies,"remove",{url:i.href,name:n.name,...n.storeId?{storeId:n.storeId}:{}}),await a(i.href,"remove","post",r)}},extractDomainFromUrl:ra})}({api:{runtime:e.runtime,cookies:{getAll(a,n){c(t),e.cookies.getAll({...a,storeId:m},(a=>{e.runtime.lastError?n(a):p(t,"cookies.getAll",a).then((()=>{try{if(Array.isArray(a)&&(xt(a.every((e=>e.storeId===m)),"E_COOKIE_SCOPE"),xt(a.every((e=>void 0===e.partitionKey)),"E_COOKIE_PARTITION_UNSUPPORTED"),w)){const e=a.filter((e=>e.name===w.name&&e.path===w.path))
xt(e.length<=1,"E_COOKIE_SCOPE"),a=e.filter((e=>!w.domain||e.domain.replace(/^\./,"")===w.domain.replace(/^\./,"")))}n(a)}catch(E){I=E,n(void 0)}}),(e=>{I=e,n(void 0)}))}))},set(a,n){c(t),e.cookies.set({...a,storeId:m},(a=>{e.runtime.lastError?n(a):p(t,"cookies.set",a).then((()=>n(a)),(e=>{I=e,n(void 0)}))}))},remove(a,n){c(t),e.cookies.remove({...a,storeId:m},(a=>{e.runtime.lastError?n(a):(a||(I=ga("E_COOKIE_OPERATION")),p(t,"cookies.remove",a).then((()=>n(a)),(e=>{I=e,n(void 0)})))}))}}},authorize:async e=>{"pre"===e.phase&&await g(t),await d(t,e.phase,{url:e.url})}})
try{if("cookies"===r){const e=new Map
for(const a of i)for(const n of await u(t,h.getCookies(a)))e.set(JSON.stringify([n.storeId,n.name,n.domain,n.path]),{name:n.name,value:n.value,domain:n.domain,path:n.path,expires:n.expirationDate,httpOnly:n.httpOnly,secure:n.secure,sameSite:n.sameSite})
return[...e.values()]}if("setCookie"===r)await u(t,h.setCookies(i))
else{const e=[]
for(const a of i)w=a,(await u(t,h.getCookies(a.url))).length&&e.push(a)
for(const a of e)if(w=a,await u(t,h.deleteCookiesByUrl(a.url)),I)throw I}return void(await g(t))}catch(E){if(I)throw I
if("E_CHROME"===E.code)throw new Dt("E_COOKIE_OPERATION",E.message)
if("E_SCHEMA"===E.code)throw new Dt(oa,E.message)
throw E}}(N)
const r=o.get(t),i=r?{requestId:v.requestId,error:r}:{requestId:v.requestId,value:qt(t),...N.handoff?{handoff:N.handoff}:{}}
return await p(N,"result",i),await g(N),await d(N,"pre"),await d(N,"post"),c(N),i}catch(P){if(R.signal.aborted){const e=R.signal.reason
throw await b(v.identity),e}throw P}finally{clearTimeout(U),clearTimeout(N.locatorTimer),delete N.locatorAbort,delete N.locatorExpiryAt,s?.removeEventListener("abort",C),T.pending.delete(N)
for(const e of N.cleanups.reverse())e()}},cancel:b})}const Ea="opendesk-builtins.v2-lodash-es-4.18.1-dayjs-1.11.23-my-utils-1.0.0",ya=Object.freeze({abi:Ea,bootstrap:"libs/runtime/bootstrap.js",bootstrapSha256:"d8b6ff3a7a6a58a3ede0f630cd906f0af134307eeaa8a7db1f096ed24687868d",pageCore:"libs/runtime/page-core.js",controllerCore:"scripting/sandbox/worker-runtime.js",resourceManifest:"libs/manifest.json",libraries:Object.freeze({lodash:Object.freeze({id:"lodash",version:"4.18.1",output:"libs/packages/lodash.js",worlds:Object.freeze(["CONTROLLER","USER_SCRIPT"]),default:!0}),dayjs:Object.freeze({id:"dayjs",version:"1.11.23",output:"libs/packages/dayjs.js",worlds:Object.freeze(["CONTROLLER","USER_SCRIPT"]),default:!0}),myUtils:Object.freeze({id:"myUtils",version:"1.0.0",output:"libs/vendor/my-utils/1.0.0/index.js",sha256:"948e074af991e89df08091e28f8c7f42981dc213ae089da013772e755e54c461",bytes:291,worlds:Object.freeze(["CONTROLLER","USER_SCRIPT"]),default:!0}),jquery:Object.freeze({id:"jquery",version:"3.7.1",license:"MIT",output:"libs/vendor/jquery/3.7.1/jquery.min.js",sha256:"fc9a93dd241f6b045cbff0481cf4e1901becd0e12fb45166a8f17f95823f0b1a",bytes:87533,worlds:Object.freeze(["USER_SCRIPT"]),default:!1})})}),ba=Object.freeze([ya.bootstrap,...Object.values(ya.libraries).map((e=>e.output)),ya.pageCore,ya.controllerCore,"licenses/lodash-es-MIT.txt","licenses/dayjs-MIT.txt","licenses/my-utils-MIT.txt","licenses/jquery-MIT.txt"]),va=e=>Object.assign(Error(e),{code:e}),_a=/^[a-f0-9]{64}$/
async function Sa(e,t,a){const{runtime:n,fetchImpl:r}=t
if("function"!=typeof n?.getURL||"function"!=typeof r)throw va("E_BUILTIN_RESOURCE")
let i,o,s,c
try{i=n.getURL(""),o=n.getURL(e)}catch{throw va("E_BUILTIN_RESOURCE")}if(!/^chrome-extension:\/\/[^/?#]+\/$/.test(i)||o!==i+e||n.id&&i!=="chrome-extension://"+n.id+"/")throw va("E_BUILTIN_RESOURCE")
try{s=await r(o,{cache:"no-store",credentials:"omit"})}catch{throw va("E_BUILTIN_RESOURCE")}if(!s?.ok||s.redirected||s.url&&s.url!==o)throw va("E_BUILTIN_RESOURCE")
try{c=await s.text()}catch{throw va("E_BUILTIN_RESOURCE")}if("string"!=typeof c)throw va("E_BUILTIN_RESOURCE")
const d=(new TextEncoder).encode(c).length
if(0===d||d>a)throw va("E_BUILTIN_RESOURCE")
return{text:c,bytes:d}}async function Aa(e,{runtime:t=globalThis.chrome?.runtime,fetchImpl:a=globalThis.fetch}={}){const n={runtime:t,fetchImpl:a},{text:r}=await Sa(ya.resourceManifest,n,16384)
let i
try{i=JSON.parse(r)}catch{throw va("E_BUILTIN_MANIFEST")}const o=await j(JSON.stringify(ya)),s=i?.resources,c=Object.values(ya.libraries)
if("opendesk.builtin-resources.v2"!==i?.format||i.abi!==Ea||i.catalogSha256!==o||!Array.isArray(s)||s.length!==ba.length||s.some(((e,t)=>e?.path!==ba[t]||!Number.isSafeInteger(e.bytes)||e.bytes<1||e.bytes>524288||!_a.test(e.sha256)))||!c.every((e=>!e.sha256||s.some((t=>t.path===e.output&&t.sha256===e.sha256&&t.bytes===e.bytes)))))throw va("E_BUILTIN_VERSION_UNAVAILABLE")
const d=[ya.bootstrap,...c.filter((t=>t.default&&t.worlds.includes(e))).map((e=>e.output)),"CONTROLLER"===e?ya.controllerCore:ya.pageCore],l=[],u=[]
for(const m of d){const e=s[ba.indexOf(m)]
if(!e)throw va("E_BUILTIN_VERSION_UNAVAILABLE")
const{text:t,bytes:a}=await Sa(m,n,524288)
if(a!==e.bytes||await j(t)!==e.sha256)throw va("E_BUILTIN_HASH")
const r=c.find((e=>e.output===m&&e.sha256))
if(m===ya.bootstrap&&e.sha256!==ya.bootstrapSha256||r&&(e.sha256!==r.sha256||e.bytes!==r.bytes))throw va("E_BUILTIN_HASH")
l.push(t),u.push(Object.freeze({path:m,bytes:a,sha256:e.sha256}))}const p=l.join("\n;\n")
return Object.freeze({code:p,sha256:await j(p),catalogSha256:o,abi:Ea,resources:Object.freeze(u)})}const Oa=e=>Aa("USER_SCRIPT",e),ka=e=>Aa("CONTROLLER",e)
function Ta(e){return{abi:e?.abi??e?.builtinAbi,catalogSha256:e?.catalogSha256??e?.builtinCatalogSha256,bundleSha256:e?.sha256??e?.builtinBundleSha256}}function Ra(e,t){P(e?.abi===Ea&&t?.abi===Ea&&/^[a-f0-9]{64}$/.test(e.catalogSha256)&&/^[a-f0-9]{64}$/.test(e.bundleSha256)&&H(e)===H(t),"E_BUILTIN_VERSION_UNAVAILABLE","内置运行时已改变或旧版本未记录身份；请保存新版本并重新验证")}const Na=/^[a-f0-9]{64}$/,Ca=/^[a-zA-Z0-9][a-zA-Z0-9._-]{0,59}$/,Ua=/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/,Pa=new Set(["string","number","integer","boolean"])
function Da(e,t,a=t){P(e&&"object"==typeof e&&!Array.isArray(e)&&(Object.getPrototypeOf(e)===Object.prototype||null===Object.getPrototypeOf(e))&&Object.keys(e).every((e=>t.includes(e)))&&a.every((t=>Object.hasOwn(e,t))),"E_SCHEMA","Unexpected task package fields")}function xa(e,t=128){P("string"==typeof e&&e.trim()===e&&e.length>0&&e.length<=t,"E_SCHEMA","Invalid task package text")}function La(e,t){"string"===e.type?P("string"==typeof t&&t.length<=(e.maxLength??1024)&&t.length>=(e.minLength??0),"E_PARAMS","Invalid string parameter"):"boolean"===e.type?P("boolean"==typeof t,"E_PARAMS","Invalid boolean parameter"):P("number"==typeof t&&Number.isFinite(t)&&("integer"!==e.type||Number.isSafeInteger(t))&&(void 0===e.minimum||t>=e.minimum)&&(void 0===e.maximum||t<=e.maximum),"E_PARAMS","Invalid numeric parameter"),e.enum&&P(e.enum.includes(t),"E_PARAMS","Parameter not in allowed choices")}function Ha(e){Da(e,["type","properties","required","additionalProperties"]),P("object"===e.type&&!1===e.additionalProperties,"E_SCHEMA","Parameters must be a closed object"),P(e.properties&&"object"==typeof e.properties&&!Array.isArray(e.properties),"E_SCHEMA","Parameter properties must be an object"),Da(e.properties,Object.keys(e.properties))
const t=Object.keys(e.properties)
P(t.length<=16&&t.every((e=>/^[a-zA-Z][a-zA-Z0-9_]{0,39}$/.test(e))),"E_SCHEMA","Invalid parameter names"),P(Array.isArray(e.required)&&e.required.length<=t.length&&new Set(e.required).size===e.required.length&&e.required.every((e=>t.includes(e))),"E_SCHEMA","Invalid required parameters")
for(const a of Object.values(e.properties)){Da(a,["type","title","description","default","enum","minLength","maxLength","minimum","maximum"],["type","title"]),P(Pa.has(a.type),"E_SCHEMA","Unsupported parameter type"),xa(a.title,60),void 0!==a.description&&xa(a.description,240),P(["minLength","maxLength"].every((e=>void 0===a[e]||"string"===a.type&&Number.isSafeInteger(a[e])&&a[e]>=0&&a[e]<=4096)),"E_SCHEMA"),P(["minimum","maximum"].every((e=>void 0===a[e]||["number","integer"].includes(a.type)&&"number"==typeof a[e]&&Number.isFinite(a[e]))),"E_SCHEMA"),P(void 0===a.minimum||void 0===a.maximum||a.minimum<=a.maximum,"E_SCHEMA"),P(void 0===a.minLength||void 0===a.maxLength||a.minLength<=a.maxLength,"E_SCHEMA"),void 0!==a.enum&&P(Array.isArray(a.enum)&&a.enum.length>0&&a.enum.length<=32&&new Set(a.enum.map((e=>H(e)))).size===a.enum.length,"E_SCHEMA","Invalid parameter choices")
for(const e of a.enum||[])La({...a,enum:void 0},e)
Object.hasOwn(a,"default")&&La(a,a.default)}return H(e),e}function Ma(e,t){return P(Ca.test(e)&&Ua.test(t)&&t.length<=24,"E_SCHEMA","Invalid task identity"),`task:${e}:${t}`}function ja(e,t,a){return Ma(t,a),"task-candidate:"+H([e,t,a])}function qa(e,t){return P(Ca.test(t),"E_SCHEMA","Invalid task ID"),"task-installed:"+H([e,t])}function Fa(e,t,a){return"script:"+H(void 0===a?[e,t]:[e,t,a])}async function Wa(e){return Da(e,["format","manifest","manifestHash","sourceUtf8"]),P("opendesk.task-package.v1"===e.format&&"string"==typeof e.sourceUtf8&&(new TextEncoder).encode(e.sourceUtf8).byteLength<=Math.min(65536,N.maxRawFrameBytes-8192)&&JSON.stringify(e).length<=1e5,"E_LIMIT","Invalid or oversized task package"),function(e){Da(e,["format","taskId","version","title","description","author","source","siteOrigins","permissions","entryFormat","program","paramsSchema"]),P("opendesk.task.v1"===e.format&&Ca.test(e.taskId)&&Ua.test(e.version)&&e.version.length<=24,"E_SCHEMA","Unsupported task version")
for(const t of["title","author","source"])xa(e[t],"title"===t?100:160)
xa(e.description,800),P(Array.isArray(e.siteOrigins)&&1===e.siteOrigins.length,"E_PERMISSION","Task v1 verifies exactly one website origin")
for(const t of e.siteOrigins){let e
try{e=new URL(t)}catch{P(!1,"E_PERMISSION","Task site must be a valid HTTP(S) origin")}P(["http:","https:"].includes(e.protocol)&&e.href===t+"/"&&e.origin===t&&!e.username&&!e.password&&!e.hash&&!e.search&&!["*","null"].includes(t),"E_PERMISSION","Only one precise HTTP(S) origin is allowed")}P(Array.isArray(e.permissions)&&1===e.permissions.length&&"page.automation"===e.permissions[0],"E_PERMISSION","Task v1 only supports explicitly authorized page automation"),P("async-main"===e.entryFormat,"E_SCHEMA","Task entry must be async main()"),Da(e.program,["revision","sourceHash"]),P(Number.isSafeInteger(e.program.revision)&&e.program.revision>0&&Na.test(e.program.sourceHash),"E_SCHEMA","Invalid immutable program reference"),Ha(e.paramsSchema),H(e)}(e.manifest),P(Na.test(e.manifestHash)&&await M(e.manifest)===e.manifestHash,"E_HASH","Task manifest checksum mismatch"),P(await j(e.sourceUtf8)===e.manifest.program.sourceHash,"E_HASH","Task script checksum mismatch"),P(/\basync\s+function\s+main\s*\(/.test(e.sourceUtf8),"E_SCHEMA","Task v1 requires async function main()"),structuredClone(e)}const za="frameworkKV",Va=new Set(["candidate","verified","available"])
function Ka(e){P(e?.verification?.builtinAbi===Ea,"E_BUILTIN_VERSION_UNAVAILABLE","任务所验证的内置库版本已更改；请创建新任务版本并重新验证")}function Ba(e,t,a=t){P(e&&"object"==typeof e&&!Array.isArray(e)&&Object.keys(e).every((e=>t.includes(e)))&&a.every((t=>Object.hasOwn(e,t))),"E_SCHEMA","Unexpected task operation fields")}function Ga(e){P("string"==typeof e&&e.length>0,"E_SCHEMA","Missing task identity")}function Ja(e){return{taskId:e.taskId,version:e.version,manifest:structuredClone(e.package.manifest),manifestHash:e.package.manifestHash,stage:e.stage,verifiedAt:e.verification?.verifiedAt??null,verification:e.verification?{runId:e.verification.runId,resultId:e.verification.resultId,sourceHash:e.verification.sourceHash,origin:e.verification.origin}:null}}function $a(e,t){return P("task-candidate-v1"===e?.tag&&e.namespace===t&&Va.has(e.stage),"E_OWNER","Task candidate unavailable"),e}function Ya(e,t){return{tag:"task-install-authorization-v1",installationId:t?.installationId??crypto.randomUUID(),generation:(t?.generation??0)+1,scope:{capabilities:structuredClone(e.permissions),siteOrigins:structuredClone(e.siteOrigins),networkOrigins:[]}}}async function Za(e,t,{scriptId:a,contentHash:n,origin:r,params:i,migrate:o=!1,expectedGeneration:s,expectedInstallationId:c,builtinIdentity:d}){const l=(await e.all(za)).filter((e=>"task-installed-v1"===e?.tag&&e.namespace===t&&e.scriptId===a&&!0===e.enabled))
P(1===l.length,"E_PERMISSION","Task must be explicitly installed and enabled")
const u=l[0]
o&&P(s===(u.authorization?.generation??null)&&c===(u.authorization?.installationId??null),"E_REVISION","任务安装或授权在运行准备期间改变，请重新运行")
const p=$a(await e.get(za,ja(t,u.taskId,u.version)),t)
if(await Wa(p.package),Ka(p),Ra(p.builtinIdentity,d),Ra(p.verification?.builtinIdentity,d),Ra(u.builtinIdentity,d),P("available"===p.stage&&p.verification?.sourceHash===n&&p.verification?.manifestHash===p.package.manifestHash&&p.package.manifestHash===u.manifestHash&&p.package.manifest.program.sourceHash===n&&p.package.manifest.siteOrigins.includes(r)&&Ma(u.taskId,u.version)===a,"E_PERMISSION","Installed task does not match its Available version or website"),void 0!==i&&function(e,t){Ha(e),Da(t,Object.keys(e.properties),[])
const a={}
for(const[n,r]of Object.entries(e.properties)){const i=Object.hasOwn(t,n)
if(!i&&!Object.hasOwn(r,"default")){P(!e.required.includes(n),"E_PARAMS","Missing required parameter: "+n)
continue}const o=i?t[n]:r.default
La(r,o),a[n]=o}H(a)}(p.package.manifest.paramsSchema,i),!u.authorization&&o&&(u.authorization=Ya(p.package.manifest),await e.put(za,u,qa(t,u.taskId))),u.authorization){const e=u.authorization
P("task-install-authorization-v1"===e.tag&&"string"==typeof e.installationId&&/^[a-f0-9-]{36}$/.test(e.installationId)&&Number.isSafeInteger(e.generation)&&e.generation>0&&H(e.scope)===H(Ya(p.package.manifest).scope),"E_PERMISSION","Installed task authorization scope differs")}return{candidate:p,installation:structuredClone(u)}}async function Qa(e,t){if(!t.scriptId?.startsWith("task:"))return
const a=t.installedTaskAuthorization
P(a?.taskId&&a.authorization,"E_PERMISSION","旧任务运行没有可恢复的安装授权，请重新运行"),P(t.builtinAbi===Ea,"E_BUILTIN_VERSION_UNAVAILABLE","旧任务运行内置库身份已改变，禁止继续执行")
const n=await e.get(za,qa(t.namespace,a.taskId))
P("task-installed-v1"===n?.tag&&n.enabled&&n.scriptId===t.scriptId&&n.version===a.version&&n.manifestHash===a.manifestHash&&H(n.authorization)===H(a.authorization),"E_PERMISSION","任务已停用、卸载或授权版本改变；旧运行不能恢复")}const Xa="runs",en="readwrite",tn="readonly",an="controller-run",nn="E_OWNER",rn="E_PERMISSION",on="E_TIMEOUT",sn="E_SCHEMA",cn="commandJournal",dn="E_DOCUMENT_REPLACED",ln="E_REQUEST_CONFLICT",un="E_EFFECT_UNKNOWN",pn="E_CANCELLED",mn="Run permission revoked",fn=[Xa,cn,"results","frameworkKV"],gn=new Set(["preparing","running"]),In=new Set(["completed","failed","stopped","interrupted"]),wn=Object.freeze({maxDepth:48}),hn=["namespace","principal","grantIncarnation","runId","opId","requestId","resultId","browserSessionIncarnation"],En=(e,t,a)=>"script:"+H(void 0===a?[e,t]:[e,t,a]),yn=(e,t)=>"controller-op:"+H([e,t])
function bn(e,t){if("<all_urls>"===e)return!0
const a="string"==typeof e&&e.match(/^(\*|https?):\/\/([^/]+)\//)
if(!a)return!1
const n=new URL(t),r=a[2].toLowerCase()
return("*"===a[1]||a[1]+":"===n.protocol)&&("*"===r||r===n.hostname||r.startsWith("*.")&&(n.hostname===r.slice(2)||n.hostname.endsWith("."+r.slice(2))))}function vn(e){return[e.target?.allowedOrigin||e.startUrl&&$e(e.startUrl).origin,...e.networkOrigins||[]].filter(Boolean)}function _n(e,t){return vn(e).some((e=>t.some((t=>bn(t,e)))))}function Sn(e,t,a=[]){P(e&&"object"==typeof e&&!Array.isArray(e)&&Object.keys(e).every((e=>t.includes(e)))&&a.every((t=>Object.hasOwn(e,t))),sn,"Invalid controller request fields")}function An(e){P("string"==typeof e&&/^[A-Za-z0-9._:-]{1,128}$/.test(e),sn,"Invalid controller id")}function On(e,t){return H(e,wn)===H(t,wn)}function kn(e){return{code:e?.code||"E_CONTROL_EXECUTION",name:e?.name||"Error",message:(e?.message||e)+""}}function Tn({storage:e,assertHost:t,currentHost:a,session:n}){return{async reserve(n,r){const i=await t(r)
await e.transaction(["runs","commandJournal"],"readwrite",(async e=>{await a(e,i,r)
const t=await e.get("runs","@slot")
P(!t?.currentRunId&&!t?.preview,"E_OWNER","执行入口被占用；未知的页面执行须关闭原标签页后再继续"),await e.put("runs",{...t||{tag:"slot",currentRunId:null},preview:{...n,registrationId:i.registrationId}},"@slot")}))},async reserveInstalled(t,a){await e.transaction(["runs","frameworkKV"],"readwrite",(async e=>{const r=await e.get("frameworkKV","page-installed:"+H([a.namespace,a.programId]))
P("page-installed-v1"===r?.tag&&!0===r.enabled&&r.token===a.token&&r.manifestHash===a.manifestHash&&r.sourceHash===t.sourceHash,"E_PERMISSION","页面脚本已停用或安装版本已经改变")
const i=await e.get("frameworkKV",a.executionKey)
P("page-execution-v1"===i?.tag&&"prepared"===i.state&&i.browserSessionIncarnation===n&&i.installationToken===r.token&&i.manifestHash===r.manifestHash&&i.sourceHash===t.sourceHash&&i.documentId===t.documentId&&i.tabId===t.tabId,"E_OWNER","页面执行准入身份已经改变")
const o=await e.get("runs","@slot")
P(!o?.currentRunId&&!o?.preview,"E_OWNER","已有执行占用共享入口；不会自动重试页面脚本"),await e.put("runs",{...o||{tag:"slot",currentRunId:null},preview:{...t,installedProgramId:r.programId,manifestHash:r.manifestHash,executionKey:a.executionKey,browserSessionIncarnation:n}},"@slot"),await e.put("frameworkKV",{...i,receiptNonce:t.nonce},a.executionKey)}))},async release({nonce:t,removedTabId:a}){await e.transaction(["runs"],"readwrite",(async e=>{const n=await e.get("runs","@slot")
n?.preview&&(t&&n.preview.nonce===t||void 0!==a&&n.preview.tabId===a)&&(delete n.preview,await e.put("runs",n,"@slot"))}))}}}const Rn="commandJournal",Nn="pageSnapshots",Cn=Object.freeze(["framework/sdk-main.js","agents/page-relay.js"]),Un=Object.freeze(Object.fromEntries(["assets/js/core/brige.js","assets/js/core/common.js","assets/js/core/axiosx.js","assets/js/core/appStorage.js","assets/js/core/appLocal.js","assets/js/core/utils.js","assets/js/Env.js"].map((e=>[e,"framework/sdk-main.js"])))),Pn="E_RESOURCE_UNAVAILABLE",Dn=(e,t)=>e&&"object"==typeof e&&!Array.isArray(e)&&Object.keys(e).length===t.length&&t.every((t=>Object.hasOwn(e,t))),xn=ya.libraries.jquery,Ln=Object.freeze({id:xn.id,version:xn.version,sha256:xn.sha256,path:xn.output,license:xn.license,origin:"packaged"}),Hn=e=>Object.assign(Error(e),{code:e})
async function Mn({runtime:e=globalThis.chrome?.runtime,fetchImpl:t=globalThis.fetch}={}){if("function"!=typeof e?.getURL||"function"!=typeof t)throw Hn("E_RESOURCE_UNAVAILABLE")
let a,n,r,i
try{a=e.getURL(""),n=e.getURL(Ln.path)}catch{throw Hn("E_RESOURCE_IDENTITY")}if(!/^chrome-extension:\/\/[^/?#]+\/$/.test(a)||n!==a+Ln.path||e.id&&a!=="chrome-extension://"+e.id+"/")throw Hn("E_RESOURCE_IDENTITY")
try{r=await t(n,{cache:"no-store",credentials:"omit"})}catch{throw Hn("E_RESOURCE_UNAVAILABLE")}if(!r?.ok||r.redirected||r.url&&r.url!==n)throw Hn("E_RESOURCE_UNAVAILABLE")
try{i=await r.text()}catch{throw Hn("E_RESOURCE_UNAVAILABLE")}if("string"!=typeof i||(new TextEncoder).encode(i).byteLength!==xn.bytes||await j(i)!==Ln.sha256)throw Hn("E_DEPENDENCY_HASH")
return Object.freeze({descriptor:Ln,code:i})}const jn=["matches","excludeMatches","runAt","allFrames","world"],qn=new Set(["document_start","document_end","document_idle"]),Fn=(e,t)=>{throw Object.assign(Error(t),{code:e})},Wn=(e,t)=>JSON.stringify(e)===JSON.stringify(t)
function zn(e){if("string"!=typeof e||/[\s\\\u0000-\u001f\u007f]/.test(e))return!1
const t=/^(https?|\*):\/\/([^/]+)(\/.*)$/.exec(e)
if(!t)return!1
const a=/^(\[[^\]]+\]|[^:]+)(?::(\*|[0-9]+))?$/.exec(t[2])
if(!a||void 0!==a[2]&&"*"!==a[2]&&Number(a[2])>65535||t[3].includes("#"))return!1
const n=a[1]
if("*"===n)return!0
const r=n.startsWith("*.")?n.slice(2):n
if(!r||r.includes("*")||/[@#?]/.test(r)||n.startsWith("*.")&&r.startsWith("["))return!1
try{return new URL(`https://${r}/`).hostname===r.toLowerCase()}catch{return!1}}function Vn(e){(!e||"object"!=typeof e||Array.isArray(e)||![Object.prototype,null].includes(Object.getPrototypeOf(e))||Object.keys(e).some((e=>!jn.includes(e)))||jn.some((t=>!Object.hasOwn(e,t))))&&Fn("E_PAGE_CONTRACT","页面运行设置字段不完整或含未知字段"),"USER_SCRIPT"!==e.world&&Fn("E_WORLD_NOT_APPROVED","当前页内程序驱动使用 Chrome 隔离执行环境；执行环境不是能力授权"),qn.has(e.runAt)&&"boolean"==typeof e.allFrames||Fn("E_PAGE_RULES","页面程序运行时机或 frame 范围无效")
for(const t of[e.matches,e.excludeMatches])(!Array.isArray(t)||t.length>128||Array.from(t).some((e=>"string"!=typeof e||e.length>4096||!zn(e))))&&Fn("E_PAGE_MATCH","页面运行范围须为明确的 HTTP(S) 匹配规则"),new Set(t).size!==t.length&&Fn("E_PAGE_RULES","页面运行范围不能含重复项")
return(new TextEncoder).encode(JSON.stringify(e)).byteLength>65536&&Fn("E_PAGE_MATCH","页面运行设置超过 64 KiB"),e.matches.length||Fn("E_PAGE_MATCH","自动运行需要明确的网页范围；普通 JavaScript 无需添加 @match 注释"),Object.freeze({matches:Object.freeze([...e.matches]),excludeMatches:Object.freeze([...e.excludeMatches]),runAt:e.runAt,allFrames:e.allFrames,world:e.world})}function Kn(e,t,a){const n=Vn(void 0===a?t.nativeOptions:a)
if(e.hasHeader){const a=t.nativeOptions;(e.matches.length&&!Wn(n.matches,a.matches)||!Wn(n.excludeMatches,a.excludeMatches)||n.runAt!==a.runAt||n.allFrames!==a.allFrames)&&Fn("E_PAGE_METADATA_RULES","兼容脚本声明与页面运行设置冲突；请明确迁移，不能静默扩大范围")}return n}const Bn=Object.freeze({headerBytes:65536,requireCount:64,matchCount:128}),Gn=Object.freeze({md5:16,sha1:20,sha256:32,sha384:48,sha512:64}),Jn=new Set(["sha256","sha384","sha512"]),$n=Object.freeze({"document-start":"document_start","document-end":"document_end","document-idle":"document_idle"}),Yn=new Set(["name","namespace","version","description","author","copyright","license","homepage","homepageurl","website","source","supporturl","icon","iconurl","defaulticon","icon64","icon64url","tag","antifeature","contributionurl","contributionamount"]),Zn=new Set(["require","resource","match","exclude-match","include","exclude","run-at","noframes","grant","connect","inject-into","sandbox","unwrap","top-level-await","run-in","webrequest","updateurl","downloadurl","inject-mode","world","opendesk-lib"]),Qn=new Set(["name","description","antifeature"]),Xn=new TextEncoder,er=(e,t,a=[])=>Object.assign(Error(t||e),{code:e,diagnostics:a}),tr=(e,t,a,n)=>({severity:e,code:t,message:a,...n?{line:n.line,directive:n.name||"require"}:{}})
function ar(e){return e&&"object"==typeof e&&!Object.isFrozen(e)&&(Object.values(e).forEach(ar),Object.freeze(e)),e}function nr(e,t){let a=t
for(;a<e.length&&!/[\r\n\u2028\u2029]/.test(e[a]);)a++
const n=a+("\r"===e[a]&&"\n"===e[a+1]?2:a<e.length?1:0)
return{raw:e.slice(t,a),end:a,next:n}}function rr(e,t){if(RegExp(`^[a-f0-9]{${2*t}}$`,"i").test(e))return{digestHex:e.toLowerCase(),encoding:"hex"}
if(!/^[A-Za-z0-9+/_-]+={0,2}$/.test(e))return null
const a=e.replace(/-/g,"+").replace(/_/g,"/"),n=a.replace(/=+$/,"")
if(n.length%4==1||a.includes("=")&&a.length%4!=0)return null
try{const e=atob(n)
return e.length!==t||btoa(e).replace(/=+$/,"")!==n?null:{digestHex:Array.from(e,(e=>e.charCodeAt(0).toString(16).padStart(2,"0"))).join(""),encoding:"base64"}}catch{return null}}function ir(e,t,a,n){const r=[],i=e.indexOf("#"),o=i<0?e:e.slice(0,i),s=function(e,t,a){if(null===e)return[]
if(""===e)return a.push(tr("error","E_DEPENDENCY_INTEGRITY","Empty integrity fragment after #; remove # or provide a supported digest",t)),[]
let n
try{n=decodeURIComponent(e)}catch{return a.push(tr("error","E_DEPENDENCY_INTEGRITY","Malformed percent encoding in dependency integrity",t)),[]}const r=[],i=n.split(/[;,\s]+/).filter(Boolean)
for(const o of i){const e=/^(md5|sha1|sha256|sha384|sha512)([=-])(.+)$/i.exec(o),n=e?.[1].toLowerCase(),i=e&&rr(e[3],Gn[n])
if(!i){a.push(tr("error","E_DEPENDENCY_INTEGRITY","Invalid or unsupported integrity token: "+o.slice(0,96),t))
continue}const s=r.find((e=>e.algorithm===n))
s&&a.push(tr(s.digestHex===i.digestHex?"warning":"error",s.digestHex===i.digestHex?"W_DEPENDENCY_INTEGRITY_DUPLICATE":"E_DEPENDENCY_INTEGRITY_CONFLICT",s.digestHex===i.digestHex?`Repeated ${n} integrity declaration`:`Conflicting ${n} integrity declarations`,t)),r.push({algorithm:n,...i,raw:o})}return i.length||a.push(tr("error","E_DEPENDENCY_INTEGRITY","Empty integrity declaration",t)),r}(i<0?null:e.slice(i+1),a,r)
let c=null
try{if(!o||/[\s\u0000-\u001f\u007f\\]/.test(o)||e.length>8192)throw Error()
if(/^[a-z][a-z0-9+.-]*:/i.test(o)||n){const e=new URL(o,n||void 0)
if("https:"!==e.protocol||e.username||e.password)throw Error()
e.hash="",c=e.href}else r.push(tr("error","E_DEPENDENCY_BASE_URL","Relative @require needs the actual script import URL; page URL and @downloadURL are not an import identity",a))}catch{r.push(tr("error","E_DEPENDENCY_URL","@require must resolve to an HTTPS URL without credentials or control characters",a))}return{raw:e,originalUrl:e,url:c,sourceKind:c?"https":null,sha256:s.find((e=>"sha256"===e.algorithm))?.digestHex||null,integrity:s,integrityPolicy:"all-strong",order:t,line:a.line,diagnostics:r}}function or(e,{importSourceUrl:t}={}){if("string"!=typeof e)throw er("E_SOURCE","Script source must be text")
const a={profile:"opendesk-d1",hasHeader:!1,headerRaw:"",headerRange:null,headerComplete:!1,importSourceUrl:null,requires:[],matches:[],excludeMatches:[],runAt:"document-idle",noframes:!1,directives:[],grants:[],resources:[],diagnostics:[]}
a.importSourceUrl=function(e,t){if(null==e)return null
try{if("string"!=typeof e||/[\u0000-\u0020\u007f\\]/.test(e))throw Error()
const t=new URL(e)
if(!["http:","https:"].includes(t.protocol)||t.username||t.password)throw Error()
return t.hash="",t.href}catch{return t.push(tr("error","E_IMPORT_SOURCE","Import source must be the actual absolute HTTP(S) script URL without credentials")),null}}(t,a.diagnostics)
const n=function(e){let t=0,a=1
for(;t<e.length;)if(/\s/.test(e[t]))"\r"===e[t]&&"\n"===e[t+1]&&t++,/[\r\n\u2028\u2029]/.test(e[t])&&a++,t++
else if(e.startsWith("//",t)){const n=nr(e,t)
if(/^\/\/[\t ]*==UserScript\b/.test(n.raw))return{offset:t,line:a,malformed:!/^\/\/[\t ]*==UserScript==[\t ]*$/.test(n.raw)}
n.next>n.end&&a++,t=n.next}else{if(!e.startsWith("/*",t))return null
{const n=e.indexOf("*/",t+2)
if(n<0)return null
a+=(e.slice(t,n+2).match(/\r\n|[\r\n\u2028\u2029]/g)||[]).length,t=n+2}}return null}(e)
if(!n)return ar(a)
let{offset:r,line:i}=n
a.hasHeader=!0,n.malformed&&a.diagnostics.push(tr("error","E_METADATA_HEADER","Malformed UserScript opening marker",{line:i}))
const o=r,s=i
let c=0,d=!0,l=null,u=!1
for(;r<e.length;){const t=nr(e,r)
if(c+=Xn.encode(e.slice(r,t.next)).byteLength,c>Bn.headerBytes){a.diagnostics.push(tr("error","E_METADATA_LIMIT","UserScript header exceeds 64 KiB")),r=Math.min(t.next,o+Bn.headerBytes),u=!0
break}if(r=t.next,d){d=!1,i++
continue}if(/^[\t ]*\/\/[\t ]*==\/UserScript==[\t ]*$/.test(t.raw)){a.headerComplete=!0
break}const n={line:i}
if(!/^[\t ]*\/\//.test(t.raw)){a.diagnostics.push(tr("error","E_METADATA_HEADER","Each metadata line must be a line comment",n)),i++
continue}const s=/^[\t ]*\/\/[\t ]*@([A-Za-z][A-Za-z0-9_.:-]*)(?:[\t ]+(.*))?[\t ]*$/.exec(t.raw)
if(!s){/^[\t ]*\/\/[\t ]*@/.test(t.raw)&&a.diagnostics.push(tr("error","E_METADATA_DIRECTIVE","Malformed metadata directive",n)),i++
continue}const p=s[1].toLowerCase(),m=s[2]?.trim()||"",[f,g]=p.split(":"),I=!Yn.has(f)||g&&!Qn.has(f)?Zn.has(p)?"execution":"unknown":"descriptive",w={name:p,originalName:s[1],value:m,raw:t.raw,line:i,kind:I,known:"unknown"!==I}
if(a.directives.push(w),"unknown"===I&&a.diagnostics.push(tr("warning","W_METADATA_UNKNOWN",`Unrecognized @${p} is preserved for review`,w)),"require"===p)a.requires.push(ir(m,a.requires.length,w,a.importSourceUrl))
else if("match"===p)a.matches.push(m)
else if("exclude-match"===p)a.excludeMatches.push(m)
else if("grant"===p)a.grants.push(m)
else if("resource"===p){const e=/^(\S+)\s+(.+)$/.exec(m)
a.resources.push({name:e?.[1]||null,originalUrl:e?.[2]||null,raw:m,line:i}),e||a.diagnostics.push(tr("error","E_RESOURCE_DECLARATION","@resource needs a name and URL",w))}else"run-at"===p?(null!==l&&a.diagnostics.push(tr(l===m?"warning":"error",l===m?"W_METADATA_DUPLICATE":"E_METADATA_CONFLICT","Repeated @run-at must agree",w)),null===l&&(a.runAt=m,l=m)):"noframes"===p&&(a.noframes=!0,m&&a.diagnostics.push(tr("error","E_METADATA_VALUE","@noframes is a flag and takes no value",w)))
i++}a.headerRaw=e.slice(o,r),a.headerRange={start:o,end:r,startLine:s,endLine:i,truncated:u},a.headerComplete||u||a.diagnostics.push(tr("error","E_METADATA_HEADER","UserScript header is not terminated")),a.requires.length>Bn.requireCount&&a.diagnostics.push(tr("error","E_DEPENDENCY_LIMIT","At most 64 dependencies can be reviewed in one script")),(a.matches.length>Bn.matchCount||a.excludeMatches.length>Bn.matchCount)&&a.diagnostics.push(tr("error","E_PAGE_MATCH","At most 128 rules of each matching type are supported"))
const p=new Map
for(const m of a.requires){if(a.diagnostics.push(...m.diagnostics),!m.url)continue
const e=p.get(m.url)
e?(a.diagnostics.push(tr("warning","W_DEPENDENCY_DUPLICATE","Repeated @require is kept in declaration order and will execute again",m)),m.integrity.some((t=>e.some((e=>Jn.has(t.algorithm)&&e.algorithm===t.algorithm&&e.digestHex!==t.digestHex))))&&a.diagnostics.push(tr("error","E_DEPENDENCY_INTEGRITY_CONFLICT","The same dependency URL declares conflicting content hashes",m)),e.push(...m.integrity)):p.set(m.url,[...m.integrity])}return ar(a)}function sr(e){if("string"!=typeof e||/[\s\\\u0000-\u001f\u007f]/.test(e))return!1
const t=/^(https?|\*):\/\/([^/]+)(\/.*)$/.exec(e)
if(!t)return!1
const a=/^(\[[^\]]+\]|[^:]+)(?::(\*|[0-9]+))?$/.exec(t[2])
if(!a||void 0!==a[2]&&"*"!==a[2]&&Number(a[2])>65535||t[3].includes("#"))return!1
const n=a[1]
if("*"===n)return!0
const r=n.startsWith("*.")?n.slice(2):n
if(!r||r.includes("*")||/[@#?]/.test(r)||n.startsWith("*.")&&r.startsWith("["))return!1
try{return new URL(`https://${r}/`).hostname===r.toLowerCase()}catch{return!1}}function cr(e,{entryFormat:t="async-main",phase:a="preview",dependenciesLocked:n=!1}={}){if(!e||"opendesk-d1"!==e.profile||!Array.isArray(e.requires)||!Array.isArray(e.diagnostics))throw er("E_METADATA_SCHEMA","A parsed UserScript manifest is required")
const r=e.diagnostics.filter((e=>"error"===e.severity)).map((e=>({...e}))),i=e.diagnostics.filter((e=>"warning"===e.severity)).map((e=>({...e}))),o=(e,t,a)=>r.push(tr("error",e,t,a)),s=(e,t,a)=>i.push(tr("warning",e,t,a));["async-main","classic-userscript"].includes(t)||o("E_ENTRY_FORMAT","Choose classic-userscript or async-main explicitly; ESM is not a UserScript entry mode"),["preview","registration"].includes(a)||o("E_METADATA_PHASE","Expected preview or registration admission")
for(const d of e.directives)"descriptive"===d.kind&&"antifeature"===d.name.split(":")[0]&&s("W_ANTIFEATURE_DECLARED",`脚本自述 @${d.originalName}：${d.value||"(未说明)"}。这不是安全鉴定；未声明也不代表没有风险。`,d),"unknown"===d.kind&&o("E_METADATA_UNSUPPORTED",`@${d.name} has unknown execution semantics; remove it or use a supported adapter`,d),"grant"===d.name&&"none"!==d.value&&o("E_GRANT_UNSUPPORTED",`@grant ${d.value||"(empty)"} is not implemented; no GM or host privilege is granted`,d),"resource"===d.name&&o("E_RESOURCE_UNSUPPORTED","@resource is preserved but its GM resource APIs are not implemented",d),"include"!==d.name&&"exclude"!==d.name||o("E_MATCH_SEMANTICS_UNSUPPORTED",`@${d.name} glob/regex semantics are not implemented; explicit @match/@exclude-match conversion is required`,d),["connect","sandbox","unwrap","top-level-await","run-in","webrequest","inject-mode"].includes(d.name)&&o("E_METADATA_UNSUPPORTED",`@${d.name} execution semantics are not implemented`,d),"inject-into"===d.name&&"content"!==d.value&&o("E_WORLD_NOT_APPROVED","Only content-style USER_SCRIPT isolation is supported; page/auto injection needs separate review",d),"world"===d.name&&o("E_WORLD_NOT_APPROVED","@world cannot authorize an execution world; D1 uses USER_SCRIPT only",d),"opendesk-lib"!==d.name||["jquery","react","vue"].includes(d.value)||o("E_BUILTIN_DECLARATION","Only reviewed packaged jquery/react/vue can be selected",d),"updateurl"!==d.name&&"downloadurl"!==d.name||s("W_UPDATE_NOT_IMPLEMENTED",`@${d.name} is informational; it neither establishes import identity nor enables automatic updates`,d)
const c=[...new Set(e.grants)]
c.includes("none")&&c.length>1&&o("E_GRANT_CONFLICT","@grant none cannot be combined with privileged grants"),e.hasHeader&&(s("W_USER_SCRIPT_ISOLATION",c.includes("none")?"@grant none does not switch to page MAIN world: page JavaScript globals and unsafeWindow are unavailable in USER_SCRIPT":"D1 uses USER_SCRIPT isolation without implicit GM_info, GM.info or unsafeWindow; this is a supported subset of UserScript managers"),e.directives.some((e=>"run-at"===e.name))||s("W_RUN_AT_DEFAULT","D1 defaults to document-idle; Violentmonkey defaults to document-end, so declare @run-at when timing matters")),Object.hasOwn($n,e.runAt)||o("E_RUN_AT_UNSUPPORTED",`@run-at ${e.runAt||"(empty)"} has no supported Chrome mapping`)
for(const[d,l]of[[e.matches,"match"],[e.excludeMatches,"exclude-match"]])for(const e of d)sr(e)||o("E_PAGE_MATCH",`@${l} is not a supported HTTP(S) Chrome match pattern: ${e}`)
"registration"===a&&0===e.matches.length&&s("W_MATCH_DEFAULT","未声明 @match：默认匹配全部 HTTP(S) 网站；安装前请核对授权范围"),"preview"===a&&e.hasHeader&&s("W_PREVIEW_TIMING","Immediate preview runs in the approved current main document now; it does not replay @run-at, match selection or frame scheduling"),"classic-userscript"===t&&e.requires.length&&s("W_SHARED_COMPILATION_UNIT","Dependencies and classic source share one compilation unit; top-level strict directives and lexical declarations can affect each other. IIFE-local strict directives retain their own scope")
for(const d of e.requires){const e=d.integrity.filter((e=>!Jn.has(e.algorithm)))
e.length&&!d.integrity.some((e=>Jn.has(e.algorithm)))?o("E_DEPENDENCY_INTEGRITY_UNSUPPORTED","MD5/SHA-1 alone are not accepted; provide a strong integrity value before review",d):e.length&&s("W_DEPENDENCY_WEAK_INTEGRITY","MD5/SHA-1 declarations are retained but not verified; every declared SHA-256/384/512 must match",d)}return ar({status:r.length?"unsupported":e.requires.length&&!n?"needs-review":"executable",blockers:r,warnings:i,nativeOptions:{matches:e.matches.length?[...new Set(e.matches)]:["*://*/*"],excludeMatches:[...new Set(e.excludeMatches)],runAt:$n[e.runAt]||null,allFrames:e.matches.length>0&&!e.noframes,world:"USER_SCRIPT"}})}function dr(e,t){const a=cr(e,t)
if(a.blockers.length){const e=a.blockers[0]
throw er(e.code,e.message,a.blockers)}if("needs-review"===a.status)throw er("E_DEPENDENCY_UNLOCKED","Approve, verify and lock all dependencies before execution")
return a}const lr=Object.freeze({react:Object.freeze({id:"react",version:"19.2.0",source:"src/libs/page-frameworks/react-19.2.0.js",output:"libs/page-frameworks/react-19.2.0.js",bytes:192234,sha256:"4922d0516810e22b35fe9204fefa98ae7efc9207a23eefe9e5459f7e11499c3f",licenseSource:"src/libs/page-frameworks/react-LICENSE.txt",licensePath:"licenses/page-framework-react-MIT.txt",global:"OpenDeskPageReact"}),vue:Object.freeze({id:"vue",version:"3.5.22",source:"src/libs/page-frameworks/vue-3.5.22.js",output:"libs/page-frameworks/vue-3.5.22.js",bytes:61558,sha256:"3c22d3940608bfe8d77ab3efb1159bc624fe30b076c3e276e6c367dec2ec7aba",licenseSource:"src/libs/page-frameworks/vue-LICENSE.txt",licensePath:"licenses/page-framework-vue-MIT.txt",global:"OpenDeskPageVue"})}),ur=Object.freeze(["classic-userscript","async-main"]),pr=131072,mr="script-src 'self'; object-src 'none'",fr="opendesk.page-preview-receipt.v1"
function gr(e,t=or(e)){const a=t.directives.filter((e=>"opendesk-lib"===e.name)).map((e=>e.value)),n=[]
if(!t.hasHeader)for(const i of e.replace(/^\uFEFF/,"").split(/\r?\n/)){if(/^\s*$/.test(i))continue
const e=/^\s*\/\/\s*@opendesk-lib\s+([^\s]+)\s*$/.exec(i)
if(e)n.push(e[1])
else if(!/^\s*\/\//.test(i))break}const r=t.hasHeader?a:n
return P(r.length<=1&&r.every((e=>["jquery","react","vue"].includes(e))),"E_BUILTIN_DECLARATION","仅允许一次有效的 // @opendesk-lib 声明"),P(!r.length||0===t.requires.length,"E_BUILTIN_CONFLICT","内置 jQuery 与 @require 不可混合加载；请只选择一种依赖来源"),r[0]??null}function Ir(e,t=or(e)){return"jquery"===gr(e,t)}function wr(e,t,a){P(void 0===a||/^[a-f0-9-]{36}$/.test(a),"E_RESULT_FORMAT","Invalid preview completion identity")
const n=void 0===a?null:JSON.stringify({format:fr,nonce:a})
if("classic-userscript"===t)return e+(n?"\n;\n({..."+n+",ok:true})":"")
const r="(async function(main) {\n'use strict';\n"+e+"\nif (typeof main !== 'function') throw new Error('E_MAIN_REQUIRED: 需要 async function main()');\nreturn await main();\n})(undefined)"
return n?"(async()=>{try{const value=await "+r+";return {..."+n+",ok:true,value};}\ncatch(error){return {..."+n+",ok:false,error:String(error?.message || error)};}})()":r}function hr(e,t,a){return t?"if(globalThis.OpenDeskLibs?.abi==="+JSON.stringify(Ea)+"&&globalThis._===globalThis.OpenDeskLibs.lodash&&globalThis.dayjs===globalThis.OpenDeskLibs.dayjs&&typeof globalThis.OpenDeskLibs.myUtils?.upper==='function'){\n"+e+"\n}else{"+(void 0===a?"throw Error('E_BUILTIN_NOT_READY')":"("+JSON.stringify({format:fr,nonce:a,ok:!1,error:"E_BUILTIN_NOT_READY"})+")")+"}":e}async function Er({sourceUtf8:e,entryFormat:t,entries:a=[],importSourceUrl:n,receiptNonce:r,builtinSource:i,jqueryCode:o,frameworkSource:s}={}){P("string"==typeof e&&e.trim().length>0&&(new TextEncoder).encode(e).byteLength<=pr,"E_SOURCE","页面脚本源码须为非空文本，且不超过 128 KiB"),P(ur.includes(t),"E_ENTRY_FORMAT","请选择经典用户脚本或 async main 入口")
const c=or(e,{importSourceUrl:n}),d=dr(c,{entryFormat:t,phase:"preview",dependenciesLocked:!0})
P(Array.isArray(a)&&a.length===c.requires.length,"E_DEPENDENCY_LOCK","源码依赖声明与已经批准的锁不同")
const l=gr(e,c),u="jquery"===l
P(u||void 0===o,"E_BUILTIN_CONFLICT","未声明内置 jQuery 却提供了依赖字节")
const p=l&&"jquery"!==l?lr[l]:null
P(p?s?.id===p.id&&s?.version===p.version&&s.sha256===p.sha256&&"string"==typeof s.code:void 0===s,"E_PAGE_FRAMEWORK_IDENTITY","Page framework selection differs from the fixed packaged runtime"),p&&P(await j(s.code)===p.sha256&&(new TextEncoder).encode(s.code).length===p.bytes,"E_DEPENDENCY_HASH","Page framework bytes do not match their pinned identity"),u&&P("string"==typeof o&&await j(o)===Ln.sha256,"E_DEPENDENCY_HASH","内置 jQuery 资源缺失或完整性不符")
const m=[]
if(void 0!==i&&(P(i?.abi===Ea&&"string"==typeof i.code&&/^[a-f0-9]{64}$/.test(i.sha256)&&await j(i.code)===i.sha256,"E_BUILTIN_HASH","预装库不是经过校验的固定资源"),m.push(i.code)),u&&(m.push("if(typeof globalThis.jQuery!=='undefined'||typeof globalThis.$!=='undefined')throw new Error('E_BUILTIN_COLLISION')"),m.push(o),m.push("if(globalThis.jQuery?.fn?.jquery!=='3.7.1')throw new Error('E_DEPENDENCY_NOT_READY')")),p){m.push(s.code)
const e=JSON.stringify(p.version),t="globalThis."+p.global
m.push("if("+t+"?.version!=="+e+')throw Error("E_PAGE_FRAMEWORK_NOT_READY")')}for(let I=0;I<a.length;I++){const e=a[I]
P(e?.order===I&&"string"==typeof e.code&&/^[a-f0-9]{64}$/.test(e.sha256)&&await j(e.code)===e.sha256,"E_DEPENDENCY_HASH","依赖内容与固定 SHA-256 不符"),m.push(e.code)}const f=wr(e,t,r)
m.push(f)
const g=(i?m.shift()+"\n;\n":"")+hr(m.join("\n;\n"),i,r)
return Object.freeze({sourceHash:await j(e),entryFormat:t,world:"USER_SCRIPT",js:Object.freeze([{code:g}]),warnings:d.warnings,receiptNonce:r,...u?{packagedJquerySha256:Ln.sha256}:{},...p?{packagedFrameworkId:p.id,packagedFrameworkSha256:p.sha256}:{},...i?{builtinAbi:Ea,builtinCatalogSha256:i.catalogSha256,builtinBundleSha256:i.sha256}:{}})}const yr="frameworkKV",br=Object.freeze({assetBytes:1048576,totalBytes:4194304,timeoutMs:2e4}),vr=Object.freeze({asset:e=>"userscript-asset:v1:sha256:"+e,review:(e,t)=>"userscript-review:v1:"+JSON.stringify([e,t]),lock:(e,t)=>"userscript-lock:v1:"+JSON.stringify([e,t]),source:(e,t)=>"userscript-source:v1:"+JSON.stringify([e,t]),manifest:(e,t)=>"userscript-manifest:v1:"+JSON.stringify([e,t]),reference:(e,t,a)=>"userscript-reference:v1:"+JSON.stringify([e,t,a])}),_r=new TextEncoder,Sr=/^[a-f0-9]{64}$/,Ar=new Map([["sha256","SHA-256"],["sha384","SHA-384"],["sha512","SHA-512"]]),Or=new Set(["application/javascript","text/javascript","application/x-javascript","application/ecmascript","text/ecmascript","text/plain"]),kr="第三方 JavaScript 可以读取或修改已授权网页的 DOM，也可能通过网页允许的网络渠道对外发送网页数据。USER_SCRIPT 隔离不是网络沙箱，也不提供 GM 或扩展宿主权限。",Tr=(e,t)=>{throw Object.assign(Error(t||e),{code:e})},Rr=(e,t,a)=>{e||Tr(t,a)},Nr=e=>structuredClone(e),Cr=e=>JSON.stringify(e,((e,t)=>t&&"object"==typeof t&&!Array.isArray(t)?Object.fromEntries(Object.keys(t).sort().map((e=>[e,t[e]]))):t)),Ur=(e,t)=>Cr(e)===Cr(t),Pr=(e,t)=>Rr(e&&"object"==typeof e&&!Array.isArray(e)&&Object.keys(e).every((e=>t.includes(e))),"E_SCHEMA","依赖请求含未知字段")
async function Dr(e,t="SHA-256"){return Rr(globalThis.crypto?.subtle,"E_HASH_UNAVAILABLE"),[...new Uint8Array(await crypto.subtle.digest(t,e))].map((e=>e.toString(16).padStart(2,"0"))).join("")}const xr=e=>Dr(_r.encode(Cr(e)))
function Lr(e){let t
try{t=new URL(e)}catch{Tr("E_DEPENDENCY_URL","依赖需要有效 HTTPS URL")}const a=t.hostname.toLowerCase()
return Rr("https:"===t.protocol&&!t.username&&!t.password&&!t.hash&&t.href.length<=4096&&!/^\[|^\d+(?:\.\d+){0,3}$/.test(a)&&a.includes(".")&&!/^(?:localhost|localhost\.)$|\.(?:localhost|local|internal)\.?$|(?:^|\.)home\.arpa\.?$/.test(a),"E_DEPENDENCY_URL","依赖下载仅支持无账户信息的公共 HTTPS 主机名，不接受 IP 或本地主机"),t}const Hr=e=>`https://${e.hostname}/*`
function Mr(e){const t=Lr(e)
return t.search||t.port?null:[{origin:"https://cdn.jsdelivr.net",path:"/npm/jquery@3.7.1/dist/jquery.min.js"},{origin:"https://unpkg.com",path:"/jquery@3.7.1/dist/jquery.min.js"},{origin:"https://code.jquery.com",path:"/jquery-3.7.1.min.js"}].some((e=>t.origin===e.origin&&t.pathname===e.path))?Ln:null}function jr(e){const t=new URL(e).pathname,a=/\/(?:npm\/)?((?:@[^/]+\/)?[^/@]+)@([^/]+)\//.exec(t)
return{name:a?.[1]||t.split("/").at(-1)||new URL(e).hostname,version:a?.[2]||null}}function qr(e){Rr("string"==typeof e.sourceUtf8&&_r.encode(e.sourceUtf8).byteLength<=131072,"E_SOURCE","页面脚本最大 128 KiB")
const t=void 0===e.entryFormat?"async-main":e.entryFormat
Rr(["classic-userscript","async-main"].includes(t),"E_ENTRY_FORMAT","页面入口必须明确为 classic-userscript 或 async-main")
const a=or(e.sourceUtf8,{importSourceUrl:e.importSourceUrl}),n={lockVersion:1,entryFormat:t,importSourceUrl:a.importSourceUrl||null,world:"USER_SCRIPT",requires:a.requires.map((e=>({order:e.order,raw:e.raw||e.originalUrl||e.url,originalUrl:e.originalUrl||e.url,url:e.url,integrity:e.integrity||[]})))}
return{parsed:a,manifest:n,entryFormat:t}}function Fr(e){try{return new TextDecoder("utf-8",{fatal:!0,ignoreBOM:!0}).decode(e)}catch{Tr("E_DEPENDENCY_ENCODING","依赖必须是有效 UTF-8 原始字节")}}async function Wr(e,t){const a=t.integrity||[],n=a.filter((e=>Ar.has(e.algorithm)))
Rr(!a.length||n.length,"E_DEPENDENCY_INTEGRITY_UNSUPPORTED","弱哈希不能独立批准依赖；请提供 SHA-256/384/512 或重新审核无哈希来源")
for(const r of n)Rr(await Dr(e,Ar.get(r.algorithm))===r.digestHex,"E_DEPENDENCY_INTEGRITY","下载资源与声明的 "+r.algorithm+" 不符")
return{verified:n.map((e=>e.algorithm)),ignoredWeak:a.filter((e=>!Ar.has(e.algorithm))).map((e=>e.algorithm))}}async function zr(e,t,a){return Rr("userscript-asset-v1"===e?.tag&&e.sha256===t&&Sr.test(t)&&e.bytes instanceof ArrayBuffer&&e.byteLength===e.bytes.byteLength&&e.byteLength>0&&e.byteLength<=br.assetBytes&&(void 0===a||e.byteLength===a),"E_DEPENDENCY_ASSET","已缓存依赖的字节或大小不合法"),Rr(await Dr(e.bytes)===t,"E_DEPENDENCY_HASH","已缓存依赖内容被修改"),{asset:e,code:Fr(e.bytes)}}function Vr(e){return{reviewId:e.reviewId,namespace:e.namespace,manifest:e.manifest,manifestDigest:e.manifestDigest,entries:e.entries,totalBytes:e.totalBytes,createdAt:e.createdAt}}async function Kr(e,t,a){return Rr("userscript-lock-v1"===e?.tag&&"locked"===e.status&&"approved"===e.approvalStatus&&e.namespace===t&&e.lockId===a&&1===e.lockVersion&&"USER_SCRIPT"===e.world&&Array.isArray(e.entries)&&e.entries.every(((e,t)=>e.order===t&&"USER_SCRIPT"===e.world&&Sr.test(e.sha256))),"E_DEPENDENCY_LOCK","依赖锁不存在、未批准或不属于当前身份"),Rr(e.manifestDigest===await xr(e.manifest)&&a==="dep-lock-"+await xr(function(e){return{lockVersion:e.lockVersion,namespace:e.namespace,manifestDigest:e.manifestDigest,manifest:e.manifest,world:e.world,reviewId:e.reviewId,approvedAt:e.approvedAt,entries:e.entries}}(e)),"E_DEPENDENCY_LOCK","不可变依赖锁校验失败"),e}const Br=e=>Nr({lockId:e.lockId,lockVersion:e.lockVersion,manifestDigest:e.manifestDigest,status:e.status,approvalStatus:e.approvalStatus,world:e.world,approvedAt:e.approvedAt,entries:e.entries})
function Gr({api:e,storage:t,assertHost:a,fetchImpl:n=globalThis.fetch,clock:r={now:()=>Date.now()},loadBuiltin:i=Oa}){Rr(e&&"function"==typeof t?.transaction&&"function"==typeof a,"E_SCHEMA","可信依赖管理器缺少宿主服务")
const o=()=>{const e=r.now()
return Rr(Number.isSafeInteger(e)&&e>=0,"E_SCHEMA"),e}
async function s(e,t){const n=await a(e)
return Rr("string"==typeof n?.namespace&&n.namespace&&"string"==typeof n.registrationId,"E_OWNER","依赖操作必须来自已注册工具宿主"),t&&Rr(["namespace","registrationId","hostDocumentId","hostInstanceId","browserSessionIncarnation","hostUrl"].every((e=>n[e]===t[e])),"E_OWNER","审核过程中宿主身份已改变"),n}async function c(e,a,n){return t.transaction([yr,"commandJournal"],a,(async t=>{const a=await t.get("commandJournal","host:"+e.registrationId)
return Rr("host"===a?.tag&&a.active&&!a.revoked&&["registrationId","hostDocumentId","hostInstanceId","browserSessionIncarnation","hostUrl"].every((t=>a[t]===e[t])),"E_OWNER","工具宿主已关闭、被撤销或发生变化"),n(t)}))}async function d(e,t,a){if(!a.url)return[]
const n=await e.get(yr,vr.source(t,a.url)),r=[]
for(const i of n?.choices||[]){const n=await Kr(await e.get(yr,vr.lock(t,i.lockId)),t,i.lockId),o=n.entries[i.order]
Rr(o?.url===a.url,"E_DEPENDENCY_LOCK"),r.some((e=>e.sha256===o.sha256))||r.push({...Nr(o),lockId:n.lockId,status:"approved-cache"})}return r}async function l(t,a){const r=Lr(t.url),i=Hr(r)
Rr(await(e.permissions?.contains?.({origins:[i]})),"E_DEPENDENCY_PERMISSION","请先明确授权下载来源："+r.origin),Rr("function"==typeof n,"E_RESOURCE_UNAVAILABLE")
const o=new AbortController,s=setTimeout((()=>o.abort()),br.timeoutMs)
let c
try{const t=await n(r.href,{method:"GET",credentials:"omit",referrerPolicy:"no-referrer",cache:"no-store",redirect:"error",signal:o.signal})
Rr(t?.ok&&t.status>=200&&t.status<300,"E_DEPENDENCY_FETCH","依赖下载响应失败"),Rr(!t.redirected&&!["opaque","opaqueredirect"].includes(t.type)&&t.url===r.href,"E_DEPENDENCY_REDIRECT","本阶段拒绝所有依赖重定向；请声明最终 HTTPS URL")
const s=t.headers?.get("content-type")||"",d=s.split(";")[0].trim().toLowerCase()
Rr(Or.has(d),"E_DEPENDENCY_CONTENT_TYPE","依赖响应必须是 JavaScript 或 text/plain，不能是 HTML/JSON")
const l=/;\s*charset\s*=\s*"?([^;"\s]+)/i.exec(s)?.[1].toLowerCase()
Rr(!l||["utf-8","utf8","us-ascii"].includes(l),"E_DEPENDENCY_ENCODING","依赖响应编码必须为 UTF-8")
const u=Math.min(a,br.assetBytes),p=t.headers?.get("content-length")
null!=p&&Rr(/^\d+$/.test(p)&&Number(p)<=u,"E_DEPENDENCY_LIMIT","依赖超过下载大小上限"),Rr(t.body?.getReader,"E_DEPENDENCY_FETCH","依赖下载需要可限长的响应流"),c=t.body.getReader()
const m=[]
let f=0
for(;;){const e=await c.read()
if(e.done)break
Rr(e.value instanceof Uint8Array,"E_DEPENDENCY_FETCH"),f+=e.value.byteLength,Rr(f<=u,"E_DEPENDENCY_LIMIT","单个依赖最多 1 MiB，整组最多 4 MiB"),m.push(e.value)}Rr(f>0,"E_DEPENDENCY_FETCH","依赖响应为空")
const g=new Uint8Array(f)
let I=0
for(const e of m)g.set(e,I),I+=e.byteLength
const w=Fr(g)
return Rr(!/^(?:\uFEFF)?\s*(?:<!doctype\s+html|<html\b|<head\b|<body\b)/i.test(w),"E_DEPENDENCY_CONTENT_TYPE","依赖来源返回了 HTML 错误页面"),Rr("us-ascii"!==l||g.every((e=>e<128)),"E_DEPENDENCY_ENCODING"),Rr(await(e.permissions?.contains?.({origins:[i]})),"E_DEPENDENCY_PERMISSION","依赖下载期间来源权限已撤销"),{bytes:g.buffer,sourceKind:"https",resolvedUrl:t.url,acquisition:"download",mime:d,license:{status:"unknown",name:null,source:null},integrityRepresentation:"fetch-response-bytes"}}catch(d){if(d.code)throw d
Tr(o.signal.aborted?"E_DEPENDENCY_TIMEOUT":"E_DEPENDENCY_FETCH",o.signal.aborted?"依赖下载超过 20 秒":"依赖下载失败；重定向、网络错误或浏览器阻止均不会被绕过")}finally{if(clearTimeout(s),o.abort(),c)try{await c.cancel()}catch{}}}async function u(e){Pr(e,["name","bytesBase64","license"]),Rr("string"==typeof e.name&&e.name.length>0&&e.name.length<=128&&!/[\x00-\x1f/\\]/.test(e.name),"E_DEPENDENCY_LOCAL","本地依赖需要不含路径的文件名"),Rr("string"==typeof e.bytesBase64&&e.bytesBase64.length<=4*Math.ceil(br.assetBytes/3)&&/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(e.bytesBase64),"E_DEPENDENCY_LOCAL","本地依赖字节必须为有界 Base64")
const t=atob(e.bytesBase64)
Rr(btoa(t)===e.bytesBase64&&t.length>0,"E_DEPENDENCY_LOCAL")
const a=Uint8Array.from(t,(e=>e.charCodeAt(0)))
return Fr(a),Rr(void 0===e.license||"string"==typeof e.license&&e.license.length>0&&e.license.length<=128,"E_DEPENDENCY_LOCAL"),{bytes:a.buffer,sourceKind:"local-file",resolvedUrl:"local:"+e.name,acquisition:"local-import",mime:null,license:e.license?{status:"declared",name:e.license,source:"user-provided-file"}:{status:"unknown",name:null,source:null},integrityRepresentation:"original-file-bytes"}}async function p(e,t){Pr(e,["sourceUtf8","entryFormat","importSourceUrl","lockId"])
const a=await s(t),n=await m(e,a.namespace,(e=>c(a,"readonly",e)))
return await s(t,a),n}async function m(e,t,a){const{parsed:n,manifest:r,entryFormat:i}=qr(e),o=await xr(r)
return dr(n,{entryFormat:i,phase:"preview",dependenciesLocked:!0}),n.requires.length?(Rr("string"==typeof e.lockId&&/^dep-lock-[a-f0-9]{64}$/.test(e.lockId),"E_DEPENDENCY_UNLOCKED","请先下载、审核并锁定依赖"),await a((async a=>{const i=await Kr(await a.get(yr,vr.lock(t,e.lockId)),t,e.lockId)
Rr(i.manifestDigest===o&&Ur(i.manifest,r)&&i.entries.length===n.requires.length,"E_DEPENDENCY_LOCK_STALE","依赖声明、来源身份或入口模式已改变，请建立新的依赖锁")
const s=[]
let c=0
for(const[e,t]of i.entries.entries()){Rr(t.order===e&&t.url===n.requires[e].url,"E_DEPENDENCY_LOCK")
const{asset:r,code:i}=await zr(await a.get(yr,vr.asset(t.sha256)),t.sha256,t.byteLength)
c+=r.byteLength,Rr(c<=br.totalBytes,"E_DEPENDENCY_LIMIT"),await Wr(r.bytes,n.requires[e]),s.push({...Nr(t),code:i})}return{lockId:i.lockId,manifestDigest:o,entries:s,world:"USER_SCRIPT"}}))):(Rr(!e.lockId,"E_DEPENDENCY_LOCK","无依赖源码不能冒用其他依赖锁"),{lockId:null,manifestDigest:o,entries:[],world:"USER_SCRIPT"})}const f=(e,t,a)=>"page-candidate:"+Cr([e,t,a]),g=e=>({candidateId:e.candidateId,manifestHash:e.manifestHash,stage:"Candidate"})
async function I(e,t){return Rr("page-candidate-v1"===e?.tag&&e.namespace===t&&"Candidate"===e.stage&&null===e.verification&&"string"==typeof e.sourceUtf8,"E_PAGE_CANDIDATE"),Rr(e.manifestHash===await xr(e.manifest)&&e.manifest.sourceHash===await Dr(_r.encode(e.sourceUtf8)),"E_HASH"),e}return Object.freeze({inspect:async function(t,a){Pr(t,["sourceUtf8","entryFormat","importSourceUrl"])
const n=await s(a),{parsed:r,manifest:i,entryFormat:o}=qr(t),l=await xr(i),u=await c(n,"readonly",(async e=>{const t=[]
for(const o of r.requires){let a=null,r=null
try{o.url&&(a=Mr(o.url))}catch(s){r={code:s.code,message:s.message}}const i=await d(e,n.namespace,o)
t.push({...Nr(o),...o.url?jr(o.url):{},sourceKind:a?"packaged":"https",status:r?"unsupported":i.length?"approved-cache":"needs-review",cacheChoices:i,downloadError:r,risk:kr,license:a?{status:"known",name:a.license,source:"extension-package"}:{status:"unknown",name:null,source:null}})}const a=await e.get(yr,vr.manifest(n.namespace,l)),i=[]
for(const r of(a?.lockIds||[]).slice(0,20))i.push(Br(await Kr(await e.get(yr,vr.lock(n.namespace,r)),n.namespace,r)))
return{manifestDigest:l,requires:t,locks:i,admission:cr(r,{entryFormat:o,phase:"preview",dependenciesLocked:i.length>0})}}))
u.permissionOrigins=[]
for(const s of u.requires.filter((e=>e.url&&"https"===e.sourceKind&&!e.downloadError))){const t=Hr(Lr(s.url))
u.permissionOrigins.includes(t)||await(e.permissions?.contains?.({origins:[t]}))||u.permissionOrigins.push(t)}return await s(a,n),u},prepare:async function(t,a){Pr(t,["sourceUtf8","entryFormat","importSourceUrl","explicitUserAction","selections"]),Rr(!0===t.explicitUserAction,"E_DEPENDENCY_REVIEW","下载依赖需要用户明确操作")
const r=await s(a),{parsed:i,manifest:p,entryFormat:m}=qr(t)
dr(i,{entryFormat:m,phase:"preview",dependenciesLocked:!0}),Rr(i.requires.length>0,"E_DEPENDENCY_EMPTY","源码没有 @require")
const f=t.selections||[]
Rr(Array.isArray(f)&&f.length<=i.requires.length,"E_SCHEMA")
const g=new Map
for(const e of f)Pr(e,["order","assetSha256","localFile"]),Rr(Number.isSafeInteger(e.order)&&e.order>=0&&e.order<i.requires.length&&!g.has(e.order)&&!(e.assetSha256&&e.localFile)&&(void 0===e.assetSha256||Sr.test(e.assetSha256)),"E_SCHEMA"),g.set(e.order,e)
const I=new Map,w=[],h=new Map
let E=0
for(const s of i.requires){Lr(s.url)
const t=g.get(s.order)
let a
if(t?.assetSha256)a=await c(r,"readonly",(async e=>{const a=(await d(e,r.namespace,s)).find((e=>e.sha256===t.assetSha256))
Rr(a,"E_DEPENDENCY_REVIEW","当前身份尚未批准该声明来源的所选缓存")
const{asset:n}=await zr(await e.get(yr,vr.asset(a.sha256)),a.sha256,a.byteLength)
return{...a,bytes:n.bytes,acquisition:"approved-cache",reusedFrom:{lockId:a.lockId}}}))
else if(t?.localFile)a=await u(t.localFile)
else if(h.has(s.url))a=h.get(s.url)
else{const t=Mr(s.url)
if(t){const r=await Mn({runtime:e.runtime,fetchImpl:n})
a={bytes:_r.encode(r.code).buffer,sourceKind:"packaged",resolvedUrl:e.runtime.getURL(t.path),acquisition:"extension-package",mime:"text/javascript",license:{status:"known",name:t.license,source:"extension-package"},integrityRepresentation:"packaged-utf8-bytes",name:t.id,version:t.version}}else a=await l(s,br.totalBytes-E)
h.set(s.url,a)}Rr(a.bytes.byteLength>0&&a.bytes.byteLength<=br.assetBytes,"E_DEPENDENCY_LIMIT"),E+=a.bytes.byteLength,Rr(E<=br.totalBytes,"E_DEPENDENCY_LIMIT","整组依赖最多 4 MiB，重复声明也计入执行预算")
const i=await Wr(a.bytes,s),p=await Dr(a.bytes)
Fr(a.bytes),I.set(p,{tag:"userscript-asset-v1",sha256:p,bytes:a.bytes,byteLength:a.bytes.byteLength,integrityStatus:"verified",createdAt:o()}),w.push({order:s.order,raw:s.raw||s.originalUrl||s.url,originalUrl:s.originalUrl||s.url,url:s.url,...jr(s.url),...a.name?{name:a.name,version:a.version}:{},sourceKind:a.sourceKind,resolvedUrl:a.resolvedUrl,acquisition:a.acquisition,reusedFrom:a.reusedFrom||null,sha256:p,byteLength:a.bytes.byteLength,world:"USER_SCRIPT",integrity:Nr(s.integrity||[]),integrityResult:i,integrityRepresentation:a.integrityRepresentation,license:a.license,mime:a.mime,risk:kr})}const y="dep-review-"+crypto.randomUUID(),b=await xr(p),v={tag:"userscript-review-v1",reviewId:y,namespace:r.namespace,status:"pending-review",approvalStatus:"pending",manifest:p,manifestDigest:b,entries:w,totalBytes:E,createdAt:o()}
return v.reviewDigest=await xr(Vr(v)),await s(a,r),await c(r,"readwrite",(async e=>{for(const[t,a]of I){const n=await e.get(yr,vr.asset(t))
n?await zr(n,t,a.byteLength):await e.put(yr,a,vr.asset(t))}await e.put(yr,v,vr.review(r.namespace,y)),await e.put(yr,{tag:"userscript-reference-v1",namespace:r.namespace,ownerType:"review",ownerId:y,assetHashes:[...I.keys()]},vr.reference(r.namespace,"review",y))})),Nr({reviewId:y,manifestDigest:b,status:v.status,approvalStatus:v.approvalStatus,entries:w,totalBytes:E})},approve:async function(e,t){Pr(e,["reviewId","explicitUserAction","acceptedHashes"]),Rr(!0===e.explicitUserAction&&/^dep-review-[a-f0-9-]{36}$/.test(e.reviewId),"E_DEPENDENCY_REVIEW","请明确审核下载后的来源、内容哈希和风险"),Rr(Array.isArray(e.acceptedHashes)&&e.acceptedHashes.every((e=>Sr.test(e))),"E_DEPENDENCY_REVIEW")
const a=await s(t),n=await c(a,"readonly",(async t=>{const n=await t.get(yr,vr.review(a.namespace,e.reviewId))
Rr("userscript-review-v1"===n?.tag&&n.namespace===a.namespace&&n.reviewId===e.reviewId&&Array.isArray(n.entries)&&Ur(e.acceptedHashes,n.entries.map((e=>e.sha256)))&&n.manifestDigest===await xr(n.manifest)&&n.reviewDigest===await xr(Vr(n)),"E_DEPENDENCY_REVIEW","审核记录或明确接受的哈希不匹配")
for(const e of n.entries){const{asset:a}=await zr(await t.get(yr,vr.asset(e.sha256)),e.sha256,e.byteLength)
await Wr(a.bytes,e)}return n})),r={lockVersion:1,namespace:a.namespace,manifestDigest:n.manifestDigest,manifest:n.manifest,world:"USER_SCRIPT",reviewId:n.reviewId,approvedAt:o(),entries:n.entries},i={tag:"userscript-lock-v1",...r,lockId:"dep-lock-"+await xr(r),status:"locked",approvalStatus:"approved"}
return await s(t,a),c(a,"readwrite",(async t=>{const r=await t.get(yr,vr.review(a.namespace,e.reviewId))
if(r?.lockId){const i=await Kr(await t.get(yr,vr.lock(a.namespace,r.lockId)),a.namespace,r.lockId)
return Rr(Ur(Vr(r),Vr(n))&&i.reviewId===n.reviewId&&i.manifestDigest===n.manifestDigest&&Ur(i.manifest,n.manifest)&&Ur(i.entries,n.entries)&&Ur(i.entries.map((e=>e.sha256)),e.acceptedHashes),"E_DEPENDENCY_REVIEW","已有批准锁不属于当前审核或明确接受的资源"),Br(i)}Rr(Ur(r,n),"E_DEPENDENCY_REVIEW","审核内容在批准前发生变化")
for(const e of i.entries)await zr(await t.get(yr,vr.asset(e.sha256)),e.sha256,e.byteLength)
await t.put(yr,i,vr.lock(a.namespace,i.lockId)),await t.put(yr,{...r,status:"reviewed",approvalStatus:"approved",lockId:i.lockId},vr.review(a.namespace,e.reviewId))
const o=vr.manifest(a.namespace,i.manifestDigest),s=await t.get(yr,o)
await t.put(yr,{tag:"userscript-manifest-index-v1",namespace:a.namespace,manifestDigest:i.manifestDigest,lockIds:[i.lockId,...s?.lockIds||[]]},o)
for(const e of new Set(i.entries.map((e=>e.url)))){const n=vr.source(a.namespace,e),r=await t.get(yr,n),o=[]
for(const t of i.entries.filter((t=>t.url===e)))o.some((e=>e.sha256===t.sha256))||o.push({lockId:i.lockId,order:t.order,sha256:t.sha256})
const s=(r?.choices||[]).filter((e=>!o.some((t=>t.sha256===e.sha256))))
await t.put(yr,{tag:"userscript-source-index-v1",namespace:a.namespace,url:e,choices:[...o,...s]},n)}return await t.put(yr,{tag:"userscript-reference-v1",namespace:a.namespace,ownerType:"lock",ownerId:i.lockId,assetHashes:[...new Set(i.entries.map((e=>e.sha256)))]},vr.reference(a.namespace,"lock",i.lockId)),Br(i)}))},loadForExecution:p,importPageCandidate:async function(t,a){Pr(t,["programId","revision","sourceUtf8","entryFormat","importSourceUrl","lockId","pageRules"]),t=Nr(t),Rr("string"==typeof t.programId&&/^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/.test(t.programId)&&Number.isSafeInteger(t.revision)&&t.revision>0,"E_REVISION"),Rr("string"==typeof t.sourceUtf8&&t.sourceUtf8.trim().length>0,"E_SOURCE","页面程序源码不能为空")
const{parsed:r,entryFormat:d}=qr(t),l=Kn(r,dr(r,{entryFormat:d,phase:"preview",dependenciesLocked:!0}),t.pageRules),u=await p({sourceUtf8:t.sourceUtf8,entryFormat:d,importSourceUrl:t.importSourceUrl,lockId:t.lockId},a),m={format:"opendesk.page-program.v1",runtimeKind:"page-userscript",programId:t.programId,revision:t.revision,sourceHash:await Dr(_r.encode(t.sourceUtf8)),entryFormat:d,sourceProfile:{metadataProfile:r.profile,importSourceUrl:r.importSourceUrl},dependencyLockId:u.lockId,dependencyManifestDigest:u.manifestDigest,pageRules:l},w=Ta(await i({runtime:e.runtime,fetchImpl:n})),h=await xr(m),E=await s(a)
return c(E,"readwrite",(async e=>{const a=f(E.namespace,m.programId,m.revision),n=await e.get(yr,a)
if(n)return await I(n,E.namespace),Rr(n.manifestHash===h&&n.sourceUtf8===t.sourceUtf8,"E_REQUEST_CONFLICT"),Ra(n.builtinIdentity,w),g(n)
const r={tag:"page-candidate-v1",namespace:E.namespace,candidateId:"page-"+await xr([E.namespace,h,w]),builtinIdentity:w,manifestHash:h,manifest:m,sourceUtf8:t.sourceUtf8,stage:"Candidate",verification:null,createdAt:o()}
return await e.put(yr,r,a),g(r)}))},getPageCandidate:async function(e,t){Pr(e,["programId","revision"])
const a=await s(t)
return c(a,"readonly",(async t=>{const n=await I(await t.get(yr,f(a.namespace,e.programId,e.revision)),a.namespace)
return{...g(n),manifest:Nr(n.manifest),sourceUtf8:n.sourceUtf8,builtinIdentity:n.builtinIdentity}}))},readStoredPageCandidate:async function(e,a,n){Rr("string"==typeof e&&e.length>0,"E_OWNER")
const r=e=>t.transaction([yr],"readonly",e),i=await r((async t=>Nr(await I(await t.get(yr,f(e,a,n)),e))))
return{candidate:i,resolution:await m({sourceUtf8:i.sourceUtf8,entryFormat:i.manifest.entryFormat,importSourceUrl:i.manifest.sourceProfile.importSourceUrl,lockId:i.manifest.dependencyLockId},e,r)}}})}const Jr="page-userscript",$r=/^[a-f0-9]{64}$/,Yr=/^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/,Zr=/^dep-lock-[a-f0-9]{64}$/
function Qr(e,t){P(e&&"object"==typeof e&&!Array.isArray(e)&&[Object.prototype,null].includes(Object.getPrototypeOf(e))&&Object.keys(e).every((e=>t.includes(e)))&&t.every((t=>Object.hasOwn(e,t))),"E_PAGE_CONTRACT","页面程序合同字段不完整或含未知字段")}function Xr(e){return e&&"object"==typeof e&&!Object.isFrozen(e)&&(Object.values(e).forEach(Xr),Object.freeze(e)),e}function ei(e){Qr(e,["format","runtimeKind","programId","revision","sourceHash","entryFormat","sourceProfile","dependencyLockId","dependencyManifestDigest","pageRules"]),P("opendesk.page-program.v1"===e.format&&e.runtimeKind===Jr,"E_PAGE_KIND","需要明确的 Page Program v1；不能把 Controller Task 当成页面脚本"),P("string"==typeof e.programId&&Yr.test(e.programId)&&Number.isSafeInteger(e.revision)&&e.revision>0&&"string"==typeof e.sourceHash&&$r.test(e.sourceHash),"E_REVISION","页面程序必须引用固定的程序 ID、版本和源码 SHA-256"),P(["classic-userscript","async-main"].includes(e.entryFormat),"E_ENTRY_FORMAT","页面入口必须明确为 classic-userscript 或 async-main"),Qr(e.sourceProfile,["metadataProfile","importSourceUrl"]),P("opendesk-d1"===e.sourceProfile.metadataProfile,"E_PAGE_PROFILE","不支持的源码解析配置")
const t=or("",{importSourceUrl:e.sourceProfile.importSourceUrl})
return P(!t.diagnostics.length&&t.importSourceUrl===e.sourceProfile.importSourceUrl,"E_IMPORT_SOURCE","来源身份须为真实、规范化的脚本导入 URL 或 null"),P((null===e.dependencyLockId||Zr.test(e.dependencyLockId))&&$r.test(e.dependencyManifestDigest),"E_DEPENDENCY_LOCK","页面程序必须绑定依赖声明摘要和不可变锁"),Vn(e.pageRules),H(e),Xr(structuredClone(e))}const ti=/^[0-9a-f]{64}$/,ai=/^[A-Za-z0-9][A-Za-z0-9_.-]{0,127}$/,ni=(e,t)=>{e||(e=>{const t=Error(e)
throw t.code=e,t})(t)}
async function ri(e){ni("string"==typeof e&&"function"==typeof crypto?.subtle?.digest,"E_HASH_UNAVAILABLE")
const t=await crypto.subtle.digest("SHA-256",(new TextEncoder).encode(e))
return[...new Uint8Array(t)].map((e=>e.toString(16).padStart(2,"0"))).join("")}const ii=e=>Object.assign(Error(e),{code:e})
async function oi(e,{runtime:t=globalThis.chrome?.runtime,fetchImpl:a=globalThis.fetch}={}){const n=Object.hasOwn(lr,e)?lr[e]:null
if(!n)throw ii("E_PAGE_FRAMEWORK_UNKNOWN")
if("function"!=typeof t?.getURL||"function"!=typeof a)throw ii("E_RESOURCE_UNAVAILABLE")
let r,i,o,s
try{r=t.getURL(""),i=t.getURL(n.output)}catch{throw ii("E_RESOURCE_IDENTITY")}if(!/^chrome-extension:\/\/[^/?#]+\/$/.test(r)||i!==r+n.output||t.id&&r!=="chrome-extension://"+t.id+"/")throw ii("E_RESOURCE_IDENTITY")
try{o=await a(i,{cache:"no-store",credentials:"omit"})}catch{throw ii("E_RESOURCE_UNAVAILABLE")}if(!o?.ok||o.redirected||o.url&&o.url!==i)throw ii("E_RESOURCE_UNAVAILABLE")
try{s=await o.text()}catch{throw ii("E_RESOURCE_UNAVAILABLE")}if("string"!=typeof s||(new TextEncoder).encode(s).length!==n.bytes||n.bytes>262144||await j(s)!==n.sha256)throw ii("E_DEPENDENCY_HASH")
return Object.freeze({id:n.id,version:n.version,sha256:n.sha256,code:s})}const si="opendeskPagePreviewWorldsD1",ci="opendesk-preview-d1-",di=()=>crypto.randomUUID().replaceAll("-","")
function li(e,t){P(e&&"object"==typeof e&&!Array.isArray(e)&&(Object.getPrototypeOf(e)===Object.prototype||null===Object.getPrototypeOf(e))&&Object.keys(e).every((e=>t.includes(e)))&&t.every((t=>Object.hasOwn(e,t))),"E_SCHEMA","Unexpected page preview fields")}function ui(e){li(e,["tabId","frameId","documentId","expectedUrl","expectedWindowId"])
const t=a(e.expectedUrl)
return P(Number.isSafeInteger(e.tabId)&&e.tabId>=0&&0===e.frameId&&Number.isSafeInteger(e.expectedWindowId)&&e.expectedWindowId>=0&&"string"==typeof e.documentId&&e.documentId.length>0&&e.documentId.length<=128&&t.href===e.expectedUrl,"E_TARGET","Only the exact current HTTP(S) main document is supported"),Object.freeze({...e})}function pi(e){return{capabilities:["page.dom"],pageRules:structuredClone(Vn(e)),networkOrigins:[]}}function mi(e,t){const a=e?.pageRules,n=t.pageRules,r=n.matches.filter((e=>!a?.matches.includes(e))),i=(a?.excludeMatches||[]).filter((e=>!n.excludeMatches.includes(e))),o=!!a&&["runAt","allFrames","world"].some((e=>a[e]!==n[e]))
return{requiresConfirmation:!e||!!(r.length||i.length||o),addedSites:r,removedExclusions:i,changedExecution:o}}function fi(e){const t=e.authorization
return P("page-install-authorization-v1"===t?.tag&&"string"==typeof t.installationId&&/^[a-f0-9-]{36}$/.test(t.installationId)&&Number.isSafeInteger(t.generation)&&t.generation>0&&["active","disabled","suspended","needs-confirmation"].includes(t.status)&&Number.isSafeInteger(t.approvedAt)&&H(t.scope)===H(pi(e.pageRules)),"E_PAGE_AUTHORIZATION","程序安装授权与固定版本的能力范围不一致"),t}function gi(e){if("<all_urls>"===e)return["*","*"]
const t="string"==typeof e&&e.match(/^(\*|https?):\/\/([^/]+)\//),a=t&&t[2].toLowerCase().match(/^(\[[^\]]+\]|[^:]+)(?::(?:\*|[0-9]+))?$/)?.[1]
return a?[t[1],a]:null}function Ii(e,t){return!!t.permissions?.includes("userScripts")||(t.origins||[]).some((t=>e.matches.some((e=>{const a=gi(t),n=gi(e)
if(!a||!n)return!1
if(a[0]!==n[0]&&"*"!==a[0]&&"*"!==n[0])return!1
const r=(e,t)=>"*"===e||e===t||e.startsWith("*.")&&(t===e.slice(2)||t.endsWith("."+e.slice(2)))
return r(a[1],n[1])||r(n[1],a[1])}))))}const wi="frameworkKV",hi="page-installed-v1",Ei="installed",yi="readwrite",bi="E_PERMISSION",vi="E_EFFECT_UNKNOWN",_i="E_REVISION",Si="opendesk.page-installed.boot.v1",Ai="opendesk-page-installed-bootstrap-v1",Oi="opendesk-page-boot-",ki="访问受限，请检查安装并恢复访问",Ti=(e,t,...a)=>"page-"+e+":"+H([t,...a]),Ri=(e,t,a=t)=>P(e&&"object"==typeof e&&!Array.isArray(e)&&Object.keys(e).every((e=>t.includes(e)))&&a.every((t=>Object.hasOwn(e,t))),"E_SCHEMA","页面安装请求字段不完整或包含未知字段"),Ni=["builtinIdentity","candidateId","namespace","manifestHash","runtimeKind","entryFormat","programId","revision","sourceHash","dependencyLockId","dependencyManifestDigest","approvedPageRules"],Ci=(e,t)=>H(e)===H(t)
function Ui(e){const t=e.manifest
return{builtinIdentity:e.builtinIdentity,candidateId:e.candidateId,namespace:e.namespace,manifestHash:e.manifestHash,runtimeKind:t.runtimeKind,entryFormat:t.entryFormat,programId:t.programId,revision:t.revision,sourceHash:t.sourceHash,dependencyLockId:t.dependencyLockId,dependencyManifestDigest:t.dependencyManifestDigest,approvedPageRules:t.pageRules}}async function Pi(e,t){P(t?.builtinAbi===Ea&&t.builtinCatalogSha256===await j(JSON.stringify(ya))&&/^[a-f0-9]{64}$/.test(t.builtinBundleSha256),"E_PAGE_ENVIRONMENT","内置库 ABI 或固定资源目录已更新；请创建新版本并重新验证"),Ra(e.builtinIdentity,Ta(t)),P(!Ir(e.sourceUtf8)||t.packagedJquerySha256===Ln.sha256,"E_PAGE_ENVIRONMENT","内置库环境已变化；请载入并保存新版本后验证安装")
const a=gr(e.sourceUtf8)
a&&"jquery"!==a&&P(t.packagedFrameworkId===a&&t.packagedFrameworkSha256===lr[a].sha256,"E_PAGE_ENVIRONMENT","固定框架代码已经变化，旧回执不可用于新版本")}const Di=e=>e?{programId:e.programId,revision:e.revision,manifestHash:e.manifestHash,sourceHash:e.sourceHash,pageRules:e.pageRules,enabled:e.enabled,nativeId:e.nativeId,nativeState:e.nativeState,authorization:e.authorization?structuredClone(e.authorization):null,error:e.error,lastExecution:e.lastExecution?xi(e.lastExecution):null}:null
function xi(e){const{installationToken:t,...a}=e
return a}const Li=new Set(["claimRun","snapshotRun","prepareCommand","dispatchCommand","stopRun","abandonUnknown","finishRun","createTarget","reconcileTargetCreation","bindTarget","retireTarget","ackPageFrame","ackSourceFrame","openSourceContext","startSourceSelection","cancelSourceSelection","releaseSourceContext","previewSource","saveTemplate","listTemplates","getTemplateRevision","renameTemplate","beginPage","stagePageBatch","sealPage","readRecords","openReaderPin","releaseReaderPin","prepareExport","prepareAttempts","retryExport","abandonExport","getEntitlementSnapshot","entitlementStatus","installEntitlement","revokeEntitlement","deleteRun"])
function Hi(e,t){return Object.fromEntries(t.map((t=>[t,(a,n)=>e[t](a,n)])))}function Mi({authority:e,api:t}){return async(a,n)=>{const r=await e.grantSdk(a,n),i=function({api:e=globalThis.chrome,authorize:t}={}){return Object.freeze({async injectFixed({target:a,file:n,world:r},i){if(!t)throw Re("E_PERMISSION")
if(Ce(a,["tabId","documentIds"],["tabId","documentIds"]),!a||!Number.isInteger(a.tabId)||a.tabId<0||!Array.isArray(a.documentIds)||1!==a.documentIds.length||"string"!=typeof a.documentIds[0]||!(n===ke.relay&&"ISOLATED"===r||n===ke.main&&"MAIN"===r))throw Re("E_SCHEMA","Exact document and fixed world/resource required")
await t({capability:"sdk.inject",target:a,file:n,world:r,phase:"pre"},i)
const o=await Ke(e,e.scripting,"executeScript",{target:a,world:r,files:[n]})
return await t({capability:"sdk.inject",target:a,file:n,world:r,phase:"post"},i),o}})}({api:t,authorize:()=>e.authorizeSdkInjection(a,n,r.grantIncarnation)}),o={tabId:a.tabId,documentIds:[a.documentId]}
try{return await i.injectFixed({target:o,file:ke.relay,world:"ISOLATED"}),await i.injectFixed({target:o,file:ke.main,world:"MAIN"}),{...r,installed:!0,files:[ke.relay,ke.main]}}catch(s){throw await e.revokeSdkGrants({tabId:a.tabId,frameId:a.frameId,documentId:a.documentId,grantIncarnation:r.grantIncarnation,reason:"installation-failed"}),s}}}async function ji({api:e,authority:t,consumer:a,downloads:n},r,i){const o=0===(await e.runtime.getContexts({documentIds:[i]})).length
return await t.loseHost(r,{documentGone:o}),o&&(await(a?.invalidateHost(r)),await(a?.reconcileRetirements()),await(n?.reconcileHostResources())),o}async function qi({api:e},t){try{return(await e.runtime.getContexts({documentIds:[t]})).length?"live":"missing"}catch{return"unknown"}}async function Fi({api:e,storage:t,session:a,authority:n,consumer:r}){if("function"!=typeof e.runtime.getContexts)return[]
const i=await t.transaction(["commandJournal"],"readonly",(async e=>(await e.all("commandJournal")).filter((e=>"host"===e?.tag&&e.active&&e.browserSessionIncarnation===a)))),o=[]
for(const s of i){const t=await qi({api:e},s.hostDocumentId)
if("missing"===t)try{const t=await ji({api:e,authority:n,consumer:r},s.registrationId,s.hostDocumentId)
o.push({registrationId:s.registrationId,state:t?"retired":"live"})}catch{o.push({registrationId:s.registrationId,state:"unknown"})}else o.push({registrationId:s.registrationId,state:t})}return o}let Wi
try{Wi=void function({development:i=null}={}){let s=0;(async function(e){if("function"!=typeof e?.sidePanel?.setPanelBehavior)throw new t("E_TARGET","Chrome Side Panel API 不可用")
try{await e.sidePanel.setPanelBehavior({openPanelOnActionClick:!0})}catch{throw new t("E_TARGET","无法配置 Chrome Side Panel 入口")}return{openPanelOnActionClick:!0}})(chrome).catch((e=>console.error(`[side-panel ${e.code||"E_TARGET"}] ${e.message}`)))
const c=function(r,{timeoutMs:i=8e3}={}){const o=new Map,s=new Map,c=new Map,d=(e,t)=>`${e}:${t}`
async function l(e,i,o){let s
try{s=await r.tabs.get(e)}catch{throw new t("E_TARGET","目标标签页已关闭")}if("optional"===o&&!(await r.permissions.contains({origins:[n(i)]})))throw new t("E_PERMISSION","读取目标标签页期间站点权限已撤销")
if(s.incognito||a(s.url).origin!==i||s.pendingUrl&&a(s.pendingUrl).origin!==i)throw new t("E_TARGET","目标已离开获准 origin")
return s}async function u(s){!function(e){if(!e||!Number.isInteger(e.tabId)||e.tabId<0||0!==e.frameId||"string"!=typeof e.documentId||!e.documentId||"string"!=typeof e.agentInstanceId||!e.agentInstanceId||a(e.origin).origin!==e.origin)throw new t("E_TARGET","缺少精确目标文档绑定")}(s)
const u=c.get(s.tabId)||0,p=o.get(d(s.tabId,s.documentId))
if(!p||!["optional","activeTab"].includes(p.authorizationMode)||p.agentInstanceId!==s.agentInstanceId||p.origin!==s.origin)throw new t("E_TARGET","目标登记已失效，请重新绑定健康探针")
if("optional"===p.authorizationMode&&!(await r.permissions.contains({origins:[n(s.origin)]})))throw new t("E_PERMISSION","站点权限已撤销")
await l(s.tabId,s.origin,p.authorizationMode)
const m=crypto.randomUUID(),f=await new Promise(((a,n)=>{const o=setTimeout((()=>n(new t("E_TARGET","健康消息超时"))),i)
r.tabs.sendMessage(s.tabId,{protocol:e,type:"HEALTH",requestId:m,agentInstanceId:s.agentInstanceId},{documentId:s.documentId,frameId:0}).then(a,(()=>n(new t("E_TARGET","目标文档已重载或无法接收消息")))).finally((()=>clearTimeout(o)))}))
if(f?.protocol!==e||f.requestId!==m||f.agentInstanceId!==s.agentInstanceId||f.origin!==s.origin)throw new t("E_TARGET","健康回包与精确目标不匹配")
if("optional"===p.authorizationMode&&!(await r.permissions.contains({origins:[n(s.origin)]})))throw new t("E_PERMISSION","等待健康回包期间站点权限已撤销")
if(await l(s.tabId,s.origin,p.authorizationMode),o.get(d(s.tabId,s.documentId))!==p||(c.get(s.tabId)||0)!==u)throw new t("E_TARGET","等待健康回包期间目标文档已失效")
return{target:s,readyState:f.readyState,scope:"environment-health-only",selectionImplemented:!1}}async function p(e,a,p="activeTab"){if(!["optional","activeTab"].includes(p))throw new t("E_PERMISSION","健康目标授权模式无效")
if("optional"===p&&!(await r.permissions.contains({origins:[n(a)]})))throw new t("E_PERMISSION","站点权限已撤销")
const m=c.get(e)||0
let f
await l(e,a,p)
try{f=await r.scripting.executeScript({target:{tabId:e,frameIds:[0]},files:["agents/health.js"],world:"ISOLATED"})}catch{throw new t("E_PERMISSION","无法注入：目标受限、已导航或站点权限不可用")}const g=f.find((e=>0===e.frameId))
if(1!==f.length||!g?.documentId)throw new t("E_TARGET","浏览器未返回精确文档")
const I=d(e,g.documentId)
if(o.has(I)||await new Promise(((e,a)=>{const n=s.get(I)||new Set,r={finish(t){clearTimeout(o),n.delete(r),n.size||s.delete(I),t?a(t):e()}},o=setTimeout((()=>r.finish(new t("E_TARGET","agent 握手超时"))),i)
n.add(r),s.set(I,n)})),(c.get(e)||0)!==m)throw new t("E_TARGET","注入握手期间目标文档已失效")
const w=o.get(I)
if(!w||w.origin!==a)throw new t("E_TARGET","未收到真实 sender 的 agent 握手")
return"optional"!==w.authorizationMode&&(w.authorizationMode=p),u(w)}return{rememberReady:function(e,n){if(n?.id!==r.runtime.id||!Number.isInteger(n.tab?.id)||n.tab.incognito||0!==n.frameId||!n.documentId||"active"!==n.documentLifecycle||"string"!=typeof e.agentInstanceId||e.agentInstanceId.length>80)throw new t("E_TARGET","健康探针来源不可信")
const i=a(n.url).origin,c=d(n.tab.id,n.documentId),l=o.get(c)
l&&l.agentInstanceId===e.agentInstanceId&&l.origin===i||o.set(c,{tabId:n.tab.id,frameId:0,documentId:n.documentId,agentInstanceId:e.agentInstanceId,origin:i}),o.size>32&&o.delete(o.keys().next().value)
for(const t of[...s.get(c)||[]])t.finish()
return{registered:!0}},bind:p,ping:u,createTarget:async function(e){const o=a(e)
if(!(await r.permissions.contains({origins:[n(o.href)]})))throw new t("E_PERMISSION","请先在用户点击中授予该站点权限")
const s=await r.tabs.create({url:o.href,active:!1})
try{return await(c=s.id,new Promise(((e,a)=>{let n=!1
const o=t=>{n||(n=!0,clearTimeout(l),r.tabs.onUpdated.removeListener(s),r.tabs.onRemoved.removeListener(d),t?a(t):e())},s=(e,t)=>{e===c&&"complete"===t.status&&o()},d=e=>{e===c&&o(new t("E_TARGET","目标在加载时已关闭"))},l=setTimeout((()=>o(new t("E_TARGET","目标加载超时"))),i)
r.tabs.onUpdated.addListener(s),r.tabs.onRemoved.addListener(d),r.tabs.get(c).then((e=>{"complete"===e.status&&o()}),(()=>d(c)))}))),await p(s.id,o.origin,"optional")}catch(d){throw await r.tabs.remove(s.id).catch((()=>{})),d}var c},forgetTab:function(e){c.set(e,(c.get(e)||0)+1)
for(const[t,a]of o)a.tabId===e&&o.delete(t)
for(const[a,n]of s)if(a.startsWith(e+":"))for(const e of[...n])e.finish(new t("E_TARGET","等待握手期间目标失效"))}}}(chrome),d=globalThis.__opendeskNativeHostPorts=new Map
i&&(globalThis.__opendeskDevelopment=i)
try{importScripts("native-agent/transport.js")}catch(m){console.warn("E_NATIVE_TRANSPORT_LOAD",m)}try{importScripts("knowledge/knowledge-host.js")}catch(m){console.warn("E_KNOWLEDGE_HOST_LOAD",m)}const l=async function({api:e=chrome,ports:t=new Map,clock:i={now:()=>Date.now()},indexedDB:s=globalThis.indexedDB,templateConsumer:c,downloadEventsAttached:d=!1}={}){if(void 0!==c)throw new C("E_MODULE_NOT_INSTALLED","Template consumer is not packaged in Background")
let{browserSessionIncarnation:l}=await e.storage.session.get("browserSessionIncarnation")
l||(l=D(),await e.storage.session.set({browserSessionIncarnation:l}))
const u=await async function({indexedDB:e=globalThis.indexedDB,name:t="opendesk-browser",version:a=2,readOnly:n=!1,clock:r={now:()=>Date.now()},admission:i,admitTemplate:o,sessionTyped:s}={}){P(e&&"function"==typeof e.open,"E_SCHEMA","IndexedDB unavailable"),P("string"==typeof t&&t.length>0&&[1,2].includes(a)&&"boolean"==typeof n,"E_VERSION","Invalid database identity"),P("function"==typeof r.now,"E_SCHEMA","clock.now required")
let c=Ae.get(e)
c||(c=new Map,Ae.set(e,c))
const d=c.get(t)
if(d)return P(d.version===a&&d.readOnly===n&&d.admission===i&&d.admitTemplate===o&&d.sessionTyped===s,"E_VERSION","Database already owned with different configuration"),d.promise
const l={version:a,readOnly:n,admission:i,admitTemplate:o,sessionTyped:s}
c.set(t,l),l.promise=(async()=>{const{db:d,readOnly:u,migrationError:p,migrationBackup:m}=await async function(e,t,a,{readOnly:n=!1}={}){let r,i
try{if(n)return{db:await Z(e,t,void 0,!1),readOnly:!0,migrationError:null,migrationBackup:null}
if(2===a){try{i=await Z(e,t,void 0,!1)}catch(o){if(0!==o.previousVersion)throw o}if(1===i?.version){try{r=await Y(i,{readOnly:!0})}catch(o){throw i.close(),o.previousVersion=1,o}i.close()}else i&&i.close()}const s=await Z(e,t,a,!0,r)
try{await async function(e){const t=1===e.version?V:K,a=e.transaction(Object.keys(t),"readonly"),n=new Promise(((e,t)=>{a.oncomplete=e,a.onabort=()=>t(a.error)}))
let r
try{for(const[e,n]of Object.entries(t)){const t=a.objectStore(e)
P(null===t.keyPath&&!t.autoIncrement,"E_VERSION","Storage requires explicit keys")
for(const[e,[a,r]]of Object.entries(n)){P(t.indexNames.contains(e),"E_VERSION","Storage index missing")
const n=t.index(e)
P(JSON.stringify(n.keyPath)===JSON.stringify(a)&&n.unique===r&&!n.multiEntry,"E_VERSION","Incompatible storage index")}}}catch(o){r=o}if(await n,r)throw r}(s)}catch(o){throw o.previousVersion=s.version,s.close(),o}return{db:s,readOnly:!1,migrationError:null,migrationBackup:r||null}}catch(o){if(!o.blocked&&(o.previousVersion>0||"VersionError"===o.name))return{db:await Z(e,t,void 0,!1),readOnly:!0,migrationError:{code:"E_VERSION",message:"Upgrade failed; previous database preserved read-only",cause:{name:o.name,code:o.code||null,message:o.message}},migrationBackup:r||null}
throw o instanceof C?o:new C("E_VERSION","Storage could not be opened")}}(e,t,a,{readOnly:n})
let f=!1
const g=()=>{f||(f=!0,d.close(),c.get(t)===l&&c.delete(t))}
d.onversionchange=g,d.onclose=g
const I={name:t,version:d.version,readOnly:u,migrationError:p,migrationBackup:m,close:g,transaction:(e,t,a)=>(P(!f,"E_VERSION","Storage connection closed"),P(Array.isArray(e)&&e.length>0&&new Set(e).size===e.length&&e.every((e=>d.objectStoreNames.contains(e))),"E_SCHEMA","Invalid transaction stores"),P("readonly"===t||"readwrite"===t,"E_SCHEMA","Invalid transaction mode"),P(!u||"readonly"===t,"E_VERSION","Recovery database is read-only; preserve backup before migration"),P("function"==typeof a,"E_SCHEMA","Transaction callback required"),Q(d,e,t,a)),rawBackup:async()=>(P(!f,"E_VERSION","Storage connection closed"),Y(d,{readOnly:u}))}
return Object.freeze(Object.assign(I,function(e,{clock:t={now:()=>Date.now()},admission:a,admitTemplate:n,sessionTyped:r}={}){const i="function"==typeof r?.executeSdk?r.executeSdk.bind(r):null,o=()=>{const e=t.now()
return P(Number.isSafeInteger(e)&&e>=0,"E_SCHEMA","Invalid storage clock"),e},s=e=>{P(e&&"function"==typeof e.authorize&&"function"==typeof e.authorizeInTransaction,"E_OWNER","Trusted storage authorization callbacks required")
for(const t of[...Se.filter((e=>"principal"!==e)),"opKey"])P("string"==typeof e[t]&&e[t].length>0,"E_OWNER",`Trusted context ${t} required`)
return P(void 0!==e.principal&&null!==e.principal,"E_OWNER","Trusted principal required"),ie(e.principal),P(Number.isSafeInteger(e.deadlineAt)&&e.deadlineAt>o(),"E_TIMEOUT","Storage operation deadline exceeded"),Object.freeze({...e,principal:he(e.principal)})},c=async(e,t)=>{P(e.deadlineAt>o(),"E_TIMEOUT","Storage operation deadline exceeded"),P(!1!==(t?await e.authorizeInTransaction(t):await e.authorize()),"E_OWNER","Storage authorization revoked")},d=e=>Object.fromEntries(Se.map((t=>[t,he(e[t])]))),l=(e,t)=>e&&Se.every((a=>JSON.stringify(ie(e[a]))===JSON.stringify(ie(t[a])))),u=async(e,t)=>{const a=await e.get(ge,t.opKey)
return P(a?.tag===("controller"===t.lifecycle?"controller-operation":"sdk-operation")&&l(a,t),"E_OWNER","SDK operation binding mismatch"),P(!["cancelled","revoked","effect_unknown","failed","interrupted"].includes(a.state),"E_OWNER","SDK operation fenced"),a},p=async(e,t,a,n,r)=>{P(!(await e.get("results",t.resultId)),"E_REQUEST_CONFLICT","Result ID already occupied")
const i={tag:"controller"===t.lifecycle?"controller-service-result":"sdk-result",...d(t),opKey:t.opKey,requestDigest:a.requestDigest,storageRequestDigest:n,state:"durable",outcomeWire:r,committedAt:o()}
return i.receiptAt=new Date(i.committedAt).toISOString(),r.ok&&(i.valueWire=r.value),await e.put("results",i,t.resultId),await e.put(ge,{...a,storageRequestDigest:n,state:"durable",valueWire:i.valueWire,durableAt:i.committedAt,receiptAt:i.receiptAt,resultId:t.resultId,receipt:{resultId:t.resultId,state:"durable"}},t.opKey),i},m=async(e,t,a,n)=>{P(a.storageRequestDigest===n,"E_REQUEST_CONFLICT","SDK request digest conflict")
const r=await e.get("results",t.resultId)
return P(r?.tag===("controller"===t.lifecycle?"controller-service-result":"sdk-result")&&l(r,t)&&r.opKey===t.opKey&&"durable"===r.state&&r.storageRequestDigest===n&&r.requestDigest===a.requestDigest,"E_OWNER","Durable result binding mismatch"),pe(r.outcomeWire),r},f=async(t,a,n)=>{const r=s(n),i=he(a),o=await j(JSON.stringify([t,ie(i)]))
await c(r)
const d=await e.transaction(ye,"readwrite",(async e=>{await c(r,e)
const a=await u(e,r)
if(P(a.method===t&&r.method===t,"E_REQUEST_CONFLICT","SDK admitted method mismatch"),void 0!==a.storageRequestDigest||"durable"===a.state){P("durable"===a.state,"E_OWNER","Storage operation is not replayable")
const t=await m(e,r,a,o)
return await c(r,e),t}P(["admitted","pending","prepared","dispatched"].includes(a.state),"E_OWNER","Storage operation not admitted")
const n=t.startsWith("APPSTORAGE_")?"app-storage":"chrome-local",s=t=>e.get("frameworkKV",be(r.namespace,n,t)),d=(t,a)=>e.put("frameworkKV",{tag:"framework-kv",namespace:r.namespace,area:n,key:t,valueWire:ie(a)},be(r.namespace,n,t)),l=e=>P("string"==typeof e&&e.length>0,"E_SCHEMA","Storage key required")
let f
if("APPSTORAGE_GETITEM"===t){l(i.key)
const e=await s(i.key)
f=e?oe(e.valueWire)+"":null}else if("APPSTORAGE_SETITEM"===t)l(i.key),await d(i.key,i.value+"")
else if("APPSTORAGE_REMOVEITEM"===t)l(i.key),await e.delete("frameworkKV",be(r.namespace,n,i.key))
else if("APPSTORAGE_CLEAR"===t||"CHROME_LOCAL_CLEAR"===t)for(const t of await e.all("frameworkKV"))"framework-kv"===t.tag&&t.namespace===r.namespace&&t.area===n&&await e.delete("frameworkKV",be(r.namespace,n,t.key))
else if("CHROME_LOCAL_GET"===t)if(null===i.key)f=(await e.all("frameworkKV")).filter((e=>"framework-kv"===e.tag&&e.namespace===r.namespace&&e.area===n)).map((e=>oe(e.valueWire)))
else{l(i.key)
const e=await s(i.key)
f=e?oe(e.valueWire):void 0}else if("CHROME_LOCAL_SET"===t){P(i.values&&!Array.isArray(i.values)&&"object"==typeof i.values,"E_SCHEMA","Storage values object required")
for(const[e,t]of Object.entries(i.values))l(e),await d(e,t)}else if("CHROME_LOCAL_REMOVE"===t){const t=Array.isArray(i.keys)?i.keys:[i.keys]
for(const a of t)l(a),await e.delete("frameworkKV",be(r.namespace,n,a))}else{if("DEVICE_GET_APP_ID"!==t)throw new C("E_CAPABILITY","Unsupported persistent storage method")
{const t=be(r.namespace,"device","deviceID"),a=await e.get("frameworkKV",t)
a?f=oe(a.valueWire):(f=D(),await e.put("frameworkKV",{tag:"device-id",namespace:r.namespace,area:"device",key:"deviceID",valueWire:ie(f)},t)),P("string"==typeof f&&f.length>0,"E_SCHEMA","Invalid persistent device ID")}}const g=ue({ok:!0,value:f})
await c(r,e)
const I=await u(e,r)
return P(I.state===a.state&&I.storageRequestDigest===a.storageRequestDigest,"E_OWNER","SDK operation CAS changed"),p(e,r,I,o,g)}))
await c(r)
const l=pe(d.outcomeWire)
return P(l.ok,"E_SCHEMA","Storage result is not successful"),l.value},g=async(t,a)=>{const n=s(t)
await c(n)
const r=await e.transaction(["scriptHeads","scriptRevisions",ge],"readwrite",(async e=>{await c(n,e)
const t=await a(e,n)
return await c(n,e),t}))
return await c(n),r}
return{async executeSdk(e,t,a){if(P("string"==typeof e,"E_CAPABILITY","Storage method required"),P(t&&"object"==typeof t&&!Array.isArray(t),"E_SCHEMA","Storage arguments required"),e.startsWith("APPLOCAL_")){const n=s(a)
P(i,"E_RESOURCE_UNAVAILABLE","Broker native storage.session adapter required"),await c(n)
const r=await i(e,he(t),a)
return await c(n),r}return f(e,t,a)},getAppId:e=>f("DEVICE_GET_APP_ID",{},e),async commitResult(t,{requestDigest:a,outcome:n}){const r=s(t),i=ue(n)
P("string"==typeof a&&/^[a-f0-9]{64}$/.test(a),"E_HASH","Result request digest required"),await c(r)
const o=await e.transaction(ye,"readwrite",(async e=>{await c(r,e)
const t=await u(e,r)
if("durable"===t.state){const n=await m(e,r,t,a)
return P(JSON.stringify(n.outcomeWire)===JSON.stringify(i),"E_REQUEST_CONFLICT","Result outcome is immutable"),await c(r,e),n}return P(["admitted","pending","prepared","dispatched"].includes(t.state),"E_OWNER","Result operation not admitted"),await c(r,e),p(e,r,t,a,i)}))
return await c(r),pe(o.outcomeWire)},async getResult(t){const a=s(t)
await c(a)
const n=await e.transaction(ye,"readonly",(async e=>{await c(a,e)
const t=await u(e,a)
P("durable"===t.state,"E_OWNER","Result is not durable")
const n=await m(e,a,t,t.storageRequestDigest)
return await c(a,e),n}))
return await c(a),pe(n.outcomeWire)},async commitScriptRevision(e,t){const a=he(t)
Ee(a.scriptId),P("string"==typeof a.sourceUtf8&&we.encode(a.sourceUtf8).byteLength<=N.maxRawFrameBytes,"E_SCHEMA","Script source UTF8 exceeds limit"),ie(a.sourceUtf8),P(Number.isSafeInteger(a.expectedRevision)&&a.expectedRevision>=0,"E_REVISION","Expected revision required")
const n=await j(a.sourceUtf8)
return void 0!==a.contentHash&&P(a.contentHash===n,"E_HASH","Script bytes hash mismatch"),g(e,(async(e,t)=>{const r=ve(t.namespace,a.scriptId),i=await e.get("scriptHeads",r)
P(!i?.tombstoned,"E_TOMBSTONE","Script deleted"),P((i?.revision||0)===a.expectedRevision,"E_REVISION","Script head CAS conflict")
const o={tag:"script-revision",namespace:t.namespace,scriptId:a.scriptId,revision:a.expectedRevision+1,parentRevision:a.expectedRevision,contentHash:n,sourceUtf8:a.sourceUtf8,...a.builtinIdentity?{builtinIdentity:he(a.builtinIdentity)}:{}}
return P(!(await e.get("scriptRevisions",ve(t.namespace,o.scriptId,o.revision))),"E_REVISION","Immutable revision exists"),await e.put("scriptRevisions",o,ve(t.namespace,o.scriptId,o.revision)),await e.put("scriptHeads",{tag:"script-head",namespace:t.namespace,scriptId:o.scriptId,revision:o.revision,contentHash:n,tombstoned:!1},r),o}))},pinScriptRevision(e,t,a){const n=he(t)
Ee(n.scriptId),P(Number.isSafeInteger(n.revision)&&n.revision>0,"E_REVISION","Exact revision required")
const r=async(e,t)=>{const a=await e.get("scriptHeads",ve(t.namespace,n.scriptId))
P(a&&!a.tombstoned,"E_TOMBSTONE","Script unavailable")
const r=await e.get("scriptRevisions",ve(t.namespace,n.scriptId,n.revision))
P(r&&r.contentHash===n.contentHash&&await j(r.sourceUtf8)===r.contentHash,"E_HASH","Pinned revision hash mismatch")
const i=_e(t,n.scriptId,n.revision),o=await e.get(ge,i)
P(!o?.released,"E_OWNER","Released pin cannot be revived"),P(!o||l(o,t),"E_OWNER","Revision pin binding mismatch")
const s=o||{tag:"script-revision-pin",...d(t),opKey:t.opKey,scriptId:n.scriptId,revision:n.revision,contentHash:r.contentHash,released:!1}
return await e.put(ge,s,i),{pinKey:i,revision:r}}
if(a){const t=s(e)
return(async()=>{await c(t,a)
const e=await r(a,t)
return await c(t,a),e})()}return g(e,r)},releaseScriptRevisionPin(e,t){const a=he(t)
return Ee(a.scriptId),g(e,(async(e,t)=>{const n=_e(t,a.scriptId,a.revision),r=await e.get(ge,n)
return P(r&&r.opKey===t.opKey,"E_OWNER","Revision pin unavailable"),await e.put(ge,{...r,released:!0},n),{released:!0}}))},tombstoneScript:(e,{scriptId:t,expectedRevision:a})=>(Ee(t),g(e,(async(e,n)=>{const r=ve(n.namespace,t),i=await e.get("scriptHeads",r)
return P(i?.revision===a,"E_REVISION","Script tombstone CAS conflict"),await e.put("scriptHeads",{...i,tombstoned:!0},r),{tombstoned:!0}}))),garbageCollectScript:(e,{scriptId:t})=>(Ee(t),g(e,(async(e,a)=>{const n=await e.get("scriptHeads",ve(a.namespace,t))
P(n?.tombstoned,"E_TOMBSTONE","GC requires tombstone")
for(const i of await e.all(ge))if("script-revision-pin"===i.tag&&i.namespace===a.namespace&&i.scriptId===t){const t=await e.get(ge,i.opKey),a="controller-lease"===t?.tag&&l(t,i)&&["completed","failed","stopped","interrupted"].includes(t.state)&&!0===t.workerRetired&&"released"===t.retirementState,n="sdk-operation"===t?.tag&&l(t,i)&&!["admitted","pending","prepared","dispatched","effect_unknown"].includes(t.state)&&("durable"!==t.state||"delivered"===t.deliveryState)&&"pending"!==t.deliveryState
P(i.released&&(a||n),"E_OWNER","Pinned or unresolved operation blocks GC")}let r=0
for(const i of await e.all("scriptRevisions"))i.namespace===a.namespace&&i.scriptId===t&&(await e.delete("scriptRevisions",ve(a.namespace,t,i.revision)),r++)
return{removed:r}})))}}(I,{clock:r,admission:i,admitTemplate:o,sessionTyped:s})))})()
try{return await l.promise}catch(u){throw c.get(t)===l&&c.delete(t),u}}({clock:i,indexedDB:s,sessionTyped:Ge({api:e})})
P(void 0===c||"function"==typeof c?.attach&&"function"==typeof c.createEntitlement&&"function"==typeof c.validatePlan,"E_SCHEMA","An explicit trusted consumer descriptor is required")
const p=()=>{throw new C("E_MODULE_NOT_INSTALLED","The template consumer has not been registered")},f=c?.createEntitlement({storage:u,clock:i}),g=async(e,a)=>{const n=await u.transaction(["commandJournal"],"readonly",(t=>t.get("commandJournal","host:"+e)))
if(!n?.active||n.browserSessionIncarnation!==l)return
const r=t.get(n.hostDocumentId)
if(r&&r.registrationId===e)try{r.postMessage({protocol:R,registrationId:e,event:a})}catch{}},I=function({storage:e,api:t,session:i,entitlement:o,validatePlan:s,clock:c={now:()=>Date.now()},loadBuiltin:d=ka,emitToHost:l=async()=>{}}){function u(e){P(r(t,e),"E_OWNER","Only an actual packaged tool document may own a run")}const p=()=>({namespace:"tool:"+t.runtime.id,principal:"extension-tool:"+t.runtime.id})
async function m(t,a){return u(t),e.transaction([Rn],"readonly",(async e=>{const n=(a?[await e.get(Rn,"host:"+a)]:await e.all(Rn)).find((e=>"host"===e?.tag&&e.hostDocumentId===t.documentId&&e.active&&e.browserSessionIncarnation===i))
return P(n&&n.hostUrl===t.url,"E_OWNER","Host registration has expired or belongs to another document"),{...n,...p()}}))}async function f(e,t,a){const n=await e.get(Rn,"host:"+t.registrationId)
return P(n?.active&&!n.revoked&&n.hostDocumentId===a.documentId&&n.hostUrl===a.url&&n.hostInstanceId===t.hostInstanceId&&n.browserSessionIncarnation===i,"E_OWNER","Host changed before transaction commit"),n}async function g(t,a){const n=await m(a)
return e.transaction(["runs",Rn,"exportJobs"],"readonly",(async e=>{const t=await e.get("runs","@slot"),a=(await e.all("exportJobs")).filter((e=>e.registrationId===n.registrationId&&!0))
return F(k,"Projection",{run:null,pendingCommandIds:[].map((e=>e.commandId)),exportJobIds:a.map((e=>e.exportJobId)),eventSeq:0,slotAvailable:!t?.currentRunId&&!t?.preview})}))}async function I(t,a){const n=X(t)
return e.transaction(["runs",Rn,Nn],"readwrite",(async e=>{const t=await e.get(Rn,n)
if(!t||"dispatched"!==t.state)return
t.state="effect_unknown",t.failure={code:a?.code||"E_EFFECT_UNKNOWN",message:(a?.message||a)+""},await e.put(Rn,t,n)
const r=await e.get("runs",t.identity.runId)
!r||r.tombstoned||z.has(r.state)||"retiring"===r.state||r.cancelSeq||(r.state="paused_unknown",r.runRevision++,r.eventSeq++,r.identity.runRevision=r.runRevision,await e.put("runs",r,r.runId))}))}async function w(e,t,a){if(t.retirementId)return{state:t.state,retirementId:t.retirementId}
const n=await e.get("runs","@slot")
P(n?.currentRunId===t.runId,"E_OWNER","Run does not own the slot"),t.ownerEpoch++,t.runRevision++,t.eventSeq++,t.cancelSeq++,t.retirementId=D(),t.fencedEpoch=t.ownerEpoch,t.finalState=a,t.retirementState="fenced",z.has(t.state)||(t.state="retiring"),n.fencedEpoch=t.fencedEpoch,n.retirementId=t.retirementId
for(const r of await e.all(Rn))"command"===r.tag&&r.identity?.runId===t.runId&&"prepared"===r.state&&(r.state="cancelled",await e.put(Rn,r,X(r)))
for(const r of await e.all(Nn))r.runId===t.runId&&"open"===r.state&&(r.state="aborted",await e.put(Nn,r,r.snapshotId))
return await e.put("runs",t,t.runId),await e.put("runs",n,"@slot"),await e.put(Rn,{tag:"retirement",retirementId:t.retirementId,runId:t.runId,fencedEpoch:t.fencedEpoch,registrationId:t.registrationId,target:t.target,creationId:t.creationId??null,browserSessionIncarnation:t.browserSessionIncarnation,state:"fenced",releaseCount:0,finalState:a},"retirement:"+t.retirementId),{state:t.state,retirementId:t.retirementId}}const h=function({storage:e,api:t,session:r,clock:i,assertHost:o,currentHost:s}){const c=new WeakMap,d=()=>W(i),l=new Map,u=new Map,p=new Map,m=new Map,f=new Map,g=[],I=new Set,w=new Map,h=D()
let E=0,y=0,b=!1
const v=e=>H([e.tabId,e.frameId])
function _(e){return p.has(e)||p.set(e,0),p.get(e)+(e=>g.filter((t=>t.some((t=>ee(t,e))))).length)(e)}function S(e){return l.has(e.tabId)||l.set(e.tabId,0),u.has(v(e))||u.set(v(e),0),b=!0,{tabEpoch:l.get(e.tabId)+(m.get(e.tabId)||0),frameEpoch:u.get(v(e))+(f.get(v(e))||0),permissionEpoch:_(e.origin),notificationEpoch:E+y}}const A=(e,t)=>({...S(e),originPermissionEpochs:t.map((e=>[e,_(e)]))})
function O(e,t=!0){const a=S(e.doc)
P(a.tabEpoch===e.tabEpoch&&a.frameEpoch===e.frameEpoch,"E_DOCUMENT_STALE","Observed document invalidation fences this SDK operation"),P(!I.has(e.grantIncarnation)&&a.permissionEpoch===e.permissionEpoch&&(e.originPermissionEpochs||[]).every((([e,t])=>_(e)===t))&&(!("notifications"===e.capability||e.capabilities?.includes("notifications"))||a.notificationEpoch===e.notificationEpoch),Rt,"Observed scope or permission removal fences this SDK operation"),t&&P(i.now()<e.deadlineAt,"E_DEADLINE","SDK short service expired")}function k(e){return void 0===e?.targetScopeVersion?!0===e?.active:1===e.targetScopeVersion&&!1===e.active&&!0===e.crossOriginActive}function T(e,t){if(P("sdk-grant"===e?.tag&&k(e),Rt,"SDK grant is inactive or has an unknown format"),void 0===e.targetScopeVersion)return P(!(Object.hasOwn(e,"targetScopeVersion")||Object.hasOwn(e,"targetOrigins")||Object.hasOwn(e,"originPermissionEpochs")||Object.hasOwn(e,"crossOriginActive")),Rt,"Malformed legacy SDK grant"),P(H(e.allowedOrigins??[t.origin])===H([t.origin]),Rt,"Legacy grants only authorize their source origin"),{...e,allowedOrigins:[t.origin]}
P(e.workerIncarnation===h,Rt,"Cross-origin SDK authorization requires explicit approval after worker restart")
const a=St(t.origin,e.targetOrigins)
return P(a.targetOrigins.length>0&&e.capabilities?.includes("network")&&H(a.allowedOrigins)===H(e.allowedOrigins)&&Array.isArray(e.originPermissionEpochs)&&e.originPermissionEpochs.length===a.allowedOrigins.length&&e.originPermissionEpochs.every(((e,t)=>Array.isArray(e)&&2===e.length&&e[0]===a.allowedOrigins[t]&&Number.isSafeInteger(e[1])&&e[1]>=0)),Rt,"Malformed cross-origin SDK scope"),e}function R(e,t=Rt){if(!e)return
I.add(e)
const a=w.get(e)
if(a){const n=Error("The original SDK document or grant was invalidated")
n.code=t,a.controller.abort(n),w.delete(e)}}const N=(e,t)=>({...e,doc:t})
function C(e,t){return{grantIncarnation:e.grantIncarnation,documentId:t.documentId,sourceOrigin:t.origin,capabilities:e.capabilities,targetOrigins:e.allowedOrigins.filter((e=>e!==t.origin)),allowedOrigins:e.allowedOrigins,requiresReapprovalAfterWorkerRestart:1===e.targetScopeVersion}}function x(e){return"network"===We[e.method]?.capability?a(e.args.url??e.args.server).origin:void 0}const L=e=>"sdk-grant:"+H([e.tabId,e.frameId,e.documentId])
function M(e){P(e?.id===t.runtime.id&&Number.isSafeInteger(e.tab?.id)&&e.tab.id>=0&&!1===e.tab.incognito&&Number.isSafeInteger(e.frameId)&&e.frameId>=0&&"string"==typeof e.documentId&&e.documentId.length>0&&"active"===e.documentLifecycle,"E_OWNER","SDK needs the actual active Chrome document sender")
const n=a(e.url).origin
return{tabId:e.tab.id,frameId:e.frameId,documentId:e.documentId,origin:n,principal:"sdk:"+n}}async function q(e){const r=await t.webNavigation.getAllFrames({tabId:e.tabId})
P(r?.some((t=>t.frameId===e.frameId&&t.documentId===e.documentId&&"active"===t.documentLifecycle&&!t.errorOccurred&&a(t.url).origin===e.origin)),"E_DOCUMENT_STALE","SDK document is no longer current"),P(await t.permissions.contains({origins:[n(e.origin)]}),kt,"SDK site permission was revoked")}async function F(e,t,a){const n=T(await e.get(Ot,L(t)),t)
return P(n.browserSessionIncarnation===r&&n.principal===t.principal&&(void 0===a||n.grantIncarnation===a),Rt,"SDK grant is absent or fenced"),O(N(n,t),!1),n}function z(e,t=!1){const a=["tabId","frameId","documentId",...t?["grantIncarnation"]:[]]
return Ce(e,a,a),P(Number.isSafeInteger(e.tabId)&&e.tabId>=0&&Number.isSafeInteger(e.frameId)&&e.frameId>=0&&"string"==typeof e.documentId&&e.documentId.length>0&&e.documentId.length<=256,"E_SCHEMA","Invalid exact SDK document"),t&&P("string"==typeof e.grantIncarnation&&e.grantIncarnation.length>0&&e.grantIncarnation.length<=256,"E_SCHEMA","Revocation requires a specific grant incarnation"),{tabId:e.tabId,frameId:e.frameId,documentId:e.documentId}}async function V(e){const n=await t.webNavigation.getAllFrames({tabId:e.tabId}),r=n?.find((t=>t.frameId===e.frameId&&t.documentId===e.documentId))
P("active"===r?.documentLifecycle&&!r.errorOccurred,"E_DOCUMENT_STALE","The selected SDK document is no longer active")
const i=a(r.url).origin
return{...e,origin:i,principal:"sdk:"+i}}async function K(i,c,l=!1){const u=l?null:await o(c)
Ce(i,["tabId","frameId","documentId","capabilities","targetOrigins"],["tabId","frameId","documentId","capabilities"]),P(i&&Number.isSafeInteger(i.tabId)&&Number.isSafeInteger(i.frameId)&&"string"==typeof i.documentId&&Array.isArray(i.capabilities),"E_SCHEMA","Invalid SDK grant")
const p=await t.webNavigation.getAllFrames({tabId:i.tabId}),m=p?.find((e=>e.frameId===i.frameId&&e.documentId===i.documentId))
P("active"===m?.documentLifecycle&&!m.errorOccurred,"E_DOCUMENT_STALE","Selected SDK document is no longer active")
const f=a(m.url).origin,g={tabId:i.tabId,frameId:i.frameId,documentId:i.documentId,origin:f,principal:"sdk:"+f}
if(l){const e=M(c),t=At(c.url,c.frameId)
P(e.tabId===g.tabId&&e.frameId===g.frameId&&e.documentId===g.documentId&&e.origin===g.origin&&null!==t&&H(i.capabilities)===H(["network"])&&H(i.targetOrigins)===H(t),kt,"Untrusted automatic SDK scope")}const I=St(f,i.targetOrigins),w=A(g,I.allowedOrigins)
await q(g)
for(const e of I.targetOrigins)P(await t.permissions.contains({origins:[n(e)]}),kt,"Target permission was not approved")
const E=new Set(Object.values(We).map((e=>e.capability)))
P(i.capabilities.length>0&&i.capabilities.every((e=>E.has(e))),"E_CAPABILITY","Unknown SDK grant capability")
const y=[...new Set(i.capabilities)].sort(),b=L(g)
return P(!I.targetOrigins.length||y.includes("network"),"E_CAPABILITY","Additional targets require the network capability"),e.transaction([Ot],"readwrite",(async e=>{l||await s(e,u,c),O({...w,doc:g,capabilities:y},!1)
const t=await e.get(Ot,b)
if(l&&t&&"worker-restart-reapproval-required"!==t.closeReason)return C(await F(e,g),g)
let a
try{a=T(t,g),O(N(a,g),!1)}catch{a=void 0}if(a&&a.browserSessionIncarnation===r&&a.principal===g.principal&&H(a.capabilities)===H(y)&&H(a.allowedOrigins)===H(I.allowedOrigins))return C(a,g)
t&&(R(t.grantIncarnation),await e.put(Ot,{...t,active:!1,crossOriginActive:!1,closedAt:d()},"sdk-closed-grant:"+t.grantIncarnation))
const n={tag:"sdk-grant",...g,...S(g),key:b,namespace:"page:"+f,capabilities:y,allowedOrigins:[...I.allowedOrigins],grantIncarnation:D(),browserSessionIncarnation:r,active:!0,grantedAt:d(),...l?{automatic:!0}:{registrationId:u.registrationId}}
return I.targetOrigins.length&&Object.assign(n,{targetScopeVersion:1,active:!1,crossOriginActive:!0,targetOrigins:[...I.targetOrigins],originPermissionEpochs:w.originPermissionEpochs,workerIncarnation:h}),O({...w,doc:g,capabilities:y},!1),await e.put(Ot,n,b),O({...w,doc:g,capabilities:y},!1),C(n,g)}))}async function B(e){const t=At(e.url,e.frameId)
if(null===t)return
const a=M(e)
await K({tabId:a.tabId,frameId:a.frameId,documentId:a.documentId,capabilities:["network"],targetOrigins:t},e,!0)}async function G(t,a){P(t&&1===Object.keys(t).length&&t.sdkVersion===Oe,"E_VERSION","SDK version differs")
const n=M(a),r={...S(n),doc:n}
await B(a),await q(n)
const i=await e.transaction([Ot],"readonly",(async e=>{const t=await F(e,n)
return O(r,!1),O(N(t,n),!1),t}))
return O(r,!1),O(N(i,n),!1),{doc:n,grant:i}}async function J(e,t){const a=c.get(t)
P(a,"E_OWNER","SDK context was not issued by the shared authority"),O(a)
const n=await F(e,a.doc,a.grantIncarnation)
P(n.namespace===a.namespace&&n.capabilities.includes(a.capability),kt,"SDK capability is not granted")
const r=await e.get(Ot,a.opKey)
return P(r?.opId===a.opId&&r.requestDigest===a.requestDigest&&r.grantIncarnation===a.grantIncarnation,"E_REQUEST_CONFLICT","SDK admission changed"),P(r.state!==Nt&&!r.cancelSeq,Tt,"Unknown SDK effect cannot be replayed"),P(i.now()<a.deadlineAt,"E_DEADLINE","SDK short service expired"),O(a),{grant:n,operation:r}}async function $(r,i={}){const o=c.get(r)
P(o,"E_OWNER","SDK context was not issued by the shared authority"),await q(o.doc)
let s=o.targetOrigin
return void 0!==i.url&&(s=a(i.url).origin,P(s===o.targetOrigin,kt,"Driver target differs from the admitted request")),s&&P(await t.permissions.contains({origins:[n(s)]}),kt,"SDK request origin is not permitted"),"notifications"===i.capability&&P(await t.permissions.contains({permissions:["notifications"]}),kt,"Notifications permission is absent"),e.transaction([Ot],"pre"===i.phase?"readwrite":"readonly",(async e=>{const t=await J(e,r)
return i.capability&&P(t.grant.capabilities.includes(i.capability),kt,"SDK request capability is not granted"),s&&P(t.grant.allowedOrigins.includes(s),kt,"SDK cross-origin capability is absent"),"pre"===i.phase&&["network","notifications","storage.session","service.log","service.time","resources.packaged"].includes(i.capability)&&(P("admitted"===t.operation.state,Tt,"SDK external effect already dispatched"),t.operation.state="dispatched",t.operation.submissionCount=1,t.operation.dispatchAt=d(),await e.put(Ot,t.operation,o.opKey)),O(o),t}))}async function Y(t,a){const n=c.get(t)
P(n,"E_OWNER","Effect receipt requires the original trusted driver context")
const r=ie(a)
return e.transaction([Ot,"results","runs"],"readwrite",(async e=>{const t=await e.get(Ot,n.opKey)
return Z(e,n,t,r)}))}async function Z(e,t,a,n,r){P(a?.opId===t.opId&&a.requestDigest===t.requestDigest&&(["admitted","dispatched","durable"].includes(a.state)||a.state===Nt&&1===a.submissionCount),Tt,"Effect receipt differs from admission")
const i=await e.get("results",t.resultId)
if(i){P("sdk-result"===i.tag&&"durable"===i.state&&i.resultId===t.resultId&&i.runId===t.runId&&i.opId===t.opId&&i.namespace===t.namespace&&i.grantIncarnation===t.grantIncarnation&&i.requestDigest===t.requestDigest,Tt,"Existing SDK result differs from admission")
const a=await e.get("runs",t.runId)
return a&&"completed"!==a.state&&await e.put("runs",{...a,state:"completed",resultId:i.resultId,completedAt:d()},a.runId),i}const o={tag:"sdk-result",state:"durable",resultId:t.resultId,opId:t.opId,runId:t.runId,namespace:t.namespace,principal:t.principal,requestId:t.requestId,opKey:t.opKey,requestDigest:t.requestDigest,browserSessionIncarnation:t.browserSessionIncarnation,valueWire:n,...r?{httpErrorWire:r}:{},receiptAt:d(),grantIncarnation:t.grantIncarnation}
a.state="durable",a.resultId=o.resultId,a.receiptAt=o.receiptAt,await e.put("results",o,o.resultId),await e.put(Ot,a,t.opKey)
const s=await e.get("runs",t.runId)
return s&&await e.put("runs",{...s,state:"completed",resultId:o.resultId,completedAt:d()},s.runId),o}async function Q(t,a){const n=c.get(t)
P(n,"E_OWNER","Native receipt requires the original driver context")
const r=ie(a),i=n.method.startsWith("AXIOS_")&&a?.status>=300&&a.status<=599&&Object.hasOwn(a,"data")
return e.transaction(i?[Ot,"results","runs"]:[Ot],"readwrite",(async e=>{const t=await e.get(Ot,n.opKey)
if(P(t?.opId===n.opId&&t.requestDigest===n.requestDigest&&(["dispatched","durable"].includes(t.state)||t.state===Nt&&1===t.submissionCount),Tt,"Native receipt has no matching dispatch"),t.nativeReceiptWire=r,t.nativeReceiptAt=d(),await e.put(Ot,t,n.opKey),i)return Z(e,n,t,ie(void 0),r)})).then((e=>n.httpErrorReceipt=e))}async function X({tabId:t,frameId:a,documentId:n,grantIncarnation:r,origins:i,permissions:o,reason:s="revoked"}={}){if(void 0!==r)P("string"==typeof r&&r.length>0&&Number.isSafeInteger(t)&&Number.isSafeInteger(a)&&"string"==typeof n&&n.length>0&&void 0===i&&void 0===o,"E_SCHEMA","Installation cleanup requires one exact document and grant incarnation"),R(r)
else{if(void 0!==t&&void 0!==a){const e=H([t,a])
f.set(e,(f.get(e)||0)+1)}else void 0!==t&&m.set(t,(m.get(t)||0)+1)
o?.includes("notifications")&&y++,i?.length&&g.push([...i])}const c=e=>!(void 0!==r&&e.grantIncarnation!==r||void 0!==t&&e.tabId!==t||void 0!==a&&e.frameId!==a||void 0!==n&&e.documentId!==n||(i||o)&&!i?.some((t=>(e.allowedOrigins||[e.origin]).some((e=>ee(t,e)))))&&!o?.some((t=>e.capabilities.includes(t))))
for(const[e,d]of w)c(d.grant)&&R(e,void 0!==r||void 0===t?Rt:"E_DOCUMENT_STALE")
return e.transaction([Ot],"readwrite",(async e=>{for(const a of await e.all(Ot))if("sdk-grant"===a.tag&&k(a)&&c(a)){if(void 0!==t||i||o)try{O(N(a,a),!1)
continue}catch{}R(a.grantIncarnation),a.active=!1,void 0!==a.targetScopeVersion&&(a.crossOriginActive=!1),a.closedAt=d(),a.closeReason=s,await e.put(Ot,a,a.key)}}))}function ee(e,t){if("<all_urls>"===e)return!0
const a=/^(\*|https?|file):\/\/([^/]+)\//.exec(e)
if(!a)return!1
const n=new URL(t),r=a[2]
return("*"===a[1]||a[1]+":"===n.protocol)&&("*"===r||r===n.hostname||r.startsWith("*.")&&(n.hostname===r.slice(2)||n.hostname.endsWith("."+r.slice(2))))}return{grantSdk:K,inspectSdkGrant:async function(a,r){const i=await o(r),c=await V(z(a))
await q(c)
const d=await e.transaction([Ot],"readonly",(async e=>{await s(e,i,r)
const t=await e.get(Ot,L(c))
return t&&k(t)?{present:!0,...C(await F(e,c),c)}:{present:!1,documentId:c.documentId,sourceOrigin:c.origin}}))
if(d.present)for(const e of d.targetOrigins)P(await t.permissions.contains({origins:[n(e)]}),kt,"SDK target permission has been removed")
return d},revokeSdkGrant:async function(t,a){const n=await o(a),r=z(t,!0),i=await V(r)
return await e.transaction([Ot],"readonly",(async e=>{await s(e,n,a),await F(e,i,t.grantIncarnation)})),await X({...r,grantIncarnation:t.grantIncarnation,reason:"user-revoked"}),e.transaction([Ot],"readonly",(async e=>{await s(e,n,a)
const o=await e.get(Ot,L(i))
return P(!o||o.grantIncarnation!==t.grantIncarnation||!k(o),Tt,"SDK revocation was not persisted"),{revoked:!0,...r,grantIncarnation:t.grantIncarnation}}))},helloSdk:async function(e,t){const{grant:a}=await G(e,t)
return{sdkVersion:Oe,ready:!0,methods:Object.entries(We).filter((([,e])=>a.capabilities.includes(e.capability))).map((([e])=>e))}},lookupSdkInvocation:async function(a,i){const{doc:o,grant:s}=await G({sdkVersion:Oe},i),c=N(s,o),d=[o.principal,o.tabId,o.frameId,o.documentId],l=Ve({requestId:a.requestId,method:a.method,args:oe(a.argsWire),deadlineAt:a.deadlineAt}),u=await j(H([l.method,me(l.args),l.deadlineAt])),p=x(l)
p&&(P(s.allowedOrigins.includes(p),kt,"SDK target was not approved"),p!==o.origin&&P(await t.permissions.contains({origins:[n(p)]}),kt,"SDK target permission was revoked")),O(c,!1)
const m=await e.transaction([Ot],"readonly",(async e=>{const t=await F(e,o,s.grantIncarnation),n=await e.get(Ot,"sdk-request:"+H([...d,a.requestId]))
if("sdk-request"!==n?.tag||n.grantIncarnation!==t.grantIncarnation)return
const i=await e.get(Ot,n.opKey)
return O(c,!1),"sdk-operation"===i?.tag&&i.opKey===n.opKey&&i.browserSessionIncarnation===r&&i.grantIncarnation===t.grantIncarnation&&H([i.principal,i.tabId,i.frameId,i.documentId])===H(d)&&i.requestId===a.requestId&&i.requestDigest===u&&["dispatched",Nt].includes(i.state)?i:void 0}))
return O(c,!1),m?{invocation:U({invocation:m}).invocation}:void 0},authorizeSdkInjection:async function(n,r,i){const c=await o(r),d={tabId:n.tabId,frameId:n.frameId,documentId:n.documentId},l=await t.webNavigation.getAllFrames({tabId:d.tabId}),u=l?.find((e=>e.frameId===d.frameId&&e.documentId===d.documentId))
return P(u,"E_DOCUMENT_STALE","SDK installation document changed"),d.origin=a(u.url).origin,d.principal="sdk:"+d.origin,await q(d),e.transaction([Ot],"readonly",(async e=>(await s(e,c,r),F(e,d,i))))},admitSdk:async function(t,a){const n=M(a),o=x(t)
await B(a)
const s={...A(n,o?[...new Set([n.origin,o])].sort():[n.origin]),doc:n,capability:We[t.method]?.capability}
await q(n)
const l=Object.hasOwn(We,t.method)&&We[t.method]
P(l,"E_SERVICE_UNSUPPORTED","Unknown SDK method"),P(Number.isSafeInteger(t.deadlineAt)&&t.deadlineAt>i.now(),"E_DEADLINE","SDK request expired")
const u=await j(H([t.method,me(t.args),t.deadlineAt])),p=await e.transaction([Ot,"runs","results"],"readwrite",(async e=>{const a=await F(e,n)
O(s,!1),o&&P(a.allowedOrigins.includes(o),kt,"SDK target was not approved"),P(a.capabilities.includes(l.capability),kt,"SDK method capability is not granted")
const c="sdk-request:"+H([n.principal,n.tabId,n.frameId,n.documentId,t.requestId]),p=await e.get(Ot,c)
P(!p||p.grantIncarnation===a.grantIncarnation,Rt,"Old request belongs to a closed grant")
const m="sdk-operation:"+H([n.principal,n.tabId,n.frameId,n.documentId,a.grantIncarnation,t.requestId])
let f=await e.get(Ot,m)
f?P(f.requestDigest===u,"E_REQUEST_CONFLICT","SDK request ID has conflicting arguments"):(f={tag:"sdk-operation",opKey:m,...n,namespace:a.namespace,grantIncarnation:a.grantIncarnation,runId:D(),opId:D(),resultId:D(),requestId:t.requestId,requestDigest:u,method:t.method,capability:l.capability,effect:l.effect,...o?{targetOrigin:o}:{},deadlineAt:Math.min(t.deadlineAt,i.now()+15e3),browserSessionIncarnation:r,state:"admitted",cancelSeq:0,submissionCount:0,admittedAt:d()},await e.put(Ot,f,m),await e.put(Ot,{tag:"sdk-request",grantIncarnation:a.grantIncarnation,opKey:m},c),await e.put("runs",{tag:"sdk-service",driver:"framework.sdk-service.v1",runId:f.runId,opId:f.opId,namespace:f.namespace,browserSessionIncarnation:r,state:"preparing",createdAt:d()},f.runId))
const g=await e.get("results",f.resultId)
return O(s,!1),O(N(a,n),!1),{operation:f,receipt:g,grant:a}})),m={...N(p.grant,n),...p.operation,targetOrigin:o,doc:n}
O(s,!1),O(m)
const f=function(e,t){let a=w.get(e.grantIncarnation)
return a||(a={grant:e,doc:t,controller:new AbortController},w.set(e.grantIncarnation,a)),a.controller.signal}(p.grant,n)
let g
return g=Object.freeze({...p.operation,...1===p.grant.targetScopeVersion?{signal:f}:{},authorize:e=>$(g,e),authorizeInTransaction:e=>J(e,g),recordEffect:e=>Y(g,e),recordNativeReceipt:e=>Q(g,e),get httpErrorReceipt(){return m.httpErrorReceipt},assertDispatch:()=>O(m)}),c.set(g,m),{operation:p.operation,receipt:p.receipt,context:g}},authorizeSdk:$,authorizeSdkInTransaction:J,recordSdkEffect:Y,recordSdkNativeReceipt:Q,failSdk:async function(t,a){const n=c.get(t)
return P(n,"E_OWNER","Failure requires the original driver context"),e.transaction([Ot,"runs"],"readwrite",(async e=>{const t=await e.get(Ot,n.opKey)
if(!t||t.opId!==n.opId)return
t.deliveryError={code:a.code||Tt,message:(a.message||a)+""},t.deliveryState="denied",["durable",Nt].includes(t.state)||(t.state="dispatched"===t.state?Nt:"failed"),await e.put(Ot,t,n.opKey)
const r=await e.get("runs",n.runId)
r&&await e.put("runs",{...r,state:"durable"===t.state?"completed":t.state===Nt?"paused_unknown":"failed",..."durable"===t.state?{resultId:t.resultId}:{terminalReason:t.deliveryError.message}},r.runId)}))},revokeSdkGrants:X,recoverSdk:async function(){return e.transaction([Ot,"runs","results"],"readwrite",(async e=>{const t=await e.all(Ot),a=new Map,n=new Map,i=new Map
let o=0
const s=(e,t,a)=>e.set(t,Math.max(e.get(t)||0,a))
for(const c of t)if("sdk-grant"===c.tag&&k(c)&&c.browserSessionIncarnation===r)if(1!==c.targetScopeVersion||c.workerIncarnation===h){for(const e of["tabEpoch","frameEpoch","permissionEpoch","notificationEpoch"])P(Number.isSafeInteger(c[e])&&c[e]>=0,Rt,"SDK grant epoch is malformed")
s(a,c.tabId,c.tabEpoch),s(n,v(c),c.frameEpoch),s(i,c.origin,c.permissionEpoch)
for(const[e,t]of c.originPermissionEpochs||[])s(i,e,t)
o=Math.max(o,c.notificationEpoch)}else R(c.grantIncarnation),c.active=!1,c.crossOriginActive=!1,c.closeReason="worker-restart-reapproval-required",c.closedAt=d(),await e.put(Ot,c,c.key)
for(const[r,c]of a)l.has(r)||l.set(r,c)
for(const[r,c]of n)u.has(r)||u.set(r,c)
for(const[r,c]of i)p.has(r)||p.set(r,c)
b||(E=o,b=!0)
for(const r of t){if("sdk-operation"!==r.tag)continue
"dispatched"===r.state&&(r.state=Nt,r.recoveredAt=d(),r.deliveryState="denied",r.deliveryError={code:Tt,message:"Worker restarted after SDK dispatch; no effect replay"},await e.put(Ot,r,r.opKey))
const t=await e.get("runs",r.runId)
if(P("sdk-service"===t?.tag&&t.opId===r.opId&&t.namespace===r.namespace,Tt,"SDK recovery run binding differs"),"durable"===r.state){const a=await e.get("results",r.resultId)
P("sdk-result"===a?.tag&&"durable"===a.state&&a.resultId===r.resultId&&a.runId===r.runId&&a.opId===r.opId&&a.namespace===r.namespace&&a.grantIncarnation===r.grantIncarnation&&a.opKey===r.opKey&&a.requestDigest===r.requestDigest,Tt,"SDK durable result binding differs"),await e.put("runs",{...t,state:"completed",resultId:a.resultId},t.runId)}else r.state!==Nt&&"failed"!==r.state||await e.put("runs",{...t,state:r.state===Nt?"paused_unknown":"failed",terminalReason:r.deliveryError?.message||r.state},t.runId)}}))},settleSdkDelivery:async function(t,a){const n=c.get(t)
return P(n,"E_OWNER","Delivery requires original SDK context"),e.transaction([Ot],"readwrite",(async e=>{const r=await e.get(Ot,n.opKey)
P(r?.opId===n.opId,"E_REQUEST_CONFLICT","SDK delivery admission changed"),a?"delivered"!==r.deliveryState&&(r.deliveryState="denied",r.deliveryError={code:a.code||Tt,message:(a.message||a)+""}):(await J(e,t),P("durable"===r.state,Tt,"SDK result is not durable"),r.deliveryState="response_ready",r.responseReadyAt=d(),delete r.deliveryError),await e.put(Ot,r,n.opKey)}))}}}({storage:e,api:t,session:i,clock:c,assertHost:m,currentHost:f}),E=function({storage:e,api:t,session:a,clock:r,assertHost:i,currentHost:o,loadBuiltin:s=ka,emitToHost:c=async()=>{}}){const d=new Map,l=new Map,u=new Map,p=new Map,m=new Map,f=new Set,g=new Map,I=new Map,w=[],h=(t,a,n=fn)=>e.transaction([...new Set(n)],t,a),E=()=>r.now()
async function y(e){for(const r of vn(e))try{await Ye(t,r)}catch(a){throw a.code===rn&&await K({permissionRemoved:!0,origins:[n(r)]}),a}}function b(e){return P("string"==typeof e.namespace&&e.namespace&&void 0!==e.principal,nn,"Tool namespace or principal missing"),e.namespace}function v(e,t,a=0){return{tabEpoch:g.get(e)||0,frameEpoch:I.get(H([e??null,a]))||0,rootFrameEpoch:a>0&&I.get(H([e??null,0]))||0,permissionEpoch:w.filter((e=>e.some((e=>bn(e,t))))).length}}function _(e){const t=e.target?.allowedOrigin||e.startUrl&&$e(e.startUrl).origin
if(!t||!e.nativeFence)return
const a=v(e.target?.tabId??e.nativeTabId,t,e.target?.frameId??e.selection.frameId??0)
P(a.permissionEpoch===e.nativeFence.permissionEpoch,rn,mn)
for(const n of e.nativeNetworkFences||[])P(v(e.target?.tabId??e.nativeTabId,n.origin).permissionEpoch===n.permissionEpoch,rn,mn)
P(a.tabEpoch===e.nativeFence.tabEpoch&&a.frameEpoch===e.nativeFence.frameEpoch&&a.rootFrameEpoch===e.nativeFence.rootFrameEpoch,dn,"Run document changed")}async function S(e,t,n,r,{active:i=!1}={}){return await o(e,n,r),P(t?.tag===an&&!t.tombstoned&&t.registrationId===n.registrationId&&t.hostDocumentId===n.hostDocumentId&&t.hostInstanceId===n.hostInstanceId&&t.namespace===b(n)&&t.browserSessionIncarnation===a,nn,"Controller host mismatch"),i&&(_(t),await Qa(e,t),P(gn.has(t.state)&&!t.cancelSeq&&!t.retirementId&&E()<t.deadlineAt,E()>=t.deadlineAt?on:pn,"Controller admission is fenced")),t}function A(e,t,n,{retiring:r=!1,scriptId:i,expectedRevision:s}={}){const c=n||{runId:D(),opId:D(),requestId:D(),resultId:D()},d={namespace:b(e),principal:e.principal,grantIncarnation:e.registrationId,browserSessionIncarnation:a,runId:c.runId,opId:c.opId,requestId:c.requestId,resultId:c.resultId,opKey:"controller-pin:"+c.runId,deadlineAt:r||!n?E()+15e3:n.deadlineAt,async authorizeInTransaction(a){if(await o(a,e,t),void 0!==i){const e=await a.get("scriptHeads",En(d.namespace,i))
P(e?.revision===s,"E_REVISION","Script GC CAS conflict")}if(n){const t=await a.get(cn,"controller-pin:"+n.runId)
P("controller-lease"===t?.tag&&t.registrationId===e.registrationId&&hn.every((e=>Object.hasOwn(t,e)&&On(t[e],d[e]))),nn),r||P(gn.has(t.state)&&!t.cancelSeq&&E()<t.deadlineAt,E()>=t.deadlineAt?on:pn)}return!0},authorize:async()=>h(tn,(async e=>d.authorizeInTransaction(e)),void 0===i?[Xa,cn]:["scriptHeads",cn])}
return d}async function O(e,t){await e.put(cn,{tag:"controller-lease",runId:t.runId,namespace:t.namespace,principal:t.principal,grantIncarnation:t.registrationId,opId:t.opId,requestId:t.requestId,resultId:t.resultId,browserSessionIncarnation:t.browserSessionIncarnation,registrationId:t.registrationId,cancelSeq:t.cancelSeq,state:t.state,deadlineAt:t.deadlineAt,workerRetired:t.workerRetired,retirementState:t.retirementState},"controller-pin:"+t.runId)}function k(e){Sn(e,["scriptId","expectedRevision"],["scriptId","expectedRevision"]),An(e.scriptId),P(!e.scriptId.startsWith("task:"),rn,"Installed task revisions are immutable"),P(Number.isSafeInteger(e.expectedRevision)&&e.expectedRevision>0,"E_REVISION","Exact script head required")}function T(e){return e?structuredClone(Object.fromEntries(["tag","runId","state","runRevision","ownerEpoch","cancelSeq","identity","target","revision","deadlineAt","retirementId","retirementState","resultId","terminalReason","workerRetired","scriptId","contentHash","sourceKind","networkOrigins"].filter((t=>void 0!==e[t])).map((t=>[t,e[t]])))):null}async function R(e,t){Sn(e,["runId"]),void 0!==e.runId&&An(e.runId)
const a=w.length,n=await i(t),r=await h(tn,(async a=>{await o(a,n,t)
const r=await a.get(Xa,"@slot"),i=(await a.all(Xa)).filter((e=>e.tag===an&&!e.tombstoned&&e.namespace===b(n))).sort(((e,t)=>(e.createdAt||0)-(t.createdAt||0)||e.runId.localeCompare(t.runId))),s=e.runId?i.find((t=>t.runId===e.runId)):null
e.runId&&P(s,nn)
const c=(await a.all("results")).filter((e=>"controller-result"===e.tag&&e.namespace===b(n)&&(!s||e.runId===s.runId))),d=new Set((s?[s]:i).map((e=>e.runId))),l=(await a.all("downloadReceipts")).filter((e=>"attempt"===e.tag&&d.has(e.attempt.runId))).map((({attempt:e})=>Object.fromEntries(["attemptId","runId","state","downloadId","submissionCount","artifactHash","resourceReleasedAt"].map((t=>[t,e[t]])))))
return{run:s,runs:i,results:c,downloads:l,slotAvailable:!r?.currentRunId&&!r?.preview}}),[...fn,"downloadReceipts"]),s=new Set
for(const i of r.runs)try{P(!i.resultDeliveryRevoked,rn),await y(i)}catch{s.add(i.runId)}await h(tn,(async e=>{await o(e,n,t)
for(const t of r.runs)(await e.get(Xa,t.runId))?.resultDeliveryRevoked&&s.add(t.runId)}))
for(const i of r.runs)w.slice(a).some((e=>_n(i,e)))&&s.add(i.runId)
return{...r,run:T(r.run),runs:r.runs.map(T),results:r.results.filter((e=>!s.has(e.runId))),resultDeliveryDenied:[...s]}}function U(e){Sn(e,"owned"===e?.mode?["mode","url"]:["mode","tabId","frameId","documentId","expectedUrl","expectedWindowId"]),P(["owned","borrowed"].includes(e.mode),"E_TARGET","Explicit target ownership is required"),"owned"===e.mode?$e(e.url):P(Number.isSafeInteger(e.tabId)&&e.tabId>=0&&Number.isSafeInteger(e.frameId)&&e.frameId>=0&&"string"==typeof e.documentId&&e.documentId,"E_TARGET","Exact borrowed document required"),void 0!==e.expectedUrl&&$e(e.expectedUrl),void 0!==e.expectedWindowId&&P("borrowed"===e.mode&&Number.isSafeInteger(e.expectedWindowId)&&e.expectedWindowId>=0&&0===e.frameId&&void 0!==e.expectedUrl,"E_TARGET","Current Page window required")}async function x(e,n,{bootstrapUrl:r,documentId:i,changedFrom:o}={}){for(;;){await h(tn,(async t=>{const n=await t.get(Xa,e.runId)
_(n),P(n?.tag===an&&!n.cancelSeq&&gn.has(n.state)&&n.browserSessionIncarnation===a,pn),P(E()<n.deadlineAt,on),await Qa(t,n)}),[Xa,"frameworkKV"])
try{const a=await Ze({api:t,tabId:n,documentId:i,allowExtensionUrl:r??null})
if((!o||a.documentId!==o)&&(!e.startUrl||r||$e(a.url).origin===$e(e.startUrl).origin))return a}catch(s){if(![dn,"E_TARGET"].includes(s.code))throw s}await new Promise((e=>setTimeout(e,25)))}}async function L(e,t,n,r,{post:i=!1,handoff:o}={}){const s=await S(e,await e.get(Xa,t.identity.runId),n,r,{active:!0})
return P(t.identity.tag===an&&On(t.identity,{...s.identity,target:t.target})&&On(t.revision,s.revision),nn,"Controller operation binding differs"),P(On(t.target,s.target),dn),q(s,t.operation),s.navigationRequestId&&P(s.navigationRequestId===t.requestId,dn,"Navigation fenced old operations"),o&&P(i&&o.from.documentId===s.target.documentId&&o.to.tabId===s.target.tabId&&o.to.frameId===s.target.frameId&&o.to.targetVersion===s.target.targetVersion+1&&o.to.browserSessionIncarnation===a&&o.to.mode===s.target.mode,dn,"Native navigation handoff differs"),s}function q(e,t){e.installedTaskAuthorization&&P("service"!==t.kind&&!("browser"===t.kind&&["cookies","setCookie","deleteCookie","uploadFromUrl"].includes(t.method)),"E_CAPABILITY","此安装任务未声明宿主网络、存储或 Cookie 能力；当前 Task v1 仅支持网页自动化")}function F(e,t){for(const a of l.values())a.runId===e&&a.abort.abort(new C(t,t))}async function W(e,t,a,{workerRetired:n=!1,host:r,sender:i,requestId:o,requestDigest:s}={}){return h(en,(async c=>{const d=await c.get(Xa,e)
if(P(d?.tag===an,nn),r&&await S(c,d,r,i),o){const t="controller-finish:"+H([e,o]),a=await c.get(cn,t)
a?P(a.requestDigest===s,ln):await c.put(cn,{tag:"controller-finish",runId:e,requestDigest:s},t)}const l=await c.get("results",d.resultId)
if(l)return"completed"===l.state&&"completed"===t&&P(On(l.outcome.valueWire,a.valueWire),ln,"Terminal value is immutable"),n&&!d.workerRetired&&(d.workerRetired=!0,await c.put(Xa,d,e),await O(c,d)),{run:T(d),result:l}
const u=d.cancelSeq?"E_HOST_CLOSED"===d.terminalReason?"interrupted":"stopped":t
P(In.has(u),sn)
const p=E()>=d.deadlineAt,m=p&&"completed"===u?"stopped":u,f={tag:"controller-result",resultId:d.resultId,runId:e,namespace:d.namespace,principal:d.principal,revision:d.revision,builtinIdentity:d.builtinIdentity,sourceKind:d.sourceKind,state:m,outcome:"completed"===m?{ok:!0,valueWire:a.valueWire}:{ok:!1,error:d.cancelSeq||p?kn(new C(p?on:d.terminalReason||pn,"Controller fenced")):a.error},committedAt:E()}
f.outcome.ok&&oe(f.outcome.valueWire),"completed"===m&&P(!(await c.all(cn)).some((t=>t.runId===e&&["controller-operation","controller-navigation"].includes(t.tag)&&["dispatched","effect_unknown"].includes(t.state))),un,"Unsettled effects prevent success"),d.state=m,d.cancelSeq++,d.ownerEpoch++,d.runRevision++,d.eventSeq++,d.workerRetired=n,d.retirementId=D(),d.retirementState="fenced",d.terminalReason=f.outcome.ok?null:f.outcome.error,await c.put("results",f,d.resultId),await c.put(Xa,d,e),await O(c,d)
const g=await c.get(Xa,"@slot")
return P(g?.currentRunId===e,nn),g.retirementId=d.retirementId,g.fencedEpoch=d.ownerEpoch,await c.put(Xa,g,"@slot"),{run:T(d),result:f}}))}async function z(n,i,o){if("released"===n.retirementState)return{state:"released",releaseCount:1}
if(!n.retirementId||!n.workerRetired)return{state:"pending",releaseCount:0,reason:"worker-not-retired"}
await ha({api:t,clock:r,authorize:async()=>!0}).cancel(n).catch((()=>{}))
let s="borrowed-not-closed"
if("owned"===n.selection.mode){const e=await h(tn,(e=>e.get(cn,"controller-create:"+n.runId)),[cn])
if(e&&(!Number.isSafeInteger(e.tabId)||e.browserSessionIncarnation!==a))return{state:"pending",releaseCount:0,reason:"creation-unknown"}
if(e){if(await h(en,(async t=>{const r=await t.get(Xa,n.runId)
P(r.retirementId===n.retirementId&&r.workerRetired&&r.browserSessionIncarnation===a,nn)
const i="controller-retirement:"+n.retirementId
return!(await t.get(cn,i))&&(await t.put(cn,{tag:"controller-retirement",runId:n.runId,retirementId:n.retirementId,submissionCount:1,state:"remove-dispatched",tabId:e.tabId,dispatchAt:E()},i),!0)})))try{await t.tabs.remove(e.tabId)}catch{}try{return await t.tabs.get(e.tabId),{state:"pending",releaseCount:0,reason:"owned-tab-present"}}catch(c){P(/No tab with id|Invalid tab ID|tab not found/i.test(c?.message||""),"E_TARGET","Query error is not target absence")}s="owned-tabs.get-not-found"}else s="not-created-before-dispatch"}return i&&n.revision?.pinKey&&await e.releaseScriptRevisionPin(A(i,o,n,{retiring:!0}),{scriptId:n.scriptId,revision:n.revision.revision}),h(en,(async e=>{const t=await e.get(Xa,n.runId),a=await e.get(Xa,"@slot")
if("released"===t.retirementState)return{state:"released",releaseCount:1}
if(P(t.workerRetired&&t.retirementId===n.retirementId&&a?.currentRunId===n.runId&&a.retirementId===n.retirementId&&0===a.releaseCount,nn),i&&await S(e,t,i,o),t.retirementState="released",t.runRevision++,"draft"===t.sourceKind&&delete t.draftSourceUtf8,await e.put(Xa,t,t.runId),await O(e,t),!i&&t.revision?.pinKey){const a=await e.get(cn,t.revision.pinKey)
P(a?.runId===t.runId&&a.opKey==="controller-pin:"+t.runId,nn),await e.put(cn,{...a,released:!0},t.revision.pinKey)}return await e.put(Xa,{...a,currentRunId:null,state:"available",releaseCount:1},"@slot"),p.delete(t.runId),u.delete(t.runId),m.delete(t.runId),await e.put(cn,{tag:"controller-retirement",runId:n.runId,retirementId:n.retirementId,releaseCount:1,absence:s,releasedAt:E()},"controller-retirement:"+n.retirementId),{state:"released",releaseCount:1,retirementId:n.retirementId}}))}async function V(e,{documentGone:a=!1}={}){const n=await h(tn,(async t=>(await t.all(Xa)).filter((t=>t.tag===an&&t.registrationId===e&&"released"!==t.retirementState))),[Xa])
for(const i of n)if(F(i.runId,"E_HOST_CLOSED"),a){if(In.has(i.state)){const e=await W(i.runId,"interrupted",{},{workerRetired:!0})
await z({...i,...e.run},null,null)
continue}await h(en,(async e=>{const t=await e.get(Xa,i.runId)
t.cancelSeq++,t.ownerEpoch++,t.terminalReason="E_HOST_CLOSED",await e.put(Xa,t,t.runId),await O(e,t)}),[Xa,cn])
const e=await W(i.runId,"interrupted",{error:kn(new C("E_HOST_CLOSED","Host document is gone"))},{workerRetired:!0})
await ha({api:t,clock:r,authorize:async()=>!0}).cancel(i).catch((()=>{})),await z({...i,...e.run},null,null)}else await h(en,(async e=>{const t=await e.get(Xa,i.runId)
In.has(t.state)||(t.state="paused_unknown",t.runRevision++,await e.put(Xa,t,t.runId),await O(e,t))}),[Xa,cn])}async function K({tabId:e,frameId:t=0,documentId:a,removed:n=!1,permissionRemoved:r=!1,origins:i=[]}={}){if(r){if(P(Array.isArray(i)&&i.every((e=>"string"==typeof e)),sn),!i.length)return[]
w.push([...i])}else if(Number.isSafeInteger(e)){const r=[...p].filter((([,a])=>a.tabId===e&&a.frameId===t))
if(n)g.set(e,(g.get(e)||0)+1)
else if(!(0===t&&[...m.values()].includes(e)||r.some((([e,t])=>u.has(e)||a===t.documentId)))){const a=H([e,t])
I.set(a,(I.get(a)||0)+1)}}const o=await h(en,(async o=>{const s=[]
for(const c of await o.all(Xa))if(c.tag===an){if(r){if(!_n(c,i))continue}else if(c.target?.tabId!==e&&c.nativeTabId!==e||!n&&0!==t&&(c.target?.frameId??c.selection.frameId??0)!==t)continue
r&&(c.resultDeliveryRevoked=!0,await o.put(Xa,c,c.runId)),gn.has(c.state)&&(n||r||!c.navigationRequestId&&m.get(c.runId)!==e)&&(n||r||a!==c.target?.documentId)&&(n||r||0!==t||a!==c.target?.rootDocumentId)&&(c.cancelSeq++,c.ownerEpoch++,c.runRevision++,c.state="stopping",c.terminalReason=r?rn:dn,await o.put(Xa,c,c.runId),s.push(c),await O(o,c))}return s}),[Xa,cn])
for(const s of o)F(s.runId,s.terminalReason),await c(s.registrationId,{type:"controller-fenced",runId:s.runId,reasonCode:s.terminalReason}).catch((()=>{}))
return o.map(T)}return Object.freeze({commitControllerScript:async function(a,n){Sn(a,["scriptId","expectedRevision","sourceUtf8","contentHash"],["scriptId","expectedRevision","sourceUtf8"]),P(!a.scriptId?.startsWith("task:"),rn,"Installed task IDs are reserved")
const r=await i(n),o=Ta(await s({runtime:t.runtime}))
return e.commitScriptRevision(A(r,n),{...a,builtinIdentity:o})},getControllerScript:async function(t,a){Sn(t,["scriptId","revision"],["scriptId"]),An(t.scriptId)
const n=await i(a)
return e.transaction(["scriptHeads","scriptRevisions",cn],tn,(async e=>{await o(e,n,a)
const r=await e.get("scriptHeads",En(b(n),t.scriptId))
P(r&&!r.tombstoned,"E_TOMBSTONE","Script is not available")
const i=t.revision??r.revision
P(Number.isSafeInteger(i)&&i>0,"E_REVISION")
const s=await e.get("scriptRevisions",En(n.namespace,t.scriptId,i))
return P(s&&await j(s.sourceUtf8)===s.contentHash,"E_HASH","Stored script bytes differ"),s}))},listControllerScripts:async function(t,a){Sn(t??{},[])
const n=await i(a)
return e.transaction(["scriptHeads",cn],tn,(async e=>(await o(e,n,a),(await e.all("scriptHeads")).filter((e=>"script-head"===e?.tag&&e.namespace===b(n)&&!e.tombstoned&&!e.scriptId.startsWith("task:"))).map((e=>({scriptId:e.scriptId,revision:e.revision,contentHash:e.contentHash}))).sort(((e,t)=>e.scriptId.localeCompare(t.scriptId))))))},tombstoneControllerScript:async function(t,a){k(t)
const n=await i(a)
return e.tombstoneScript(A(n,a),t)},garbageCollectControllerScript:async function(t,a){k(t)
const n=await i(a)
return e.garbageCollectScript(A(n,a,void 0,t),{scriptId:t.scriptId})},startControllerRun:async function(n,r){U(n.target)
let c=!1
const d=n.target,l=e=>{e.tabId===d.tabId&&e.frameId===d.frameId&&(void 0!==e.documentId&&e.documentId!==d.documentId||e.url!==d.expectedUrl)&&(c=!0)},u=[[t.tabs.onActivated,e=>{e.windowId===d.expectedWindowId&&e.tabId!==d.tabId&&(c=!0)}],[t.tabs.onUpdated,(e,t,a)=>{e===d.tabId&&(["loading","unloaded"].includes(t.status)||t.pendingUrl||void 0!==t.url&&t.url!==d.expectedUrl||a?.incognito)&&(c=!0)}],[t.tabs.onRemoved,e=>{e===d.tabId&&(c=!0)}],[t.webNavigation.onBeforeNavigate,e=>{e.tabId===d.tabId&&e.frameId===d.frameId&&(c=!0)}],[t.webNavigation.onCommitted,l],[t.webNavigation.onHistoryStateUpdated,l],[t.webNavigation.onReferenceFragmentUpdated,l],[t.windows?.onRemoved,e=>{e===d.expectedWindowId&&(c=!0)}]],f=()=>P(!c,"E_DOCUMENT_STALE","Captured Current Page changed during admission")
if(void 0!==d.expectedWindowId)for(const[e,t]of u)e?.addListener(t)
try{return await async function(n,r,c){Sn(n,["requestId","scriptId","revision","contentHash","source","paramsWire","target","deadlineAt","networkOrigins","expectedTaskGeneration","expectedTaskInstallationId"],["requestId","paramsWire","target","deadlineAt"]),An(n.requestId),U(n.target)
const d=oe(n.paramsWire),l=Ta(await s({runtime:t.runtime})),u=n.source,f="draft"===u?.kind
void 0!==u&&(P(!["scriptId","revision","contentHash"].some((e=>Object.hasOwn(n,e))),sn,"Mixed source variants"),P("draft"===u?.kind||"saved"===u?.kind,sn,"Unknown controller source variant"),Sn(u,f?["kind","sourceUtf8"]:["kind","scriptId","revision","contentHash"],f?["kind","sourceUtf8"]:["kind","scriptId","revision","contentHash"]))
const w=f?null:u||n,y=!f&&w.scriptId?.startsWith("task:")
P(y?Object.hasOwn(n,"expectedTaskGeneration")&&Object.hasOwn(n,"expectedTaskInstallationId"):!Object.hasOwn(n,"expectedTaskGeneration")&&!Object.hasOwn(n,"expectedTaskInstallationId"),"E_REVISION","安装任务必须绑定点击时的安装身份和授权代次")
const _=f?u.sourceUtf8:void 0
f?(P("string"==typeof _&&(new TextEncoder).encode(_).byteLength<=N.maxRawFrameBytes-8192,"E_LIMIT","Draft source exceeds safe host message budget"),ie(_)):(An(w.scriptId),P(Number.isSafeInteger(w.revision)&&w.revision>0&&/^[a-f0-9]{64}$/.test(w.contentHash),"E_REVISION")),P(Number.isSafeInteger(n.deadlineAt)&&n.deadlineAt>E(),on)
const k=f?await j(_):w.contentHash,R=await i(r),C=await M(n,wn),L="owned"===n.target.mode?$e(n.target.url).origin:null
let q
"borrowed"===n.target.mode?q=await Ze({api:t,...n.target}):await Ye(t,$e(n.target.url).origin)
const F=function(e,t=[],{installedTask:a=!1}={}){const n=St(e,t).targetOrigins
return P(!a||!n.length,"E_PERMISSION","安装任务必须单独授权跨站网络"),n}(L||q.allowedOrigin,n.networkOrigins??[],{installedTask:y})
for(const e of F)await Ye(t,e)
const V=F.map((e=>({origin:e,permissionEpoch:v(n.target.tabId,e).permissionEpoch}))),K=v(n.target.tabId,L||q.allowedOrigin,n.target.frameId??0),B="controller-start:"+H([R.registrationId,n.requestId]),G=await h(en,(async t=>{await o(t,R,r),c()
const i=y?await Za(t,b(R),{scriptId:w.scriptId,contentHash:w.contentHash,origin:L||q.allowedOrigin,params:d,migrate:!0,builtinIdentity:l,expectedGeneration:n.expectedTaskGeneration,expectedInstallationId:n.expectedTaskInstallationId}):null,s=await t.get(cn,B)
if(s){P(s.requestDigest===C,ln)
const e=await S(t,await t.get(Xa,s.runId),R,r)
return Ra(e.builtinIdentity,l),Ra(e.revision?.builtinIdentity,l),{run:e,duplicate:!0}}const u=await t.get(Xa,"@slot")
P(!u?.currentRunId&&!u?.preview,nn,"Previous target or preview still active")
const p=D(),m=f?"draft:"+p:w.scriptId,g={tag:an,runId:p,namespace:b(R),principal:R.principal,registrationId:R.registrationId,hostDocumentId:R.hostDocumentId,hostInstanceId:R.hostInstanceId,browserSessionIncarnation:a,scriptId:m,contentHash:k,builtinAbi:Ea,sourceKind:f?"draft":"saved",builtinIdentity:l,...f?{draftSourceUtf8:_}:{},...i?{installedTaskAuthorization:{taskId:i.installation.taskId,version:i.installation.version,manifestHash:i.installation.manifestHash,authorization:i.installation.authorization}}:{},opId:D(),resultId:D(),requestId:n.requestId,requestDigest:C,deadlineAt:n.deadlineAt,paramsWire:structuredClone(n.paramsWire),selection:structuredClone(n.target),startUrl:"owned"===n.target.mode?$e(n.target.url).href:null,nativeFence:K,nativeNetworkFences:V,networkOrigins:F,nativeTabId:n.target.tabId??null,state:"preparing",ownerEpoch:1,runRevision:1,eventSeq:0,cancelSeq:0,workerRetired:!1,retirementState:"not-started",target:null,identity:null,revision:null,createdAt:E()}
let I
return await t.put(Xa,g,p),await O(t,g),f?(P(await j(g.draftSourceUtf8)===k,"E_HASH","Draft source changed at admission"),g.revision={kind:"draft",scriptId:g.scriptId,revision:1,sourceHash:k,builtinIdentity:l}):(I=await e.pinScriptRevision(A(R,r,g),w,t),Ra(I.revision.builtinIdentity,l),g.revision={scriptId:g.scriptId,revision:I.revision.revision,builtinIdentity:l,sourceHash:I.revision.contentHash,pinKey:I.pinKey}),await t.put(Xa,g,p),await t.put(Xa,{tag:"slot",currentRunId:p,state:"held",releaseCount:0,fencedEpoch:1,retirementId:null},"@slot"),await t.put(cn,{tag:"controller-start",runId:p,requestDigest:C},B),{run:g,pinned:I,duplicate:!1}}),f?fn:[...fn,"scriptHeads","scriptRevisions",...y?["frameworkKV"]:[]]),J=G.run
if(G.duplicate)return{runId:J.runId,state:J.state,duplicate:!0,runRevision:J.runRevision}
try{const e=G.pinned
return q||(q=await async function(e,n,r){const i="controller-create:"+e.runId,o=await h(en,(async o=>{const s=await S(o,await o.get(Xa,e.runId),n,r,{active:!0})
P(!(await o.get(cn,i)),un,"Owned creation dispatch is never replayed")
const c=D(),d=t.runtime.getURL("ui/target-bootstrap.html?creationId="+encodeURIComponent(c)),l={tag:"controller-target-create",runId:s.runId,creationId:c,browserSessionIncarnation:a,bootstrapUrl:d,state:"dispatched",submissionCount:1,tabId:null,dispatchAt:E()}
return await o.put(cn,l,i),l}))
await Ye(t,$e(e.startUrl).origin),await h(tn,(t=>S(t,e,n,r,{active:!0})))
const s=await t.tabs.create({url:o.bootstrapUrl,active:!1})
P(Number.isSafeInteger(s?.id),un,"No native owned tab receipt"),m.set(e.runId,s.id),await h(en,(async t=>{const a=await t.get(cn,i)
P(1===a.submissionCount&&null===a.tabId,un),a.tabId=s.id,a.receiptAt=E(),a.state="created",await t.put(cn,a,i)
const n=await t.get(Xa,e.runId)
n.nativeTabId=s.id,n.nativeFence.tabEpoch=g.get(s.id)||0,n.nativeFence.frameEpoch=I.get(H([s.id,0]))||0,await t.put(Xa,n,n.runId)}))
const c=await x(e,s.id,{bootstrapUrl:o.bootstrapUrl})
return await Ye(t,$e(e.startUrl).origin),await h(en,(async t=>{await S(t,await t.get(Xa,e.runId),n,r,{active:!0})
const a=await t.get(cn,i)
P(!a.navigationSubmissionCount,un),a.bootstrapDocumentId=c.documentId,a.navigationSubmissionCount=1,a.navigationState="dispatched",await t.put(cn,a,i)})),await t.tabs.update(s.id,{url:e.startUrl}),{...await x(e,s.id,{changedFrom:c.documentId}),creationId:o.creationId}}(J,R,r)),await Qe({api:t,target:q,expectedUrl:n.target.expectedUrl,expectedWindowId:n.target.expectedWindowId}),await h(en,(async t=>{const i=await S(t,await t.get(Xa,J.runId),R,r,{active:!0})
return c(),i.target={...q,targetSessionId:D(),targetVersion:1,mode:n.target.mode,browserSessionIncarnation:a},i.identity={tag:an,runId:i.runId,hostInstanceId:R.hostInstanceId,hostDocumentId:R.hostDocumentId,ownerEpoch:i.ownerEpoch,scriptId:i.scriptId,revision:i.revision.revision,contentHash:i.contentHash,target:i.target},f&&P(await j(i.draftSourceUtf8)===i.revision.sourceHash,"E_HASH","Admitted draft bytes do not match their SHA-256"),i.state="running",i.runRevision++,i.eventSeq++,p.set(i.runId,i.target),m.delete(i.runId),await t.put(Xa,i,i.runId),await O(t,i),c(),{...T(i),sourceUtf8:f?i.draftSourceUtf8:e.revision.sourceUtf8,paramsWire:i.paramsWire}}))}catch($){const e=await W(J.runId,"failed",{error:kn($)},{workerRetired:!0})
throw await z({...J,...e.run},R,r),$.runId=J.runId,$}}(n,r,f)}finally{if(void 0!==d.expectedWindowId)for(const[e,t]of u)e?.removeListener(t)}},controllerOperation:async function(n,o){Sn(n,["envelope"],["envelope"])
const s=structuredClone(n.envelope)
Sn(s,["requestId","identity","revision","target","operation"],["requestId","identity","revision","target","operation"]),An(s.requestId),P(s.identity?.tag===an,nn),An(s.identity.runId),Sn(s.operation,["kind","method","args"],["kind","method","args"]),P(Array.isArray(Ft(s.operation.args,{maxBytes:"uploadChunk"===s.operation.method?131072:65536})),sn)
const c="service"===s.operation.kind
let m
if(c){const e=s.operation.method,t=Ft(s.operation.args)
P(Object.hasOwn(qe,e)&&/^(AXIOS_|APPSTORAGE_|APPLOCAL_|CHROME_LOCAL_)/.test(e),"E_CAPABILITY"),P(1===t.length,sn),m=ze(e,t[0])}const g=await i(o),I=yn(s.identity.runId,s.requestId),w=await M(s,wn),{previous:b,run:A}=await h(tn,(async e=>{const t=await S(e,await e.get(Xa,s.identity.runId),g,o),a=await e.get(cn,I)
return a&&P(a.requestDigest===w,ln),{previous:a,run:t}}))
if(c&&"durable"===b?.state&&!b.reply&&Object.hasOwn(b,"valueWire")&&(b.reply={requestId:s.requestId,value:qt(oe(b.valueWire))}),b?.reply){const e=b.reply.handoff?.to||s.target
return await y(A),await Qe({api:t,target:e}),await h(tn,(async t=>{const a=await S(t,await t.get(Xa,s.identity.runId),g,o,{active:!0})
q(a,s.operation),P(On(s.identity,{...a.identity,target:s.target})&&On(s.revision,a.revision),nn),P(On(e,a.target)&&!a.navigationRequestId,dn)})),b.reply}if(d.has(I))return d.get(I)
if(b)throw new C(un,"Cannot replay a dispatched operation")
const k=async function(){const n="browser"===s.operation.kind&&["goto","reload"].includes(s.operation.method),i=c&&"draft"===A.sourceKind&&/^AXIOS_(GET|POST|PUT|DELETE)$/.test(s.operation.method)?$e(m.url).origin:null
i&&i!==s.target.allowedOrigin&&!(A.networkOrigins||[]).includes(i)&&await Ye(t,i)
const d=await h(en,(async e=>{const t=await L(e,s,g,o)
return P(!(await e.get(cn,I)),un),i&&i!==t.target.allowedOrigin&&!t.networkOrigins.includes(i)&&(P("draft"===t.sourceKind,rn),P(t.networkOrigins.length<32,"E_LIMIT","本次开发草稿已访问 32 个额外 Origin，请结束后重新运行"),t.networkOrigins.push(i),t.nativeNetworkFences.push({origin:i,permissionEpoch:v(t.target.tabId??t.nativeTabId,i).permissionEpoch}),await e.put(Xa,t,t.runId)),n&&(P(!t.navigationRequestId,dn),t.navigationRequestId=s.requestId,await e.put(Xa,t,t.runId)),await e.put(cn,{tag:n?"controller-navigation":"controller-operation",runId:t.runId,...c?{lifecycle:"controller",namespace:t.namespace,principal:t.principal,grantIncarnation:t.registrationId,browserSessionIncarnation:a,opId:I,requestId:s.requestId,resultId:I+":result",method:s.operation.method}:{},requestDigest:w,envelope:s,state:"dispatched",submissionCount:1,dispatchAt:E()},I),t}))
n&&u.set(d.runId,s.requestId)
const b=new AbortController
l.set(I,{runId:d.runId,abort:b})
const S=async(e,a={})=>(P(On(e,s),nn),void 0!==a.url&&function({url:e,sourceOrigin:t,additionalOrigins:a=[],serviceCall:n=!1,method:r="",capability:i}={}){const o=$e(e).origin
P(o===t||n&&"network"===i&&/^AXIOS_(GET|POST|PUT|DELETE)$/.test(r)&&a.includes(o),"E_PERMISSION","Cross-origin controller operation denied: "+o+"；请在「开发」授权精确 Origin，网页 SDK 授权不通用")}({url:a.url,sourceOrigin:s.target.allowedOrigin,additionalOrigins:d.networkOrigins||[],serviceCall:c,method:s.operation.method,capability:a.capability}),await y(d),a.handoff?await Qe({api:t,target:a.handoff.to}):a.navigationPending?(P(n,nn,"Only the original navigation may cross documents"),P((await Ze({api:t,tabId:s.target.tabId,frameId:s.target.frameId})).allowedOrigin===s.target.allowedOrigin,rn)):await Qe({api:t,target:s.target}),h(tn,(e=>L(e,s,g,o,{post:"post"===a.phase,handoff:a.handoff})))),k=ha({api:t,clock:r,authorize:S,withWrite:async(e,t)=>{const a=e.runId
P(!f.has(a),"E_WRITE_CONFLICT"),f.add(a)
try{return await t()}finally{f.delete(a)}}}),T=async e=>h(en,(async t=>{const a=await t.get(cn,I)
P(a?.requestDigest===w,ln),"locator.commitNoEffect"===e.stage&&(a.locatorNoEffectCount=(a.locatorNoEffectCount||0)+1,a.nativeReceipts=(a.nativeReceipts||[]).filter((e=>"locator.commitIntent"!==e.stage&&"locator.commitNoEffect"!==e.stage))),(a.nativeReceipts||=[]).push(structuredClone(e)),await t.put(cn,a,I)}),[cn]),R=async e=>{const t=ie(e),a={requestId:s.requestId,value:qt(e)}
return await h(en,(async e=>{const n=await e.get(cn,I)
P(n?.requestDigest===w,ln),await e.put("results",{...Object.fromEntries(hn.map((e=>[e,n[e]]))),tag:"controller-service-result",opKey:I,requestDigest:w,state:"durable",valueWire:t,committedAt:E()},n.resultId),n.state="durable",n.valueWire=t,n.reply=a,n.receiptAt=E(),await e.put(cn,n,I)})),a}
try{const t=c?await async function(){const t={lifecycle:"controller",namespace:d.namespace,principal:d.principal,grantIncarnation:d.registrationId,browserSessionIncarnation:a,runId:d.runId,opId:I,requestId:s.requestId,resultId:I+":result",opKey:I,method:s.operation.method,requestDigest:w,deadlineAt:d.deadlineAt,signal:b.signal,authorize:e=>S(s,e),authorizeInTransaction:e=>L(e,s,g,o),assertDispatch(){_(d),P(!b.signal.aborted&&E()<d.deadlineAt,pn)},recordNativeReceipt:T,recordEffect:R},n={AXIOS_GET:"GET",AXIOS_POST:"POST",AXIOS_PUT:"PUT",AXIOS_DELETE:"DELETE"}[t.method],i=n?await Pt({clock:r,authorize:(e,t)=>t.authorize(e)}).request({method:n,...m},t):await e.executeSdk(t.method,m,t)
return{requestId:s.requestId,value:qt(i)}}():await k.execute(s,{signal:b.signal,deadlineAt:d.deadlineAt,recordReceipt:T})
P(t?.requestId===s.requestId,"E_RESULT_FORMAT")
const i=t.error?void 0:ie(Ft(t.value))
return await h(en,(async e=>{const a=await e.get(cn,I)
if(P(a?.requestDigest===w&&1===a.submissionCount,ln),t.error){const e=s.operation.kind,n="browser"===e&&Ia.includes(s.operation.method),r="user-script"===e?"userScripts.finalFailure":"packaged"===e?"packaged.finalFailure":n?"cookies.preflightFailure":void 0,i=r&&a.nativeReceipts?.find((e=>e.stage===r&&e.requestId===s.requestId))
if(P(i?.receipt?.frameId===s.target.frameId&&i.receipt.documentId===s.target.documentId&&On(i.receipt.error,t.error)&&("packaged"!==e||i.receipt.runId===s.identity.runId&&i.receipt.ownerEpoch===s.identity.ownerEpoch),"E_RESULT_FORMAT","Unverified target completion receipt"),n){const e=a.nativeReceipts,n=e.filter((e=>"result"===e.stage))
P(1===e.filter((e=>e.stage===r)).length&&"input-preflight"===i.receipt.phase&&i.receipt.method===s.operation.method&&i.receipt.runId===s.identity.runId&&i.receipt.ownerEpoch===s.identity.ownerEpoch&&wa.includes(t.error.code)&&1===n.length&&n[0].requestId===s.requestId&&On(n[0].receipt,t)&&e.every((e=>e.requestId===s.requestId&&["webNavigation.getAllFrames",r,"result"].includes(e.stage))),"E_RESULT_FORMAT","Cookie preflight lacks a no-dispatch receipt")}a.effectState="failure-observed",a.failure=structuredClone(t.error)}else a.valueWire=i
a.state="durable",a.receiptAt=E(),a.reply=t,t.handoff&&(a.targetTransition={navigationIntentId:s.requestId,from:structuredClone(t.handoff.from),to:structuredClone(t.handoff.to)}),await e.put(cn,a,I)})),await h(en,(async e=>{const a=await L(e,s,g,o,{post:!0,handoff:t.handoff})
return n&&(P(t.handoff,dn),a.target=structuredClone(t.handoff.to),a.identity.target=a.target,p.set(a.runId,a.target),delete a.navigationRequestId,a.runRevision++,a.eventSeq++,await e.put(Xa,a,a.runId)),t}))}catch(N){const e=await h(en,(async e=>{const t=await e.get(cn,I)
if(!t||"durable"===t.state)return
if(c&&"E_HTTP"===N.code&&t.nativeReceipts?.some((e=>Number.isInteger(e.status))))return t.state="durable",t.effectState="response-observed",t.receiptAt=E(),t.reply={requestId:s.requestId,error:{...kn(N),cause:{status:N.status,response:N.response}}},t.failure=kn(N),await e.put(cn,t,I),t.reply
const a="E_USER_SCRIPTS_UNAVAILABLE"===N.code&&"user-script"===s.operation.kind&&!function(e){return!0===e?.nativeReceipts?.some((e=>"webNavigation.getAllFrames"!==e.stage))}(t),n=(t.nativeReceipts||[]).filter((e=>"locator.commitIntent"===e.stage||"locator.commitNoEffect"===e.stage)).at(-1),r="packaged"===s.operation.kind&&"locatorAction"===s.operation.method&&"locator.commitIntent"===n?.stage
t.state=r?"effect_unknown":N.code===pn||N.code===on?"cancelled":a?"failed":"effect_unknown",t.failure=kn(N),t.deliveryState="fenced",await e.put(cn,t,I)
const i=await e.get(Xa,d.runId)
i?.navigationRequestId===s.requestId&&delete i.navigationRequestId,i&&gn.has(i.state)&&!i.cancelSeq&&"effect_unknown"===t.state&&(i.state="paused_unknown",i.terminalReason=kn(N),i.runRevision++),i&&(await e.put(Xa,i,i.runId),await O(e,i))}))
if(e)return await S(s,{phase:"post"}),e
throw N}finally{l.delete(I),n&&u.delete(d.runId)}}()
d.set(I,k)
try{return await k}finally{d.get(I)===k&&d.delete(I)}},stopControllerRun:async function(e,a){Sn(e,["runId","requestId","expectedRunRevision","reason"],["runId","requestId"]),An(e.runId),An(e.requestId)
const n=await i(a),o="controller-stop:"+H([e.runId,e.requestId]),s=await h(en,(async t=>{const r=await S(t,await t.get(Xa,e.runId),n,a),i=await t.get(cn,o)
if(i)return P(i.requestDigest===H(e),ln),i.response
r.cancelSeq||In.has(r.state)||r.retirementId||(P(void 0===e.expectedRunRevision||e.expectedRunRevision===r.runRevision,"E_REVISION"),r.cancelSeq++,r.ownerEpoch++,r.runRevision++,r.eventSeq++,r.state="stopping",r.terminalReason=e.reason||pn,await t.put(Xa,r,r.runId),await O(t,r))
const s={runId:r.runId,state:r.state,cancelSeq:r.cancelSeq,runRevision:r.runRevision}
return await t.put(cn,{tag:"controller-stop",requestDigest:H(e),response:s},o),s}))
F(e.runId,e.reason===on?on:pn)
const c=await h(tn,(t=>t.get(Xa,e.runId)),[Xa])
return await ha({api:t,clock:r,authorize:async()=>!0}).cancel(c).catch((()=>{})),s},finishControllerRun:async function(e,t){Sn(e,["runId","requestId","status","valueWire","error","workerRetired"],["runId","requestId","status","workerRetired"]),An(e.runId),An(e.requestId),P(["succeeded","error","stopped","timeout","host-closed"].includes(e.status)&&"boolean"==typeof e.workerRetired,sn),"succeeded"===e.status&&oe(e.valueWire)
const a=await i(t)
await h(tn,(async n=>S(n,await n.get(Xa,e.runId),a,t)))
const n="succeeded"===e.status?"completed":"error"===e.status?"failed":"host-closed"===e.status?"interrupted":"stopped",r=await W(e.runId,n,"succeeded"===e.status?{valueWire:e.valueWire}:{error:e.error||kn(new C("timeout"===e.status?on:pn,e.status))},{...e,host:a,sender:t,requestDigest:await M(e,wn)})
return F(e.runId,"timeout"===e.status?on:pn),P((await R({runId:e.runId},t)).results.some((e=>e.resultId===r.result.resultId)),rn,mn),r},snapshotControllerRun:R,retireControllerTarget:async function(e,t){Sn(e,["runId"],["runId"]),An(e.runId)
const a=await i(t)
return z(await h(tn,(async n=>S(n,await n.get(Xa,e.runId),a,t))),a,t)},loseControllerHost:V,invalidateControllerTarget:K,recoverControllers:async function(){const e=await h(en,(async e=>{for(const t of await e.all(cn))["controller-operation","controller-navigation","controller-target-create"].includes(t.tag)&&"dispatched"===t.state&&(t.state="effect_unknown",await e.put(cn,t,"controller-target-create"===t.tag?"controller-create:"+t.runId:yn(t.runId,t.envelope.requestId)))
for(const t of await e.all(Xa))t.tag===an&&(In.has(t.state)||(t.state="paused_unknown",t.runRevision++,t.terminalReason="worker-restart",await e.put(Xa,t,t.runId)),await O(e,t))
return{replayed:0}})),a=await(t.runtime?.getContexts?.({}).catch((()=>null)))
if(Array.isArray(a)){const e=await h(tn,(async e=>(await e.all(Xa)).filter((e=>e.tag===an&&"released"!==e.retirementState))),[Xa])
for(const t of e)a.some((e=>e.documentId===t.hostDocumentId))||await V(t.registrationId,{documentGone:!0})}return e}})}({storage:e,api:t,session:i,clock:c,assertHost:m,currentHost:f,loadBuiltin:d,emitToHost:l}),y=function({storage:e,api:t,assertHost:a,currentHost:n,clock:r={now:()=>Date.now()},loadBuiltin:i=ka}){async function o(e,t,a){if(a)for(const n of await e.all("runs")){if("controller-run"!==n.tag||n.namespace!==t||!["preparing","running","stopping"].includes(n.state)||n.installedTaskAuthorization?.taskId!==a.taskId&&n.scriptId!==a.scriptId)continue
n.cancelSeq++,n.ownerEpoch++,n.runRevision++,n.eventSeq++,n.state="stopping",n.terminalReason="E_PERMISSION",await e.put("runs",n,n.runId)
const r="controller-pin:"+n.runId,i=await e.get("commandJournal",r)
i&&await e.put("commandJournal",{...i,cancelSeq:n.cancelSeq,state:n.state},r)}}async function s(t,r,i,o){const s=await a(t)
return e.transaction([...new Set([...r,"commandJournal"])],i,(async e=>{await n(e,s,t)
const a=await o(e,s.namespace,s)
return await n(e,s,t),a}))}const c=async()=>Ta(await i({runtime:t?.runtime}))
return{importTaskPackage:async function(e,t){const a=await c()
Ba(e,["package"])
const n=await Wa(e.package),{taskId:i,version:o}=n.manifest
return s(t,[za],"readwrite",(async(e,t)=>{const s=ja(t,i,o),c=await e.get(za,s)
if(c)return $a(c,t),P(c.package.manifestHash===n.manifestHash&&c.package.sourceUtf8===n.sourceUtf8,"E_REQUEST_CONFLICT","Task version is immutable"),Ra(c.builtinIdentity,a),Ja(c)
const d={tag:"task-candidate-v1",namespace:t,taskId:i,version:o,package:n,builtinIdentity:a,stage:"candidate",verification:null,createdAt:r.now()}
return await e.put(za,d,s),Ja(d)}))},listTaskCatalog:async function(e,t){return Ba(e??{},[]),s(t,[za],"readonly",(async(e,t)=>{const a=(await e.all(za)).filter((e=>"task-candidate-v1"===e?.tag&&e.namespace===t)),n=(await e.all(za)).filter((e=>"task-installed-v1"===e?.tag&&e.namespace===t)),r=new Map(n.map((e=>[e.taskId,e])))
return{catalog:a.map((e=>({...Ja(e),installed:r.get(e.taskId)?.version===e.version,enabled:r.get(e.taskId)?.version===e.version&&r.get(e.taskId).enabled}))),installed:n.map((e=>({taskId:e.taskId,version:e.version,manifestHash:e.manifestHash,scriptId:e.scriptId,enabled:e.enabled,installedAt:e.installedAt,installationId:e.authorization?.installationId??null,generation:e.authorization?.generation??null})))}}))},getTaskCandidate:async function(e,t){return Ba(e,["taskId","version"]),Ga(e.taskId),Ga(e.version),s(t,[za],"readonly",(async(t,a)=>{const n=$a(await t.get(za,ja(a,e.taskId,e.version)),a)
return await Wa(n.package),{...Ja(n),package:structuredClone(n.package)}}))},verifyTaskCandidate:async function(e,t){const a=await c()
return Ba(e,["taskId","version","runId"]),Ga(e.runId),s(t,[za,"runs","results"],"readwrite",(async(t,n)=>{const i=ja(n,e.taskId,e.version),o=$a(await t.get(za,i),n)
if(await Wa(o.package),Ra(o.builtinIdentity,a),"candidate"!==o.stage)return Ka(o),Ja(o)
const s=await t.get("runs",e.runId),c=s?.resultId&&await t.get("results",s.resultId),d=o.package.manifest,l=d.program.sourceHash
P("controller-run"===s?.tag&&s.namespace===n&&"completed"===s.state&&"released"===s.retirementState&&!0===s.workerRetired&&s.revision?.sourceHash===l&&!s.resultDeliveryRevoked&&s.target?.allowedOrigin===d.siteOrigins[0]&&"controller-result"===c?.tag&&c.resultId===s.resultId&&c.namespace===n&&c.runId===s.runId&&"completed"===c.state&&!0===c.outcome?.ok&&c.revision?.sourceHash===l,"E_VERIFICATION","No matching durable completed Controller run"),P(s.builtinAbi===Ea,"E_BUILTIN_VERSION_UNAVAILABLE","任务验证必须与当前内置库版本一致")
const u=[]
for(const e of await t.all("commandJournal")){const t=e?.envelope
if("controller-operation"!==e?.tag||e.runId!==s.runId||"durable"!==e.state||e.reply?.error||e.reply?.requestId!==t?.requestId||!["packaged","browser","user-script"].includes(t?.operation?.kind)||"controller-run"!==t.identity?.tag||t.identity.runId!==s.runId||t.identity.scriptId!==s.scriptId||t.identity.contentHash!==l||t.identity.hostInstanceId!==s.hostInstanceId||t.identity.hostDocumentId!==s.hostDocumentId||t.revision?.sourceHash!==l||t.target?.allowedOrigin!==d.siteOrigins[0])continue
const a=e.nativeReceipts?.find((e=>"result"===e.stage&&e.requestId===t.requestId&&e.receipt?.requestId===t.requestId))
a&&e.requestDigest===await M(t,{maxDepth:48})&&H(e.reply,{maxDepth:48})===H(a.receipt,{maxDepth:48})&&u.push(e)}return P(u.length>0,"E_VERIFICATION","Exact successful native page-effect receipt is required"),Ra(o.builtinIdentity,s.builtinIdentity),Ra(o.builtinIdentity,c.builtinIdentity),o.stage="verified",o.verification={runId:s.runId,resultId:c.resultId,sourceHash:l,builtinIdentity:a,builtinAbi:s.builtinAbi,manifestHash:o.package.manifestHash,origin:s.target.allowedOrigin,nativeReceiptCount:u.length,verifiedAt:r.now()},await t.put(za,o,i),Ja(o)}))},makeTaskAvailable:async function(e,t){const a=await c()
return Ba(e,["taskId","version","manifestHash"]),s(t,[za],"readwrite",(async(t,n)=>{const i=ja(n,e.taskId,e.version),o=$a(await t.get(za,i),n)
return await Wa(o.package),P(o.package.manifestHash===e.manifestHash&&o.verification?.sourceHash===o.package.manifest.program.sourceHash&&o.verification?.manifestHash===o.package.manifestHash&&["verified","available"].includes(o.stage),"E_VERIFICATION","Task lacks trusted local verification"),Ka(o),Ra(o.builtinIdentity,a),Ra(o.verification.builtinIdentity,a),o.stage="available",o.availableAt??=r.now(),await t.put(za,o,i),Ja(o)}))},installTask:async function(e,t){const a=await c()
return Ba(e=structuredClone(e),["taskId","version","manifestHash","expectedInstalledVersion","expectedGeneration","expectedInstallationId"],["taskId","version","manifestHash","expectedInstalledVersion"]),P(null===e.expectedInstalledVersion||"string"==typeof e.expectedInstalledVersion,"E_SCHEMA"),s(t,[za,"scriptHeads","scriptRevisions","runs"],"readwrite",(async(t,n)=>{const i=$a(await t.get(za,ja(n,e.taskId,e.version)),n),s=await Wa(i.package)
P("available"===i.stage&&i.verification?.manifestHash===s.manifestHash&&i.verification?.sourceHash===s.manifest.program.sourceHash&&s.manifestHash===e.manifestHash,"E_VERIFICATION","Only exact Available task versions can install"),Ka(i),Ra(i.builtinIdentity,a),Ra(i.verification.builtinIdentity,a)
const c=qa(n,e.taskId),d=await t.get(za,c)
P((d?.version??null)===e.expectedInstalledVersion&&(d?e.expectedGeneration===(d.authorization?.generation??null)&&e.expectedInstallationId===(d.authorization?.installationId??null):null===(e.expectedGeneration??null)&&null===(e.expectedInstallationId??null)),"E_REVISION","Installed version or authorization changed")
const l=Ma(e.taskId,e.version),u=Fa(n,l),p=Fa(n,l,1),m=await t.get("scriptHeads",u),f=await t.get("scriptRevisions",p)
m||f?P(1===m?.revision&&m.contentHash===s.manifest.program.sourceHash&&!m.tombstoned&&f?.sourceUtf8===s.sourceUtf8&&f?.contentHash===s.manifest.program.sourceHash,"E_HASH","Installed script integrity differs"):(await t.put("scriptRevisions",{tag:"script-revision",namespace:n,scriptId:l,revision:1,parentRevision:0,contentHash:s.manifest.program.sourceHash,sourceUtf8:s.sourceUtf8,builtinIdentity:a},p),await t.put("scriptHeads",{tag:"script-head",namespace:n,scriptId:l,revision:1,contentHash:s.manifest.program.sourceHash,tombstoned:!1},u))
const g={tag:"task-installed-v1",namespace:n,taskId:e.taskId,version:e.version,scriptId:l,manifestHash:s.manifestHash,builtinIdentity:a,enabled:!0,installedAt:d?.installedAt??r.now(),authorization:Ya(s.manifest,d?.authorization)}
return await o(t,n,d),await t.put(za,g,c),{taskId:g.taskId,version:g.version,enabled:g.enabled,manifestHash:g.manifestHash}}))},setInstalledTaskEnabled:async function(e,t){Ba(e=structuredClone(e),["taskId","version","enabled","expectedGeneration","expectedInstallationId"]),P("boolean"==typeof e.enabled,"E_SCHEMA")
const a=await c()
return s(t,[za,"runs"],"readwrite",(async(t,n)=>{const r=qa(n,e.taskId),i=await t.get(za,r)
P("task-installed-v1"===i?.tag&&i.version===e.version&&e.expectedGeneration===(i.authorization?.generation??null)&&e.expectedInstallationId===(i.authorization?.installationId??null),"E_REVISION","Installed task authorization changed")
const s=$a(await t.get(za,ja(n,i.taskId,i.version)),n)
return await Wa(s.package),Ra(i.builtinIdentity,a),Ra(s.builtinIdentity,a),Ra(s.verification?.builtinIdentity,a),P("available"===s.stage&&s.package.manifestHash===i.manifestHash&&s.verification?.manifestHash===i.manifestHash,"E_PERMISSION","任务安装缺少固定版本验证"),Ka(s),await t.put(za,{...i,enabled:e.enabled,authorization:Ya(s.package.manifest,i.authorization)},r),await o(t,n,i),{taskId:i.taskId,version:i.version,enabled:e.enabled}}))},uninstallTask:async function(e,t){return Ba(e=structuredClone(e),["taskId","version","expectedGeneration","expectedInstallationId"]),s(t,[za,"runs"],"readwrite",(async(t,a)=>{const n=qa(a,e.taskId),r=await t.get(za,n)
return P("task-installed-v1"===r?.tag&&r.version===e.version&&e.expectedGeneration===(r.authorization?.generation??null)&&e.expectedInstallationId===(r.authorization?.installationId??null),"E_REVISION","Installed task authorization changed"),await t.delete(za,n),await o(t,a,r),{taskId:r.taskId,version:r.version,uninstalled:!0}}))},resolveInstalledTask:async function(e,t){const a=await c()
return Ba(e,["taskId"]),s(t,[za,"scriptRevisions"],"readonly",(async(t,n)=>{const r=await t.get(za,qa(n,e.taskId))
P("task-installed-v1"===r?.tag&&r.enabled,"E_PERMISSION","Task is disabled or not installed")
const i=$a(await t.get(za,ja(n,r.taskId,r.version)),n),{candidate:o}=await Za(t,n,{scriptId:r.scriptId,contentHash:i.package.manifest.program.sourceHash,origin:i.package.manifest.siteOrigins[0],builtinIdentity:a})
return{taskId:r.taskId,version:r.version,scriptId:r.scriptId,revision:1,installationId:r.authorization?.installationId??null,generation:r.authorization?.generation??null,contentHash:o.package.manifest.program.sourceHash,manifest:structuredClone(o.package.manifest),manifestHash:o.package.manifestHash}}))}}}({storage:e,api:t,assertHost:m,currentHost:f,clock:c,loadBuiltin:d})
return{...h,...E,...y,registerHost:async function(t,a){u(a),P("1.0.0"===t.claimedContractVersion&&"1486ff9c442807c0d447e542252830731faeede5f81cd685c5f146daecdba2a1"===t.claimedContractHash,"E_VERSION","Host contract differs"),P("string"==typeof t.hostInstanceId&&/^[A-Za-z0-9._:-]{1,128}$/.test(t.hostInstanceId),"E_SCHEMA","Invalid host instance")
const n=await e.transaction([Rn],"readwrite",(async e=>{const n=(await e.all(Rn)).find((e=>"host"===e.tag&&e.hostDocumentId===a.documentId&&e.browserSessionIncarnation===i))
if(n)return P(n.hostInstanceId===t.hostInstanceId&&n.active,"E_OWNER","Document cannot replace its host identity"),n.registrationId
const r=D()
return await e.put(Rn,{tag:"host",registrationId:r,hostInstanceId:t.hostInstanceId,hostDocumentId:a.documentId,hostUrl:a.url,hostTabId:a.tab?.id??null,...p(),browserSessionIncarnation:i,active:!0,revoked:!1,registeredAt:W(c)},"host:"+r),r}))
return F(T,"RegisterHostResponse",{hostDocumentId:a.documentId,registrationId:n,projection:await g(0,a)})},assertHost:m,pagePreviewAdmission:Tn({storage:e,assertHost:m,currentHost:f,session:i}),loseHost:async function(t,{documentGone:a=!1}={}){await e.transaction(["runs",Rn,Nn],"readwrite",(async e=>{const n=await e.get(Rn,"host:"+t)
if(n){n.active=!a,n.revoked=a,await e.put(Rn,n,"host:"+t)
for(const n of await e.all("runs"))if("controller-run"!==n.tag&&n.registrationId===t&&!z.has(n.state)&&"retiring"!==n.state){if(n.retirementId)continue
if(!a&&["stopping","paused_unknown"].includes(n.state))continue
n.state=a?n.cancelSeq?"stopped":"interrupted":"paused_unknown",n.terminalReason="RunHost connection lost",n.runRevision++,n.eventSeq++,n.identity&&(n.identity.runRevision=n.runRevision),a?await w(e,n,n.state):await e.put("runs",n,n.runId)}}})),await E.loseControllerHost(t,{documentGone:a})},recover:async function(){const t=await e.transaction([Rn],"readonly",(async e=>(await e.all(Rn)).filter((e=>"command"===e.tag&&"dispatched"===e.state))))
for(const e of t)await I(e,new C("E_EFFECT_UNKNOWN","Worker restart after dispatch"))
await e.transaction(["runs",Rn,Nn],"readwrite",(async e=>{const t=await e.get("runs","@slot")
for(const a of await e.all("runs"))a.runId&&"controller-run"!==a.tag&&z.has(a.state)&&!a.retirementId&&!a.tombstoned&&t?.currentRunId===a.runId?await w(e,a,a.state):!a.runId||"sdk-service"===a.tag||"controller-run"===a.tag||a.browserSessionIncarnation===i||z.has(a.state)||a.retirementId||["retiring","stopping","paused_unknown"].includes(a.state)||(a.state="paused_unknown",a.runRevision++,a.eventSeq++,a.terminalReason="cross-session-unverified",a.identity&&(a.identity.runRevision=a.runRevision),await e.put("runs",a,a.runId))})),await h.recoverSdk(),await E.recoverControllers()}}}({storage:u,api:e,session:l,entitlement:f,validatePlan:c?.validatePlan??p,clock:i,emitToHost:g}),w=function({storage:e,api:t,clock:a=Date.now,assertHost:n}){P(e?.transaction&&t?.downloads&&"function"==typeof n,"E_SCHEMA","Download service requires storage, Chrome API and host authentication")
const r=t.runtime?.id
P("string"==typeof r&&r.length>0,"E_TARGET","Extension identity is required")
const i=new Set,o=[]
let s=null
const c=()=>{const e=Number("function"==typeof a?a():a.now())
return P(Number.isSafeInteger(e)&&e>=0,"E_SCHEMA","Invalid clock"),e},d=(t,a)=>e.transaction(rt,t,a),l=(t,a)=>e.transaction(it,t,a),u=e=>{i.add(e),e.catch((e=>o.push(e))).finally((()=>i.delete(e)))},p=(e,a)=>new Promise(((n,r)=>{const i=e=>{const a=t.runtime?.lastError
a?r(Error(a.message)):n(e)}
try{const o=t.downloads[e](a,i)
o?.then&&o.then(n,r)}catch(o){r(o)}}))
async function m(e,t){const a=await e.get("runs",t)
return P(a&&!a.tombstoned&&!(await e.get(at,lt("tombstone",t))),"E_TOMBSTONE","Run is deleted or unavailable"),a}async function f(e){const t=await e.all(nt)
return P(t.every((e=>["attempt","receipt","candidate"].includes(e?.tag))),"E_SCHEMA","Unknown download record tag"),t}function g(e,t){P(e&&["registrationId","hostInstanceId","hostDocumentId","browserSessionIncarnation"].every((a=>"string"==typeof t[a]&&e[a]===t[a])),"E_OWNER","Host registration does not own this export")}async function I(e,t){const a=await n(e,t.registrationId)
return g(a,t),a}async function w(e,t,a){const n=await e.get(at,lt("host",t.registrationId))
return P("host"===n?.tag&&!0===n.active&&!1===n.revoked&&n.hostDocumentId===a?.documentId&&n.hostUrl===a?.url&&n.hostTabId===(a?.tab?.id??null),"E_OWNER","Registered host document changed before artifact transaction"),g(t,n),P("string"==typeof n.namespace&&n.namespace&&"string"==typeof n.principal&&n.principal&&n.namespace===t.namespace&&n.principal===t.principal,"E_OWNER","Unique authority must issue a stable namespace and principal"),n}async function h(e,t,a){const n=await m(e,t.runId)
P("controller-run"===n.tag&&n.runId===t.runId&&n.resultId===t.resultId&&n.namespace===a.namespace&&n.principal===a.principal,"E_OWNER","Controller result belongs to another namespace or principal")
const r=await e.get("results",t.resultId)
return P("controller-result"===r?.tag&&r.resultId===n.resultId&&r.runId===n.runId&&r.namespace===a.namespace&&r.principal===a.principal&&JSON.stringify(r.revision)===JSON.stringify(n.revision),"E_OWNER","Durable controller result binding differs"),P(!n.resultDeliveryRevoked,"E_PERMISSION","Result delivery permission was revoked"),P("completed"===n.state&&"completed"===r.state&&!0===r.outcome?.ok&&Object.hasOwn(r.outcome,"valueWire"),"E_OWNER","Only a durable successful controller result can produce an artifact"),{run:n,result:r}}async function E(e,t,a,n){if(g(t,a),ot(a)){const r=await w(e,t,n)
P(r.namespace===a.namespace&&r.principal===a.principal,"E_OWNER","Artifact namespace has been fenced")}}async function y(e,t){return{attempt:wt(t.attempt),receipt:wt((await e.get(nt,lt("receipt",t.attempt.attemptId)))?.receipt??null),job:wt(await e.get(tt,t.attempt.exportJobId)??null)}}async function b(e,t,a){F(_,"DownloadAttempt",t.attempt),Object.assign(t,{attemptId:t.attempt.attemptId,exportJobId:t.attempt.exportJobId,runId:t.attempt.runId,artifactId:t.attempt.artifactId,state:t.attempt.state,fullBlobUrl:t.attempt.blobUrl}),null===t.attempt.downloadId?delete t.boundDownloadId:t.boundDownloadId=t.attempt.downloadId,await e.put(nt,t,lt("attempt",t.attempt.attemptId))
const n=await e.get(tt,t.attempt.exportJobId)
if(!n)return
const r=[]
for(const i of n.activeAttemptIds){const t=await e.get(nt,lt("attempt",i))
P("attempt"===t?.tag,"E_SCHEMA","Missing active download attempt"),r.push(t.attempt)}if(await e.put(tt,function(e,t){return"abandoned"===e.state||0===t.length||(t.some((e=>["interrupted","conflict","abandoned"].includes(e.state)))?e.state="delivery_failed":t.every((e=>"complete"===e.state))?e.state="delivery_complete":t.some((e=>["mapping_unknown","deadline_unknown"].includes(e.state)))?e.state="delivery_unknown":t.every((e=>"prepared"===e.state))?e.state="ready":e.state="delivering",yt(e)),e}(n,r),n.exportJobId),r.every((e=>et(e,Date.parse(a))))){const t=await e.get(at,mt(n.exportJobId))
t&&!t.released&&await e.put(at,{...t,released:!0,releasedAt:Date.parse(a)},mt(n.exportJobId))}}async function v(e,a){ht(e,["artifactId"])
const{artifactId:n}=e,r=await d("readonly",(e=>e.get("artifacts",n)))
P("artifact"===r?.tag,"E_SCHEMA","Artifact is missing"),bt(r.artifact)
const i=await d("readonly",(e=>e.get(at,ut(r.artifact.exportJobId)))),o=await I(a,i),s=ot(r.artifact)?l:d
let c,u,p
const f=await s("readonly",(async e=>{await m(e,i.runId)
const t=await e.get(at,ut(i.exportJobId))
await E(e,o,t,a)
const s=await e.get("artifacts",n)
if(P("artifact"===s?.tag&&JSON.stringify(s.artifact)===JSON.stringify(r.artifact),"E_HASH","Artifact descriptor changed"),ot(r.artifact)){P(ot(t)&&r.artifact.runId===t.runId&&r.artifact.resultId===t.resultId&&r.artifact.namespace===t.namespace&&r.artifact.principal===t.principal,"E_OWNER","Artifact provenance differs from its export intent")
const a=await h(e,t,o)
p=a.run.target.allowedOrigin,c=(new TextEncoder).encode(JSON.stringify(a.result)),u=t.resultSha256}const d=new Uint8Array(r.artifact.bytes)
let l=0
for(const a of r.artifact.chunkKeys){const t=await e.get("artifacts",a)
P("artifact-chunk"===t?.tag&&t.parentArtifactId===n&&t.exportJobId===i.exportJobId&&t.bytes instanceof Uint8Array&&l+t.bytes.length<=d.length&&(!ot(r.artifact)||t.bytes.length<=N.maxRawFrameBytes),"E_SCHEMA","Artifact chunk missing or oversized"),d.set(t.bytes,l),l+=t.bytes.length}return P(l===d.length,"E_SCHEMA","Artifact byte count mismatch"),d}))
return P(await Xe(f)===r.artifact.sha256,"E_HASH","Artifact bytes changed"),c&&(P(await Xe(c)===u,"E_HASH","Controller result changed after artifact preparation"),await Ye(t,p),await l("readonly",(async e=>h(e,i,await w(e,o,a))))),{artifact:r.artifact,bytes:f}}function A(e,t){const a=Date.parse(e?.startTime)
return Number.isSafeInteger(e?.id)&&e.id>=0&&e.url===t.blobUrl&&e.byExtensionId===r&&Number.isFinite(a)&&a>=Date.parse(t.dispatchAt)-2e3&&a<=Date.parse(t.mappingDeadline)}function O(e){return{tag:"candidate",downloadId:e.id,fullBlobUrl:e.url,byExtensionId:e.byExtensionId,startTime:e.startTime,state:e.state,interruptReason:"string"==typeof e.error?e.error:null}}async function k(e,t={}){const{evidence:a="search",force:n=!1}=t
ht(e,["attemptId"])
const i=c(),o=await d("readonly",(t=>t.get(nt,lt("attempt",e.attemptId))))
P("attempt"===o?.tag,"E_SCHEMA","Download attempt is missing")
const s=o.attempt,l="string"==typeof t.documentId?t:null
let u,m
if(l){const e=await d("readonly",(e=>e.get(at,ut(s.exportJobId))))
ot(e)&&(m=e,u=await I(l,e))}const g=async e=>{u&&await E(e,u,await e.get(at,ut(m.exportJobId)),l)}
if(u&&await d("readonly",g),0===s.submissionCount||ft(s.state)&&!gt(s.state))return d("readonly",(async e=>(await g(e),y(e,o))))
const w=o.callbackDownloadId??s.downloadId,h=i>=Date.parse(s.downloadDeadline)&&"deadline_unknown"!==s.state,v=i>=Date.parse(s.mappingDeadline)&&"dispatched"===s.state,_=null===w&&!n&&!h&&!v&&i<(o.nextMappingSearchAt??0)
let k=[],T=!1
if(!_)try{k=await p("search",null===w?{url:s.blobUrl,startedAfter:It(Date.parse(s.dispatchAt)-2001),startedBefore:It(Date.parse(s.mappingDeadline)+1),limit:0}:{id:w}),T=Array.isArray(k),T||(k=[])}catch{}return d("readwrite",(async t=>{await g(t)
const n=await t.get(nt,lt("attempt",e.attemptId))
if(!n)return{attempt:null,receipt:null,job:null}
const o=n.attempt
if(ft(o.state)&&!gt(o.state))return y(t,n)
const s=await t.get("runs",o.runId),c=!s||s.tombstoned||!!(await t.get(at,lt("tombstone",o.runId)))
c&&!ft(o.state)&&(o.state="abandoned")
const d=i<Date.parse(o.dispatchAt)||null!==n.lastObservedAt&&i<Date.parse(n.lastObservedAt),l=new Map,u=await f(t)
for(const e of u)"candidate"===e.tag&&A({id:e.downloadId,url:e.fullBlobUrl,byExtensionId:e.byExtensionId,startTime:e.startTime},o)&&l.set(e.downloadId,{id:e.downloadId})
const p=new Map
if(!d)for(const e of k)A(e,o)&&(l.set(e.id,e),p.set(e.id,e),await t.put(nt,O(e),lt("candidate",e.id)))
o.candidateDownloadIds=[...l.keys()].sort(((e,t)=>e-t))
const m=n.callbackDownloadId??o.downloadId,I=l.size>1||u.some((e=>"attempt"===e.tag&&e.attempt.attemptId!==o.attemptId&&null!==e.attempt.downloadId&&l.has(e.attempt.downloadId)))||null!==m&&[...l.keys()].some((e=>e!==m))||null!==n.callbackDownloadId&&null!==o.downloadId&&n.callbackDownloadId!==o.downloadId||k.some((e=>e?.id===m&&!A(e,o)))
I&&!gt(o.state)&&(o.state="conflict")
let w=null
if(!d&&!I&&1===l.size){const e=[...l.keys()][0]
w=p.get(e)??null,!w||gt(o.state)||c||(o.downloadId=e,o.mappedAt??=It(i))}if(w&&["in_progress","complete","interrupted"].includes(w.state)){const e={attemptId:o.attemptId,downloadId:w.id,observedState:w.state,observedAt:It(i),evidence:a,byExtensionId:r,late:!!(o.timedOutAt||"mapping_unknown"===o.state||i>=Date.parse(o.downloadDeadline)),browserDownloadComplete:"complete"===w.state,diskHashVerified:!1,interruptReason:"interrupted"===w.state&&"string"==typeof w.error?w.error:null}
F(S,"Receipt",e)
const n=await t.get(nt,lt("receipt",o.attemptId))
n&&"in_progress"!==n.receipt.observedState||await t.put(nt,{tag:"receipt",receipt:e},lt("receipt",o.attemptId)),gt(o.state)||c||(o.state=w.state)}return ft(o.state)||(i>=Date.parse(o.downloadDeadline)?(o.state="deadline_unknown",o.timedOutAt??=It(i)):null===o.downloadId&&i>=Date.parse(o.mappingDeadline)&&(o.state="mapping_unknown",o.timedOutAt??=It(i))),d||(n.lastObservedAt=It(i)),_||(n.mappingSearchCount++,n.nextMappingSearchAt=i+(i>=Date.parse(o.mappingDeadline)?6e4:1e3)),await b(t,n,It(i)),y(t,n)}))}async function T(e){if(!Number.isSafeInteger(e?.id)||e.id<0||e.byExtensionId!==r||"string"!=typeof e.url||!Number.isFinite(Date.parse(e.startTime)))return
const t=await d("readwrite",(async t=>{const a=(await f(t)).filter((t=>"attempt"===t.tag&&1===t.attempt.submissionCount&&A(e,t.attempt)))
return a.length&&await t.put(nt,O(e),lt("candidate",e.id)),a.map((e=>e.attempt.attemptId))}))
for(const a of t)await k({attemptId:a},{force:!0})}async function R(e){if(!Number.isSafeInteger(e?.id)||e.id<0)return
const t=await d("readonly",(async t=>(await f(t)).filter((t=>"attempt"===t.tag&&(t.attempt.downloadId===e.id||t.callbackDownloadId===e.id||t.attempt.candidateDownloadIds.includes(e.id)))).map((e=>e.attempt.attemptId))))
for(const a of t)await k({attemptId:a},{evidence:"onChanged+search",force:!0})}async function C(){if("function"!=typeof t.runtime.getContexts)return
const e=await d("readonly",(async e=>(await e.all(at)).filter((e=>ot(e)&&"export-intent"===e.tag))))
for(const a of e){let e
try{e=await t.runtime.getContexts({documentIds:[a.hostDocumentId]})}catch{continue}e.length||await d("readwrite",(async e=>{const t=await e.get(at,ut(a.exportJobId))
if(!t||t.hostDocumentId!==a.hostDocumentId)return
const n=await e.get(tt,a.exportJobId)
if(!n)return
const r=(await f(e)).filter((e=>"attempt"===e.tag&&e.attempt.exportJobId===n.exportJobId)),i=It(c())
r.every((e=>0===e.attempt.submissionCount))&&await U(e,n,i)
for(const a of r){const t=await e.get(nt,lt("attempt",a.attempt.attemptId))
et(t.attempt,c())&&(t.attempt.resourceReleasedAt??=i,await b(e,t,i))}await e.put(at,{...await e.get(at,ut(n.exportJobId)),hostDocumentGoneAt:i},ut(n.exportJobId))}))}}async function U(e,t,a,n){t.state="abandoned",await e.put(tt,t,t.exportJobId)
const r=await e.get(at,ut(t.exportJobId))
r&&await e.put(at,{...r,frozen:!0},ut(t.exportJobId))
const i=ot(t)?(await f(e)).filter((e=>"attempt"===e.tag&&e.attempt.exportJobId===t.exportJobId)).map((e=>e.attempt.attemptId)):t.activeAttemptIds
for(const s of i){const t=await e.get(nt,lt("attempt",s))
t&&!ft(t.attempt.state)&&(t.attempt.state="abandoned",await b(e,t,a))}const o=await e.get(at,mt(t.exportJobId))
o&&await e.put(at,{...o,released:!0,releasedAt:Date.parse(a)},mt(t.exportJobId))}return Object.freeze({prepareArtifact:async function(e,a){ht(e,"data"===e?.format?["requestId","runId","resultId","filename","format","data"]:["requestId","runId","resultId","filename","format"])
for(const t of["requestId","runId","resultId"])dt(e[t])
Et(e.filename),P(["typed-json","data"].includes(e.format),"E_SCHEMA","Unknown artifact format"),e=wt(e)
const r=await n(a),i=await l("readonly",(async t=>{const n=await w(t,r,a)
return h(t,e,n)}))
await Ye(t,i.run.target.allowedOrigin),oe(i.result.outcome.valueWire)
const o=JSON.stringify(i.result)
let s,d
if("data"===e.format)ht(e.data,["mime","blocks"]),P(st.includes(e.data.mime)&&Array.isArray(e.data.blocks)&&e.data.blocks.length>0&&e.data.blocks.length<=64,"E_SCHEMA","Explicit artifact data requires an approved MIME and 1..64 blocks"),s=e.data.blocks.map((e=>function(e,{maxBytes:t=N.maxRawFrameBytes}={}){let a;("string"!=typeof e||e.length>4*Math.ceil(t/3)||!/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(e))&&se("base64","Invalid base64")
try{a=atob(e)}catch{se("base64","Invalid base64")}return(a.length>t||btoa(a)!==e)&&se("base64","Noncanonical or oversized base64"),Uint8Array.from(a,(e=>e.charCodeAt(0)))}(e))),d=e.data.mime
else{const t=(new TextEncoder).encode(JSON.stringify({protocol:ee,runId:e.runId,resultId:e.resultId,valueWire:i.result.outcome.valueWire})+"\n")
P(t.byteLength<=N.maxArtifactBytes,"E_LIMIT","Artifact exceeds 8 MiB"),s=[]
for(let e=0;e<t.byteLength;e+=N.maxRawFrameBytes)s.push(t.slice(e,e+N.maxRawFrameBytes))
d="application/json"}const u=s.reduce(((e,t)=>e+t.byteLength),0)
P(u<=N.maxArtifactBytes&&s.length<=64,"E_LIMIT","Artifact exceeds 8 MiB/64 blocks")
const p=H(e),m=new Uint8Array(u)
let f=0
for(const t of s)m.set(t,f),f+=t.byteLength
const g=D(),I=D(),y=It(c()),b=await Xe(m),v=await Xe((new TextEncoder).encode(o)),_=bt({kind:"controller-artifact",artifactId:I,exportJobId:g,runId:e.runId,resultId:e.resultId,namespace:r.namespace,principal:r.principal,format:e.format,mime:d,bytes:u,byteCount:u,sha256:b,storageEncoding:"Uint8Array-chunks",chunkKeys:s.map(((e,t)=>lt("chunk",`${I}:${t}`))),filename:e.filename}),S=yt({kind:"controller-artifact",exportJobId:g,runId:e.runId,resultId:e.resultId,namespace:r.namespace,principal:r.principal,format:e.format,artifactIds:[I],activeAttemptIds:[],state:"preparing"}),A=lt("export-request",H(["artifact",r.registrationId,e.requestId]))
return l("readwrite",(async t=>{const n=await w(t,r,a),i=await h(t,e,n)
P(JSON.stringify(i.result)===o,"E_REQUEST_CONFLICT","Controller result changed before artifact commit")
const c=await t.get(at,A)
if(c){P(c.requestCanonical===p,"E_REQUEST_CONFLICT","Artifact request ID has different content")
const e=await t.get(at,ut(c.exportJobId))
await E(t,r,e,a)
const n=await t.get("artifacts",c.artifactId)
return P("artifact"===n?.tag,"E_SCHEMA","Prepared artifact is missing"),bt(n.artifact),{exportJobId:e.exportJobId,artifactId:n.artifact.artifactId,artifact:wt(n.artifact),job:wt(await t.get(tt,e.exportJobId))}}const d=await t.all("runs"),l=await t.all("artifacts"),m=await t.all(at)
P(l.filter((e=>"artifact"===e.tag)).reduce(((e,t)=>e+(t.artifact.byteCount??t.artifact.bytes)),0)+d.reduce(((e,t)=>e+(t.storedBytes??0)),0)+m.filter((e=>"migration-backup"===e.tag)).reduce(((e,t)=>e+t.utf8Bytes),0)+u<=N.profileStoredBytes&&l.filter((t=>"artifact"===t.tag&&t.artifact.runId===e.runId)).reduce(((e,t)=>e+t.artifact.bytes),0)+u<=N.maxStoredBytes,"E_QUOTA","Artifact exceeds shared storage budget")
const f={tag:"export-intent",kind:"controller-artifact",exportJobId:g,runId:e.runId,resultId:e.resultId,resultSha256:v,namespace:n.namespace,principal:n.principal,registrationId:n.registrationId,hostInstanceId:n.hostInstanceId,hostDocumentId:n.hostDocumentId,browserSessionIncarnation:n.browserSessionIncarnation,ownerEpochAtCreation:i.run.ownerEpoch,preparedAt:y,frozen:!1,readerPinId:pt(g)}
await t.put(at,f,ut(g)),await t.put(at,{tag:"reader-pin",readerPinId:pt(g),runId:e.runId,resultId:e.resultId,exportJobId:g,released:!1,createdAt:Date.parse(y)},mt(g)),await t.put("artifacts",{tag:"artifact",artifact:_},I)
for(const[a,r]of s.entries())await t.put("artifacts",{tag:"artifact-chunk",parentArtifactId:I,exportJobId:g,runId:e.runId,bytes:r},_.chunkKeys[a])
return await t.put(tt,S,g),await t.put(at,{tag:"export-request",requestCanonical:p,exportJobId:g,artifactId:I},A),{exportJobId:g,artifactId:I,artifact:wt(_),job:wt(S)}}))},prepareAttempt:async function(e,t){ht(e,["requestId","artifactId","blobUrl"]),dt(e.requestId),dt(e.artifactId),P("string"==typeof e.blobUrl&&e.blobUrl.startsWith(`blob:chrome-extension://${r}/`)&&e.blobUrl.length>`blob:chrome-extension://${r}/`.length&&!/[\u0000-\u0020\u007f]/.test(e.blobUrl),"E_SCHEMA","RunHost must provide a fresh same-extension Blob URL"),e=wt(e)
const a=await v({artifactId:e.artifactId},t)
P(ot(a.artifact),"E_SCHEMA","Generic attempt requires a generic artifact")
const n=await d("readonly",(e=>e.get(at,ut(a.artifact.exportJobId)))),i=await I(t,n),o=H(e),s=lt("export-request",H(["attempt",i.registrationId,e.requestId])),u=c()
return l("readwrite",(async r=>{const c=await r.get(at,ut(n.exportJobId))
await E(r,i,c,t)
const d=await h(r,c,i)
P(await Xe((new TextEncoder).encode(JSON.stringify(d.result)))===c.resultSha256,"E_HASH","Controller result changed after artifact preparation")
const l=await r.get("artifacts",e.artifactId)
P("artifact"===l?.tag&&JSON.stringify(l.artifact)===JSON.stringify(a.artifact),"E_HASH","Artifact changed before attempt commit")
let p=0
for(const t of a.artifact.chunkKeys){const i=await r.get("artifacts",t)
P("artifact-chunk"===i?.tag&&i.parentArtifactId===e.artifactId&&i.exportJobId===n.exportJobId&&i.bytes instanceof Uint8Array&&i.bytes.length<=N.maxRawFrameBytes&&p+i.bytes.length<=a.bytes.length&&i.bytes.every(((e,t)=>e===a.bytes[p+t])),"E_HASH","Artifact bytes changed before attempt commit"),p+=i.bytes.length}P(p===a.bytes.length,"E_HASH","Artifact byte count changed")
const m=await r.get(at,s)
if(m){P(m.requestCanonical===o,"E_REQUEST_CONFLICT","Attempt request ID has different content")
const t=await r.get(nt,lt("attempt",m.attemptId))
return P("attempt"===t?.tag&&t.attempt.artifactId===e.artifactId,"E_SCHEMA","Prepared attempt is missing"),wt(t.attempt)}P(!c.frozen&&u>=Date.parse(c.preparedAt),"E_OWNER","Artifact is abandoned or its clock is fenced")
const g=yt(await r.get(tt,n.exportJobId))
P("abandoned"!==g.state&&g.artifactIds[0]===e.artifactId,"E_OWNER","Artifact job is unavailable"),P(!(await f(r)).some((t=>"attempt"===t.tag&&t.attempt.blobUrl===e.blobUrl)),"E_SCHEMA","Each attempt requires a fresh Blob URL")
for(const e of g.activeAttemptIds){const t=await r.get(nt,lt("attempt",e))
P("attempt"===t?.tag&&et(t.attempt,u),"E_OWNER","Previous download still needs its artifact")}const I={attemptId:D(),exportJobId:n.exportJobId,runId:n.runId,artifactId:e.artifactId,artifactHash:a.artifact.sha256,artifactBytes:a.artifact.bytes,rowCount:0,hostInstanceId:i.hostInstanceId,hostDocumentId:i.hostDocumentId,ownerEpochAtCreation:c.ownerEpochAtCreation,blobUrl:e.blobUrl,filename:a.artifact.filename,preparedAt:It(u),dispatchAt:null,mappingDeadline:null,downloadDeadline:null,state:"prepared",downloadId:null,resourceReleasedAt:null,timedOutAt:null,candidateDownloadIds:[],mappedAt:null,submissionCount:0}
F(_,"DownloadAttempt",I),g.activeAttemptIds=[I.attemptId],g.state="ready",await r.put(tt,yt(g),g.exportJobId),await r.put(nt,{tag:"attempt",attempt:I,callbackDownloadId:null,lastObservedAt:null,attemptId:I.attemptId,exportJobId:I.exportJobId,runId:I.runId,artifactId:I.artifactId,state:I.state,fullBlobUrl:I.blobUrl,mappingSearchCount:0,nextMappingSearchAt:null},lt("attempt",I.attemptId))
const w=await r.get(at,mt(g.exportJobId))
return P("reader-pin"===w?.tag,"E_SCHEMA","Artifact reader pin is missing"),await r.put(at,{...w,released:!1,releasedAt:null},mt(g.exportJobId)),await r.put(at,{tag:"export-request",requestCanonical:o,exportJobId:g.exportJobId,artifactId:e.artifactId,attemptId:I.attemptId},s),wt(I)}))},retirePreparedArtifact:async function(e,t){ht(e,["artifactId"]),dt(e.artifactId)
const a=await d("readonly",(t=>t.get("artifacts",e.artifactId)))
P("artifact"===a?.tag&&ot(a.artifact),"E_SCHEMA")
const n=await d("readonly",(e=>e.get(at,ut(a.artifact.exportJobId)))),r=await I(t,n)
return l("readwrite",(async e=>{await E(e,r,await e.get(at,ut(n.exportJobId)),t)
const a=await e.get(tt,n.exportJobId),i=(await f(e)).filter((e=>"attempt"===e.tag&&e.attempt.exportJobId===a.exportJobId))
return P(i.every((e=>0===e.attempt.submissionCount)),"E_EFFECT_UNKNOWN","Submitted attempts require native reconciliation"),await U(e,a,It(c())),{attemptIds:i.map((e=>e.attempt.attemptId))}}))},readArtifact:v,dispatchDownload:async function(e,a){ht(e,["attemptId"])
const n=await d("readonly",(t=>t.get(nt,lt("attempt",e.attemptId))))
P("attempt"===n?.tag,"E_SCHEMA","Download attempt is missing")
const r=await d("readonly",(e=>e.get(at,ut(n.attempt.exportJobId)))),i=await I(a,r)
if(ot(r)){const e=await l("readonly",(e=>h(e,r,i)))
await Ye(t,e.run.target.allowedOrigin)}const o=c(),s=await d("readwrite",(async t=>{const n=await t.get(nt,lt("attempt",e.attemptId)),r=await t.get(at,ut(n.attempt.exportJobId))
await E(t,i,r,a)
const s=await m(t,n.attempt.runId)
return ot(r)&&P(!s.resultDeliveryRevoked,"E_PERMISSION"),1===n.attempt.submissionCount?null:(P(!r.frozen&&"prepared"===n.attempt.state,"E_OWNER","Attempt cannot be submitted"),P(o>=Date.parse(n.attempt.preparedAt),"E_SEMANTIC","Clock moved backwards"),Object.assign(n.attempt,{state:"dispatched",submissionCount:1,dispatchAt:It(o),mappingDeadline:It(o+N.mappingWindowMs),downloadDeadline:It(o+N.downloadDeadlineMs)}),await b(t,n,It(o)),wt(n.attempt))}))
return s&&u(async function(e){let t
try{t=await p("download",{url:e.blobUrl,filename:e.filename,conflictAction:"uniquify",saveAs:!1})}catch{return}!Number.isSafeInteger(t)||t<0||(await d("readwrite",(async a=>{const n=await a.get(nt,lt("attempt",e.attemptId))
n&&(null!==n.callbackDownloadId&&n.callbackDownloadId!==t&&(n.attempt.state=gt(n.attempt.state)?n.attempt.state:"conflict"),n.callbackDownloadId=t,await b(a,n,It(c())))})),await k({attemptId:e.attemptId}))}(s)),{accepted:!0,state:"dispatched"}},reconcileDownload:k,reconcilePending:async function(){const e=c(),t=await d("readonly",(async t=>(await f(t)).filter((t=>"attempt"===t.tag&&1===t.attempt.submissionCount&&(!["complete","interrupted","abandoned","conflict","deadline_unknown"].includes(t.attempt.state)||"conflict"===t.attempt.state&&e>=Date.parse(t.attempt.downloadDeadline)&&Date.parse(t.lastObservedAt??t.attempt.dispatchAt)<Date.parse(t.attempt.downloadDeadline)))).map((e=>e.attempt.attemptId)))),a=[]
for(const n of t)a.push(await k({attemptId:n}))
return await C(),a},reconcileHostResources:C,recordResourceRelease:async function(e,t){ht(e,["attemptId"])
const a=await d("readonly",(t=>t.get(nt,lt("attempt",e.attemptId))))
P("attempt"===a?.tag,"E_SCHEMA","Download attempt is missing")
const n=await d("readonly",(e=>e.get(at,ut(a.attempt.exportJobId)))),r=await I(t,n),i=c()
return d("readwrite",(async a=>{const n=await a.get(nt,lt("attempt",e.attemptId))
return await E(a,r,await a.get(at,ut(n.attempt.exportJobId)),t),P(i>=Date.parse(n.lastObservedAt??n.attempt.preparedAt),"E_SEMANTIC","Clock moved backwards"),P(et(n.attempt,i),"E_OWNER","Blob is still needed by an active download"),n.attempt.resourceReleasedAt??=It(i),await b(a,n,It(i)),wt(n.attempt)}))},handleCreated:T,handleChanged:R,attach:function(){if(s)return s
const e=e=>{u(T(e))},a=e=>{u(R(e))}
return t.downloads.onCreated.addListener(e),t.downloads.onChanged.addListener(a),s=()=>{t.downloads.onCreated.removeListener(e),t.downloads.onChanged.removeListener(a),s=null},s},drain:async function(){for(;i.size;)await Promise.allSettled([...i])
if(o.length)throw o.shift()}})}({storage:u,api:e,clock:i,assertHost:I.assertHost}),h=function({authority:e,storage:t,api:a,fetchImpl:n=globalThis.fetch,clock:r={now:()=>Date.now()},logger:i=console,setTimer:o=setTimeout,clearTimer:s=clearTimeout}){const c=new Map,d=(e,t)=>t.authorize(e),l=Pt({fetchImpl:n,authorize:d,clock:r,networkInfoEnabled:!1}),u=function({api:e=globalThis.chrome,authorize:t,iconUrl:a,onLifecycle:n=()=>{}}={}){const r=new Map
let i=!1
const o=e=>{try{n(e)}catch{}},s=(e,t)=>{const a=r.get(e)
a&&(r.delete(e),o({kind:"closed",notificationId:e,byUser:t,requestId:a.requestId}))},c=t=>{const a=r.get(t)
a&&(o({kind:"clicked",notificationId:t,requestId:a.requestId}),r.delete(t),e.notifications.clear?.(t,(()=>{e.runtime})))}
return e?.notifications?.onClosed?.addListener(s),e?.notifications?.onClicked?.addListener(c),Object.freeze({async create({title:n,content:s},c={}){if(i)throw Re("E_CANCELLED")
if(!t)throw Re("E_PERMISSION","Notification driver requires broker authorization")
if(await t({capability:"notifications",phase:"pre"},c),c.assertDispatch?.(),!e?.notifications?.create||!a)throw Re("E_RESOURCE_UNAVAILABLE","Notification driver or fixed icon missing",{stage:"lookup"})
if("string"!=typeof n||"string"!=typeof s)throw Re("E_SCHEMA")
const d=await new Promise(((t,d)=>{try{e.notifications.create("",{type:"basic",title:n,message:s,iconUrl:a},(a=>{const n=e.runtime?.lastError
n?d(Re("E_NOTIFICATION",n.message)):"string"==typeof a&&a?(i||r.set(a,c),o({kind:"created",notificationId:a,requestId:c.requestId,delivery:"unobserved"}),t(a)):d(Re("E_NOTIFICATION","Missing native notification receipt"))}))}catch(l){d(Re("E_NOTIFICATION",l.message))}}))
await(c.recordNativeReceipt?.({notificationId:d})),await(c.recordEffect?.(void 0)),await t({capability:"notifications",phase:"post"},c)},dispose(){i||(i=!0,e?.notifications?.onClosed?.removeListener(s),e?.notifications?.onClicked?.removeListener(c),r.clear())},diagnostics:()=>({active:r.size,disposed:i})})}({api:a,authorize:d,iconUrl:a.runtime.getURL("icons/notification.png")}),p=function({api:e,clock:t,fetchImpl:a=globalThis.fetch,logger:n=console}={}){function r(){const t=e?.runtime?.getURL("/")
if("string"!=typeof t||!/^chrome-extension:\/\/[a-p]{32}\/$/.test(t))throw Re(Pn,"Extension runtime root is unavailable")
return t}async function i(t,n){if("function"!=typeof a)throw Re(Pn,"Packaged resource reader is unavailable")
let r
try{r=await a(e.runtime.getURL(t),{redirect:"error",credentials:"omit"})}catch{throw Re(Pn,"Packaged resource could not be read")}if(!r.ok)throw Re(Pn,"Packaged resource is missing")
const i=Number(r.headers?.get("content-length"))
if(Number.isFinite(i)&&i>n)throw Re(Pn,"Packaged resource exceeds its size limit")
const o=[]
let s=0
if(r.body?.getReader){const e=r.body.getReader()
try{for(;;){const{done:t,value:a}=await e.read()
if(t)break
if(s+=a.byteLength,s>n)throw await e.cancel(),Re(Pn,"Packaged resource exceeds its size limit")
o.push(a)}}finally{e.releaseLock()}}else{const e=new Uint8Array(await r.arrayBuffer())
if(s=e.byteLength,s>n)throw Re(Pn,"Packaged resource exceeds its size limit")
o.push(e)}const c=new Uint8Array(s)
let d=0
for(const e of o)c.set(e,d),d+=e.byteLength
return c}return Object.freeze({async execute(e,a,o){const s="log"===e?"service.log":"getTime"===e?"service.time":"resources.packaged",c="requestResource"===e?function(e){const t=r()
if("string"!=typeof e||!e||e.length>1024||/[\\%?#\s]/.test(e)||e.includes(".."))throw Re("E_SCHEMA","Invalid packaged resource URL")
const a=e.startsWith(t)?e.slice(t.length):e
if(a.startsWith("/")||a.includes(":"))throw Re("E_SCHEMA","Only this extension package is readable")
if(Cn.includes(a))return a
if(Object.hasOwn(Un,a))return Un[a]
throw Re(Pn,"Resource is outside the fixed package list")}(a.url):void 0
let d
if(await o.authorize({capability:s,phase:"pre"}),o.assertDispatch(),"log"===e){if("function"!=typeof n?.info)throw Re(Pn,"Trusted log sink is unavailable")
n.info("opendesk.sdk.log",Object.freeze({messageBytes:(new TextEncoder).encode(a.message).byteLength,dataItems:a.data?.length??0})),d=void 0}else if("getTime"===e){if(d=t?.now(),!Number.isFinite(d))throw Re(Pn,"Trusted clock returned a non-finite value")}else if("bexUrl"===e)d={url:r()}
else{if("requestResource"!==e)throw Re("E_SERVICE_UNSUPPORTED")
d=await async function(e){let t
try{t=JSON.parse(new TextDecoder("utf-8",{fatal:!0}).decode(await i("framework/sdk-resources.json",8192)))}catch(o){if(o.code)throw o
throw Re(Pn,"Invalid packaged resource manifest")}if(!Dn(t,["schemaVersion","resources"])||1!==t.schemaVersion||!Array.isArray(t.resources)||t.resources.length!==Cn.length||!t.resources.every(((e,t)=>Dn(e,["path","bytes","sha256"])&&e.path===Cn[t]&&Number.isSafeInteger(e.bytes)&&e.bytes>0&&e.bytes<=Te.responseBytes&&/^[a-f0-9]{64}$/.test(e.sha256))))throw Re(Pn,"Resource manifest differs from the fixed contract")
const a=t.resources.find((t=>t.path===e)),n=await i(e,a.bytes),r=[...new Uint8Array(await crypto.subtle.digest("SHA-256",n))].map((e=>e.toString(16).padStart(2,"0"))).join("")
if(n.byteLength!==a.bytes||r!==a.sha256)throw Re(Pn,"Packaged resource integrity mismatch")
try{return{success:!0,data:new TextDecoder("utf-8",{fatal:!0}).decode(n)}}catch{throw Re(Pn,"Packaged resource is not UTF-8")}}(c)}return await o.recordEffect(d),await o.authorize({capability:s,phase:"post"}),o.assertDispatch(),d}})}({api:a,clock:r,fetchImpl:n,logger:i}),m=function({network:e,notifications:t,storage:a,device:n,background:r}={}){return Object.freeze({async execute(i,o,s){let c
o=ze(i,o)
const d={AXIOS_GET:"GET",AXIOS_POST:"POST",AXIOS_PUT:"PUT",AXIOS_DELETE:"DELETE"}[i]
if(Object.hasOwn(Fe,i)){if(!r)throw Re("E_RESOURCE_UNAVAILABLE")
c=await r.execute(i,o,s)}else if(d){if(!e)throw Re("E_RESOURCE_UNAVAILABLE")
c=await e.request({method:d,...o},s)}else if(i.startsWith("APPSTORAGE_")||i.startsWith("APPLOCAL_")||i.startsWith("CHROME_LOCAL_")){if(!a?.executeSdk)throw Re("E_RESOURCE_UNAVAILABLE","Shared SDK storage adapter missing")
c=await a.executeSdk(i,o,s)}else if("CREATE_NOTIFY"===i){if(!t)throw Re("E_RESOURCE_UNAVAILABLE")
c=await t.create(o,s)}else if("SERVER_CHECK"===i){if(!e)throw Re("E_RESOURCE_UNAVAILABLE")
c=await e.checkServer(o,s)}else if("NETWORK_INFO_GET"===i){if(!e)throw Re("E_RESOURCE_UNAVAILABLE")
c=await e.getIpInfo(o,s)}else if("DEVICE_GET_APP_ID"===i){if(!n?.getAppId)throw Re("E_RESOURCE_UNAVAILABLE","Shared atomic device namespace adapter missing")
c=await n.getAppId(s)}return{ok:!0,value:c}}})}({network:l,notifications:u,storage:t,background:p,device:{getAppId:e=>t.getAppId(e)}})
function f(){P("function"==typeof t.executeSdk&&"function"==typeof t.getAppId,"E_RESOURCE_UNAVAILABLE","Shared SDK storage is unavailable")}async function g(t,a){const{context:n}=t
try{const e=await m.execute(a.method,a.args,n)
return P(!0===e?.ok&&Object.hasOwn(e,"value"),"E_SCHEMA","Invalid driver result"),await n.recordEffect(e.value)}catch(r){if(await e.failSdk(n,r),"E_HTTP"===r.code&&n.httpErrorReceipt)return n.httpErrorReceipt
throw r}}return Object.freeze({hello:async(t,a)=>(f(),e.helloSdk(t,a)),request:async function(t,a){f(),Ce(t,["requestId","method","argsWire","deadlineAt"],["requestId","method","argsWire","deadlineAt"])
const n=Ve({requestId:t.requestId,method:t.method,args:oe(t.argsWire),deadlineAt:t.deadlineAt}),i=await e.admitSdk(n,a),{operation:d,context:l}=i
let u,p,m=i.receipt
if(!m){if(P("effect_unknown"!==d.state&&"dispatched"!==d.state||c.has(d.opKey),"E_EFFECT_UNKNOWN","Dispatched SDK effect has no durable result; it cannot be repeated"),"failed"===d.state)throw new C(d.deliveryError?.code||"E_EFFECT_UNKNOWN",d.deliveryError?.message||"SDK request failed")
let t=c.get(d.opKey)
if(!t){let a
P(c.size<100,"E_LIMIT","SDK short service concurrency limit")
const u=Math.max(0,l.deadlineAt-r.now())
t=Promise.race([g(i,n),new Promise(((e,t)=>{a=o((()=>t(new C("E_DEADLINE","SDK hard service deadline exceeded"))),u)}))]).catch((async t=>{throw await e.failSdk(l,t),t})).finally((()=>s(a))),c.set(d.opKey,t),t.finally((()=>{c.get(d.opKey)===t&&c.delete(d.opKey)})).catch((()=>{}))}m=await t}try{if(await l.authorize(),m.httpErrorWire){const e=oe(m.httpErrorWire)
p=Object.assign(new C("E_HTTP","HTTP "+e.status),{status:e.status,response:e})}else u={valueWire:ie((I=oe(m.valueWire),{PageBrigeCode:0,message:"",data:I}))}
await e.settleSdkDelivery(l),l.assertDispatch()}catch(w){throw await e.settleSdkDelivery(l,w),w}var I
if(p)throw p
return u},dispose:()=>u.dispose(),diagnostics:()=>({pending:c.size,notifications:u.diagnostics()})})}({authority:I,storage:u,api:e,clock:i}),E=Gr({api:e,storage:u,assertHost:I.assertHost,clock:i}),y=function({api:e,storage:t,assertHost:a,dependencies:r,admission:i,managedFactory:o=globalThis.__opendeskNativeManagedUI,fetchImpl:s=globalThis.fetch,loadBuiltin:c=Oa}){P(e&&t&&"function"==typeof a&&"function"==typeof i?.reserve&&"function"==typeof i.release,"E_SCHEMA","Trusted preview dependencies missing")
const d=r||Gr({api:e,storage:t,assertHost:a,fetchImpl:s}),l=function({api:e}){let t=Promise.resolve()
const a=e=>{const a=t.then(e,e)
return t=a.catch((()=>{})),a}
async function n(){P("function"==typeof e.storage?.session?.get&&"function"==typeof e.storage.session.set,"E_WORLD_ISOLATION","缺少浏览器会话级执行世界账本")
const t=(await e.storage.session.get(si))[si]??[]
return P(Array.isArray(t)&&t.every((e=>Number.isSafeInteger(e.tabId)&&"string"==typeof e.documentId&&"string"==typeof e.worldId&&e.worldId.startsWith(ci))),"E_WORLD_ISOLATION","执行世界账本损坏，请关闭当前标签页后重试"),t}async function r(e,t,a,n,r){const i=await e.execute({target:{tabId:t.tabId,documentIds:[t.documentId]},world:"USER_SCRIPT",...r?{worldId:r}:{},js:[{code:a}]})
P(Array.isArray(i)&&1===i.length&&0===i[0].frameId&&i[0].documentId===t.documentId&&void 0===i[0].error&&i[0].result===n,"E_WORLD_ISOLATION","浏览器未确认独立脚本世界；请刷新网页后重试，未注入依赖或用户代码")}return Object.freeze({allocate:async function(t,i){return a((async()=>{P("function"==typeof t.configureWorld&&"function"==typeof t.getWorldConfigurations&&"function"==typeof t.resetWorldConfiguration,"E_WORLD_ISOLATION","浏览器缺少独立世界配置与对账能力")
const a=await t.getWorldConfigurations()
P(Array.isArray(a),"E_WORLD_ISOLATION","无法读取浏览器执行世界配置")
for(const e of a)"string"==typeof e.worldId&&e.worldId.startsWith(ci)&&await t.resetWorldConfiguration(e.worldId)
const o=await async function(t){const a=await n()
P(a.filter((e=>e.documentId===t.documentId)).length<6,"E_PREVIEW_WORLD_LIMIT","当前文档已调试 6 次；请刷新网页后继续。刷新会清除本页旧脚本的运行状态。"),P(a.length<4096,"E_PREVIEW_WORLD_LIMIT","本次浏览器会话的调试世界已达上限，请关闭不用的标签页")
const r=ci+di()
return a.push({tabId:t.tabId,documentId:t.documentId,worldId:r}),await e.storage.session.set({[si]:a}),r}(i),s="__opendesk_probe_"+di(),c=di(),d=di()
return await t.configureWorld({worldId:o,csp:mr,messaging:!1}),await r(t,i,"const "+s+" = "+JSON.stringify(c)+";\n"+JSON.stringify(c),c),await r(t,i,s,c),await r(t,i,"typeof "+s+" === 'undefined' ? "+JSON.stringify(d)+" : "+JSON.stringify(c),d,o),o}))},cleanup:async function({tabId:t,documentId:r,removed:i=!1}){return a((async()=>{const a=await n()
let o
try{o=e.userScripts}catch{}if(i&&await e.storage.session.set({[si]:a.filter((e=>e.tabId!==t))}),"function"==typeof o?.resetWorldConfiguration)for(const e of a.filter((e=>e.tabId===t&&(i||e.documentId!==r))))try{await o.resetWorldConfiguration(e.worldId)}catch{throw new C("E_WORLD_ISOLATION","无法清理已离开文档的世界配置")}}))},records:n,editRecords:t=>a((async()=>{const a=await n(),r=a.map((e=>[e.tabId,e.documentId,e.worldId])),i=t(a)
return P(!i?.then&&a.length===r.length&&a.every(((e,t)=>e.tabId===r[t][0]&&e.documentId===r[t][1]&&e.worldId===r[t][2])),"E_WORLD_ISOLATION","受管元数据不能改变世界预算或身份"),await e.storage.session.set({[si]:a}),i}))})}({api:e}),u=o?.({worlds:l,assertHost:a,verifyTarget:f})
let p=!1
async function m(){try{const t=e.userScripts
if("function"!=typeof t?.getScripts||"function"!=typeof t.execute)throw Error()
return await t.getScripts(),t}catch{throw new C("E_USER_SCRIPTS_UNAVAILABLE","请在 chrome://extensions 中打开此扩展的「允许用户脚本」开关")}}async function f(a,r,{requireActive:i=!0,allowLoading:o=!1}={}){const[s,c]=await Promise.all([e.tabs.get(a.tabId),i?e.tabs.query({active:!0,windowId:a.expectedWindowId}):null])
P(s?.id===a.tabId&&s.windowId===a.expectedWindowId&&(!i||!0===s.active)&&!s.incognito&&s.url===a.expectedUrl&&!s.pendingUrl&&"unloaded"!==s.status&&(o||"loading"!==s.status)&&(!i||Array.isArray(c)&&1===c.length&&c[0].id===a.tabId),"E_DOCUMENT_STALE","Page changed")
const d=await e.webNavigation.getAllFrames({tabId:a.tabId}),l=d?.find((e=>0===e.frameId))
P(!(l?.documentId!==a.documentId||l.url!==a.expectedUrl||l.errorOccurred||l.documentLifecycle&&"active"!==l.documentLifecycle),"E_DOCUMENT_STALE","Document changed"),P(await e.permissions.contains({origins:[n(a.expectedUrl)]}),"E_PERMISSION","Site permission was not granted or was revoked")
const u=await t.transaction(["runs"],"readonly",(e=>e.get("runs","@slot")))
P(!(u?.currentRunId||u?.preview&&u.preview.nonce!==r),"E_OWNER","Controller/Page preview owns slot")}return Object.freeze({preview:async function(t,n){P(!p,"E_OWNER","已有页面脚本试运行正在等待浏览器回执"),p=!0
try{return await async function(t,n){const r=await a(n),o=function(e){if(e&&!Object.hasOwn(e,"withJquery")){const t=["sourceUtf8","entryFormat","lockId","target","importSourceUrl","managedUI"]
return P("object"==typeof e&&!Array.isArray(e)&&Object.keys(e).every((e=>t.includes(e)))&&["sourceUtf8","entryFormat","target"].every((t=>Object.hasOwn(e,t))),"E_SCHEMA","Unexpected page preview fields"),P("string"==typeof e.sourceUtf8&&e.sourceUtf8.trim().length>0&&(new TextEncoder).encode(e.sourceUtf8).byteLength<=pr&&ur.includes(e.entryFormat)&&(null==e.lockId||"string"==typeof e.lockId),"E_SOURCE","Invalid page script entry or source"),Object.freeze({sourceUtf8:e.sourceUtf8,entryFormat:e.entryFormat,lockId:e.lockId??null,...e.importSourceUrl?{importSourceUrl:e.importSourceUrl}:{},...e.managedUI?{managedUI:Object.freeze({...e.managedUI})}:{},target:ui(e.target),legacy:!1})}li(e,["sourceUtf8","withJquery","target"]),P("boolean"==typeof e.withJquery&&"string"==typeof e.sourceUtf8&&e.sourceUtf8.trim().length>0&&(new TextEncoder).encode(e.sourceUtf8).byteLength<=32768&&/\basync\s+function\s+main\s*\(/.test(e.sourceUtf8),"E_SOURCE","Preview requires a bounded async function main()")
const t=or(e.sourceUtf8)
return dr(t,{entryFormat:"async-main",dependenciesLocked:0===t.requires.length}),Object.freeze({sourceUtf8:e.sourceUtf8,withJquery:e.withJquery,target:ui(e.target),legacy:!0})}(t)
let p,g,I,w
await f(o.target)
const h=crypto.randomUUID(),E=await c({runtime:e.runtime,fetchImpl:s})
o.legacy&&o.withJquery&&(p=(await Mn({runtime:e.runtime,fetchImpl:s})).code),!o.legacy&&Ir(o.sourceUtf8)&&(p=(await Mn({runtime:e.runtime,fetchImpl:s})).code)
const y=!o.legacy&&gr(o.sourceUtf8)
y&&"jquery"!==y&&(w=await oi(y,{runtime:e.runtime,fetchImpl:s})),o.legacy?I=await async function({sourceUtf8:e,withJquery:t,jqueryCode:a,receiptNonce:n,builtinSource:r}={}){P("string"==typeof e&&"boolean"==typeof t&&e.trim().length>0&&(new TextEncoder).encode(e).byteLength<=32768&&/\basync\s+function\s+main\s*\(/.test(e),"E_SOURCE","Preview requires a bounded async function main()")
const i=await ri(e),o=[]
t?(P("string"==typeof a&&await ri(a)===Ln.sha256,"E_DEPENDENCY_HASH","Packaged jQuery source integrity differs"),o.push({code:a})):P(void 0===a,"E_DEPENDENCY_LOCK","Unexpected dependency bytes")
const s=t?"if (globalThis.jQuery?.fn?.jquery !== '3.7.1') throw new Error('E_DEPENDENCY_NOT_READY');\n":""
return void 0!==r&&P(r?.abi===Ea&&"string"==typeof r.code&&await ri(r.code)===r.sha256,"E_BUILTIN_HASH","内置库固定资源损坏"),o.push({code:(r?.code?r.code+"\n;\n":"")+hr(wr(s+e,"async-main",n),r,n)}),Object.freeze({sourceHash:i,world:"USER_SCRIPT",worldId:"opendesk-preview-"+i.slice(0,48)+(t?"-jq":"-plain"),js:Object.freeze(o),receiptNonce:n,...r?{builtinAbi:Ea,builtinCatalogSha256:r.catalogSha256,builtinBundleSha256:r.sha256}:{}})}({...o,jqueryCode:p,receiptNonce:h,builtinSource:E}):(g=await d.loadForExecution({sourceUtf8:o.sourceUtf8,entryFormat:o.entryFormat,lockId:o.lockId,...o.importSourceUrl?{importSourceUrl:o.importSourceUrl}:{}},n),I=await Er({...o,entries:g.entries,receiptNonce:h,builtinSource:E,jqueryCode:p,frameworkSource:w}))
const b=await m()
P(!o.managedUI||u,"E_UI_LIFECYCLE","受管预览未加载")
const v=o.managedUI?await u.inspect(o,r):null,_=await l.allocate(b,o.target)
await a(n)
const S=o.target.tabId,A=o.target.documentId
await i.reserve({nonce:h,tabId:S,documentId:A,sourceHash:I.sourceHash},n)
let O,k=!1,T=!1
try{await f(o.target,h),v?.previous&&(O=await u.retire(b,v.previous,h,{sender:n,dispatch:()=>{k=!0,T=!1},confirm:()=>{T=!0}}))
const e=v?await u.prepare(b,v,_,I.sourceHash,h,n):null
k=!0,T=!1
const t=await b.execute({target:{tabId:S,documentIds:[A]},world:I.world,worldId:_,js:I.js})
P(Array.isArray(t)&&1===t.length&&0===t[0]?.frameId&&t[0]?.documentId===A,"E_RESULT_FORMAT","Native user script returned no exact document receipt")
const a=t[0]
if(void 0!==a.error)throw new C("E_PAGE_SCRIPT_EXECUTION",a.error+"")
const r=a.result
P(r&&r.format===fr&&r.nonce===h&&"boolean"==typeof r.ok,"E_PAGE_SCRIPT_EXECUTION","脚本未返回完成回执，请查看网页控制台"),e&&await u.mark(e,"evaluated"),T=!0
const i={tabId:S,documentId:A,sourceHash:I.sourceHash,world:I.world,worldId:_,receiptNonce:h,builtinAbi:I.builtinAbi,builtinCatalogSha256:I.builtinCatalogSha256,builtinBundleSha256:I.builtinBundleSha256,...I.packagedJquerySha256?{packagedJquerySha256:I.packagedJquerySha256}:{},...I.packagedFrameworkId?{packagedFrameworkId:I.packagedFrameworkId,packagedFrameworkSha256:I.packagedFrameworkSha256}:{}}
if(!r.ok)throw Object.assign(new C("E_PAGE_SCRIPT_EXECUTION",r.error||"页面脚本执行失败"),{response:{...i,state:"preview-failed",completion:{format:r.format,nonce:r.nonce,ok:!1,error:((r.error||"")+"").slice(0,2048)}}})
await f(o.target,h)
const s=r.value
let c
try{c=void 0===s?"undefined":JSON.stringify(s)}catch{c="（返回值不可 JSON 序列化）"}return"string"!=typeof c&&(c=s+""),"classic-userscript"===o.entryFormat&&(c="经典脚本的顶层同步代码已执行；异步 IIFE、监听器和定时器不等待，也不会因预览返回而停止。"),{state:"preview-evaluated",durable:!1,registered:!1,...i,...e?{managedUI:!0,managedPreviewId:e.previewId,...O?{previousCleanup:{previewId:v.previous.previewId,...O}}:{}}:{},...o.legacy?{withJquery:o.withJquery,dependency:o.withJquery?{id:Ln.id,version:Ln.version}:null}:{entryFormat:o.entryFormat,lockId:g.lockId,manifestDigest:g.manifestDigest,dependencies:g.entries.map((({order:e,url:t,sha256:a,sourceKind:n})=>({order:e,url:t,sha256:a,sourceKind:n}))),warnings:I.warnings},resultText:c.slice(0,2048)}}catch(R){if(k&&!T)throw new C("E_EFFECT_UNKNOWN",R.message+"；原页面执行效果未知，不能自动重试")
throw R}finally{k&&!T||await i.release({nonce:h})}}(t,n)}finally{p=!1}},retire:async function(e,t){P(!p&&u,"E_OWNER","受管清理不可用或忙碌"),p=!0
try{return await u.retirePreview(e,t,{assertHost:a,verifyTarget:f,nativeAPI:m,admission:i})}finally{p=!1}},executeInstalled:async function({candidate:t,resolution:a,target:n,installation:r},o,d){P(!p&&"function"==typeof i.reserveInstalled,"E_OWNER","页面执行入口正忙")
const u=ui(n)
p=!0
let g=!1,I=!1,w=!1
const h=crypto.randomUUID()
try{P("function"==typeof d,"E_OWNER","缺少安装派发授权"),await o(),await f(u,void 0,{requireActive:!1,allowLoading:!0})
const n=await c({runtime:e.runtime,fetchImpl:s})
Ra(t.builtinIdentity,Ta(n))
const p=Ir(t.sourceUtf8)?(await Mn({runtime:e.runtime,fetchImpl:s})).code:void 0,E=gr(t.sourceUtf8),y=E&&"jquery"!==E?await oi(E,{runtime:e.runtime,fetchImpl:s}):void 0,b=await Er({sourceUtf8:t.sourceUtf8,entryFormat:t.manifest.entryFormat,entries:a.entries,importSourceUrl:t.manifest.sourceProfile.importSourceUrl,receiptNonce:h,builtinSource:n,jqueryCode:p,frameworkSource:y}),v=await m(),_=await l.allocate(v,u)
await i.reserveInstalled({nonce:h,tabId:u.tabId,documentId:u.documentId,sourceHash:b.sourceHash},r),w=!0,await f(u,h,{requireActive:!1,allowLoading:!0})
const S=await d(h,(()=>(g=!0,v.execute({target:{tabId:u.tabId,documentIds:[u.documentId]},world:"USER_SCRIPT",worldId:_,js:b.js})))),A=await S.completion
P(Array.isArray(A)&&1===A.length&&0===A[0]?.frameId&&A[0]?.documentId===u.documentId,"E_RESULT_FORMAT","缺少安装脚本的精确文档回执")
const O=A[0]
if(void 0!==O.error)throw new C("E_PAGE_SCRIPT_EXECUTION",O.error+"")
const k=O.result
let T
P(k?.format===fr&&k.nonce===h&&"boolean"==typeof k.ok,"E_PAGE_SCRIPT_EXECUTION","安装脚本缺少完成回执"),I=!0,P(k.ok,"E_PAGE_SCRIPT_EXECUTION",k.error||"安装脚本执行失败"),await f(u,h,{requireActive:!1,allowLoading:!0}),await o()
try{T=void 0===k.value?"undefined":JSON.stringify(k.value)}catch{T="（返回值不可 JSON 序列化）"}return"classic-userscript"===t.manifest.entryFormat&&(T="经典脚本同步顶层求值完成；异步 IIFE、监听器和定时器不等待，也不会因返回而停止。"),{state:"page-installed-evaluated",sourceHash:b.sourceHash,tabId:u.tabId,documentId:u.documentId,world:"USER_SCRIPT",worldId:_,receiptNonce:h,resultText:(T+"").slice(0,2048),entryFormat:t.manifest.entryFormat,builtinAbi:b.builtinAbi,builtinCatalogSha256:b.builtinCatalogSha256,builtinBundleSha256:b.builtinBundleSha256,...b.packagedJquerySha256?{packagedJquerySha256:b.packagedJquerySha256}:{},...b.packagedFrameworkId?{packagedFrameworkId:b.packagedFrameworkId,packagedFrameworkSha256:b.packagedFrameworkSha256}:{}}}catch(E){if(g&&!I)throw new C("E_EFFECT_UNKNOWN",E.message+"；本次效果未知，不自动重放")
throw g&&I&&(E.effectConfirmed=!0),E}finally{!w||g&&!I||await i.release({nonce:h}),p=!1}},cleanupWorlds:async e=>(e.removed&&await i.release({removedTabId:e.tabId}),l.cleanup(e))})}({api:e,storage:u,assertHost:I.assertHost,dependencies:E,admission:I.pagePreviewAdmission}),b=function({api:e,storage:t,assertHost:n,dependencies:r,preview:i,admission:o,session:s,clock:c={now:()=>Date.now()},loadBuiltin:d=Oa}){const l="tool:"+e.runtime.id
let u=Promise.resolve(),p=Promise.resolve()
const f=[],g=e=>f.filter((t=>Ii(e.pageRules,t))).length,I=e=>e?.enabled&&"active"===fi(e).status,w=e=>{const t=u.then(e,e)
return u=t.catch((()=>{})),t},h=e=>t.transaction([wi],"readonly",e)
async function E(e,a,r){const i=await n(e)
return P(i.namespace===l,"E_OWNER","安装属于其他扩展"),t.transaction([wi,"commandJournal"],a,(async e=>{const t=await e.get("commandJournal","host:"+i.registrationId)
return P(t?.active&&!t.revoked&&["hostDocumentId","hostInstanceId","browserSessionIncarnation","hostUrl"].every((e=>t[e]===i[e])),"E_OWNER","安装操作的工具宿主已失效"),r(e,i)}))}async function y(){try{const t=e.userScripts
return await t.getScripts(),t}catch{throw new C("E_USER_SCRIPTS_UNAVAILABLE","请开启扩展的「允许用户脚本」后重新核对安装状态")}}async function b(t){if(!0!==await e.permissions.contains({origins:t.pageRules.matches}))throw Object.assign(new C(bi,ki),{pageAccessLost:!0})}async function v(t,a){const n=await r.readStoredPageCandidate(l,t,a)
return Ra(n.candidate.builtinIdentity,Ta(await d({runtime:e.runtime}))),n}async function _(e,{available:t=!1}={}){const a=await h((t=>t.get(wi,Ti("verification",l,e.manifest.programId,e.manifest.revision))))
return P("page-verification-v1"===a?.tag&&["Verified","Available"].includes(a.status)&&Ni.every((t=>Ci(a[t],Ui(e)[t])))&&"preview-evaluated"===a.receipt?.state&&"USER_SCRIPT"===a.receipt.world&&a.receipt.sourceHash===e.manifest.sourceHash&&"string"==typeof a.receipt.documentId&&a.receiptHash===await M(a.receipt),"E_PAGE_VERIFICATION","缺少此固定 Page 版本的真实验证回执"),await Pi(e,a.receipt),P(!t||"Available"===a.status,"E_NOT_AVAILABLE","请先将验证版本设为本机可安装"),a}async function S(t,{legacy:a=!1}={}){const{candidate:n,resolution:r}=await v(t.programId,t.revision),i=await _(n,{available:!0})
Ra(t.builtinIdentity,n.builtinIdentity),P(t.tag===hi&&t.namespace===l&&t.manifestHash===n.manifestHash&&t.sourceHash===n.manifest.sourceHash&&Ci(t.pageRules,n.manifest.pageRules)&&/^[a-f0-9]{32}$/.test(t.token),"E_PAGE_INSTALLATION","安装记录不属于此固定版本"),a||fi(t)
const o=Ir(n.sourceUtf8)?(await Mn({runtime:e.runtime})).code:void 0,s=gr(n.sourceUtf8),c=s&&"jquery"!==s?await oi(s,{runtime:e.runtime}):void 0,d=await async function({candidate:e,sourceUtf8:t,authority:a,dependencyResolution:n,jqueryCode:r,frameworkSource:i}={}){ni(e&&"object"==typeof e&&"function"==typeof a?.assertAvailable,"E_AUTHORITY_REQUIRED")
const o=structuredClone(e),s=structuredClone(n),{candidateId:c,namespace:d,manifestHash:l}=o
ni("string"==typeof c&&ai.test(c)&&"string"==typeof d&&d.length>0&&d.length<=256&&ti.test(l),"E_PAGE_CANDIDATE")
const u=ei(o.manifest)
ni(await async function(e){return M(ei(e))}(u)===l,"E_MANIFEST_HASH"),await async function({manifest:e,sourceUtf8:t,dependencyResolution:a}){P("string"==typeof t&&t.trim().length>0,"E_SOURCE","页面程序源码不能为空")
const n=ei(e),r=structuredClone(a)
P(await j(t)===n.sourceHash,"E_SOURCE_HASH","页面源码已偏离冻结版本")
const{parsed:i,manifestDigest:o}=await async function(e){const t=qr(e)
return{...t,manifestDigest:await xr(t.manifest)}}({sourceUtf8:t,entryFormat:n.entryFormat,importSourceUrl:n.sourceProfile.importSourceUrl}),s=dr(i,{entryFormat:n.entryFormat,phase:"preview",dependenciesLocked:!0})
return P(n.dependencyManifestDigest===o,"E_DEPENDENCY_LOCK_STALE","页面程序依赖声明摘要不符"),function(e,t,a){P(a&&"USER_SCRIPT"===a.world&&a.manifestDigest===t&&Array.isArray(a.entries)&&a.entries.length===e.requires.length,"E_DEPENDENCY_LOCK_STALE","依赖加载结果与当前源码声明不一致"),P(e.requires.length?Zr.test(a.lockId):null===a.lockId,"E_DEPENDENCY_LOCK","依赖缺少固定锁，或无依赖源码冒用了其他锁")
for(const[n,r]of a.entries.entries())P(r?.order===n&&r.url===e.requires[n].url&&"USER_SCRIPT"===r.world&&$r.test(r.sha256),"E_DEPENDENCY_LOCK","依赖资产的顺序、来源或执行世界不一致")}(i,o,r),P(n.dependencyLockId===r.lockId,"E_DEPENDENCY_LOCK_STALE","加载的依赖版本与固定程序不一致"),Kn(i,s,n.pageRules),n}({manifest:u,sourceUtf8:t,dependencyResolution:s})
const p=await a.assertAvailable(c)
ni(p?.candidateId===c&&p.namespace===d&&p.manifestHash===l&&"Available"===p.status&&!0===p.installationEnabled&&p.runtimeKind===Jr&&p.entryFormat===u.entryFormat&&p.programId===u.programId&&p.revision===u.revision&&p.sourceHash===u.sourceHash&&p.dependencyLockId===u.dependencyLockId&&p.dependencyManifestDigest===u.dependencyManifestDigest,"E_NOT_AVAILABLE")
const m=Vn(p.approvedPageRules)
ni(H(m)===H(u.pageRules),"E_NOT_AVAILABLE")
const f=await Er({sourceUtf8:t,entryFormat:u.entryFormat,entries:s.entries,importSourceUrl:u.sourceProfile.importSourceUrl,jqueryCode:r,frameworkSource:i})
ni(f.sourceHash===u.sourceHash&&f.world===u.pageRules.world,"E_SOURCE_HASH")
const g="opendesk-page-d1-"+(await M({namespace:d,candidateId:c,manifestHash:l})).slice(0,48),I=u.pageRules
return Object.freeze({id:g,matches:I.matches,excludeMatches:I.excludeMatches,runAt:I.runAt,allFrames:I.allFrames,world:"USER_SCRIPT",worldId:g,js:f.js})}({candidate:n,sourceUtf8:n.sourceUtf8,dependencyResolution:r,jqueryCode:o,frameworkSource:c,authority:{assertAvailable:async()=>({...i,installationEnabled:!0})}})
P(!1===d.allFrames,"E_PAGE_FRAME_SCOPE","本轮正式安装只支持顶层文档；请添加 @noframes"),P("document_idle"===d.runAt,"E_PAGE_RUN_AT","正式安装仅支持 @run-at document-idle；早期时序尚未验收")
const u=Oi+(await M([l,t.programId])).slice(0,48)
P(t.nativeId===u,"E_PAGE_INSTALLATION","安装的原生注册身份已改变")
const p="__opendesk_page_boot_"+t.token,m={protocol:Si,nativeId:u,token:t.token}
return{candidate:n,resolution:r,marker:p,script:{id:u,matches:d.matches,excludeMatches:d.excludeMatches,runAt:d.runAt,allFrames:!1,world:"USER_SCRIPT",worldId:Ai,js:[{code:"const "+p+" = "+JSON.stringify(t.token)+";\nchrome.runtime.sendMessage("+JSON.stringify(m)+').catch(error=>console.error("[OpenDesk Page bootstrap]",error));'}]}}}function A(e,t){return e&&["id","matches","excludeMatches","runAt","allFrames","world","worldId","js"].every((a=>Ci(e[a]??("excludeMatches"===a?[]:null),t[a])))}async function O(a){let n="blocked",r=null
try{const t=await y(),i=await t.getScripts({ids:[a.nativeId]})
if(I(a)){const r=g(a),o=await S(a)
P(await e.permissions.contains({origins:o.script.matches}),bi,"原网站权限已撤销"),await t.configureWorld({worldId:Ai,csp:mr,messaging:!0}),P(g(a)===r,bi,ki),A(i[0],o.script)||(i.length&&await t.unregister({ids:[a.nativeId]}),await t.register([o.script]))
const s=await t.getScripts({ids:[a.nativeId]})
P(g(a)===r,bi,ki),P(1===s.length&&A(s[0],o.script),vi,"原生注册内容尚未确认"),n="registered"}else i.length&&await t.unregister({ids:[a.nativeId]}),P(0===(await t.getScripts({ids:[a.nativeId]})).length,vi,"原生注册撤销尚未确认"),n=a.enabled?"blocked":"disabled",r=a.enabled?a.error??{code:bi,message:ki}:null}catch(m){r={code:m.code||vi,message:(m.message||m)+""}
try{const e=await y()
await e.unregister({ids:[a.nativeId]})}catch{}}await t.transaction([wi],yi,(async e=>{const t=Ti(Ei,l,a.programId),i=await e.get(wi,t)
if(i?.token===a.token&&i.enabled===a.enabled){const a="active"===i.authorization?.status&&[bi,"E_USER_SCRIPTS_UNAVAILABLE","E_PAGE_AUTHORIZATION","E_PAGE_ENVIRONMENT"].includes(r?.code)
await e.put(wi,{...i,nativeState:n,error:r,...a?{token:crypto.randomUUID().replaceAll("-",""),authorization:{...i.authorization,generation:i.authorization.generation+1,status:"suspended"}}:{}},t)}}))}async function k(a){if(a.authorization)return a
let n,r=a.error
try{await S(a,{legacy:!0})
const t=await e.permissions.contains({origins:a.pageRules.matches}),i=a.enabled?t&&"registered"===a.nativeState&&!a.error?"active":"suspended":"disabled"
n={tag:"page-install-authorization-v1",installationId:crypto.randomUUID(),generation:1,status:i,scope:pi(a.pageRules),approvedAt:a.installedAt},"suspended"===i&&(r={code:bi,message:ki})}catch(o){r={code:o.code||"E_PAGE_AUTHORIZATION",message:"旧安装无法验证，请重新核对并安装固定版本"}}const i={...a,authorization:n,nativeState:"active"===n?.status?a.nativeState:"blocked",error:r,..."active"===n?.status?{}:{token:crypto.randomUUID().replaceAll("-","")}}
return await t.transaction([wi],yi,(e=>e.put(wi,i,Ti(Ei,l,a.programId)))),i}return Object.freeze({verifyPageCandidate:async function(e,t){Ri(e,["programId","revision","target"]),await E(t,"readonly",(()=>{}))
const{candidate:a}=await v(e.programId,e.revision),n=a.manifest
if(await h((e=>e.get(wi,Ti("verification",l,n.programId,n.revision))))){const e=await _(a)
return{stage:e.status,manifestHash:a.manifestHash,receipt:e.receipt}}const r=await i.preview({sourceUtf8:a.sourceUtf8,entryFormat:n.entryFormat,importSourceUrl:n.sourceProfile.importSourceUrl,lockId:n.dependencyLockId,target:e.target},t)
P("preview-evaluated"===r.state&&r.sourceHash===n.sourceHash&&"USER_SCRIPT"===r.world,"E_PAGE_VERIFICATION","Page 类型验证身份不一致"),await Pi(a,r)
const o={tag:"page-verification-v1",...Ui(a),status:"Verified",receipt:r,receiptHash:await M(r),verifiedAt:c.now()}
return E(t,yi,(async e=>{const t=Ti("verification",l,n.programId,n.revision),i=await e.get(wi,t)
return i?(P(Ni.every((e=>Ci(i[e],o[e]))),_i,"验证身份已改变"),{stage:i.status,manifestHash:a.manifestHash}):(await e.put(wi,o,t),{stage:"Verified",manifestHash:a.manifestHash,receipt:r})}))},makePageAvailable:async function(e,t){Ri(e,["programId","revision","manifestHash"])
const{candidate:a}=await v(e.programId,e.revision),n=await _(a)
return P(a.manifestHash===e.manifestHash,_i,"冻结版本已改变"),E(t,yi,(async t=>{const r=Ti("verification",l,e.programId,e.revision),i=await t.get(wi,r)
return P(i?.receiptHash===n.receiptHash,_i,"验证版本已改变"),await t.put(wi,{...i,status:"Available"},r),{stage:"Available",manifestHash:a.manifestHash}}))},installPageProgram:async function(t,a){return t=structuredClone(t),Ri(t,["programId","revision","manifestHash","expectedInstalledManifestHash","expectedGeneration"],["programId","revision","manifestHash","expectedInstalledManifestHash"]),w((async()=>{const{candidate:n}=await v(t.programId,t.revision)
await _(n,{available:!0}),P(n.manifestHash===t.manifestHash,_i,"安装必须引用固定版本")
const r=await h((e=>e.get(wi,Ti(Ei,l,t.programId))))
P((r?.manifestHash??null)===t.expectedInstalledManifestHash&&(!r||t.expectedGeneration===(r.authorization?.generation??null)),_i,"安装授权在确认期间改变；请刷新后核对"),r?.authorization&&fi(r)
const i=pi(n.manifest.pageRules),o=mi(r?.authorization?.scope,i),s={tag:hi,namespace:l,programId:t.programId,revision:t.revision,manifestHash:n.manifestHash,sourceHash:n.manifest.sourceHash,builtinIdentity:n.builtinIdentity,pageRules:n.manifest.pageRules,enabled:!0,token:crypto.randomUUID().replaceAll("-",""),nativeId:Oi+(await M([l,t.programId])).slice(0,48),nativeState:"pending",error:null,installedAt:r?.installedAt??c.now(),authorization:{tag:"page-install-authorization-v1",installationId:r?.authorization?.installationId??crypto.randomUUID(),generation:(r?.authorization?.generation??0)+1,status:"active",scope:i,approvedAt:o.requiresConfirmation?c.now():r.authorization.approvedAt}},d=g(s),u=await S(s)
return P(await e.permissions.contains({origins:u.script.matches}),bi,"安装的网站范围尚未获得授权"),await E(a,yi,(async e=>{const a=Ti(Ei,l,s.programId),n=await e.get(wi,a)
P((n?.manifestHash??null)===t.expectedInstalledManifestHash&&n?.token===r?.token,_i,"已安装版本在确认期间改变"),P(g(s)===d,bi,ki),await e.put(wi,s,a)})),await O(s),Di(await h((e=>e.get(wi,Ti(Ei,l,s.programId)))))}))},setInstalledPageEnabled:async function(t,a){return t=structuredClone(t),Ri(t,["programId","manifestHash","enabled","expectedGeneration"]),P("boolean"==typeof t.enabled,"E_SCHEMA","启用状态必须是布尔值"),w((async()=>{let n
const r=await h((e=>e.get(wi,Ti(Ei,l,t.programId))))
P(r?.tag===hi&&r.manifestHash===t.manifestHash&&(r.authorization?.generation??null)===t.expectedGeneration,_i,"安装授权已改变")
const i=g(r)
return t.enabled&&(await S(r),P(await e.permissions.contains({origins:r.pageRules.matches}),bi,ki)),await E(a,yi,(async e=>{const a=Ti(Ei,l,t.programId),o=await e.get(wi,a)
P(o?.tag===hi&&o.manifestHash===t.manifestHash&&o.token===r.token,_i,"安装身份已改变"),t.enabled&&P(g(o)===i,bi,ki)
const s=fi(o)
n={...o,enabled:t.enabled,token:crypto.randomUUID().replaceAll("-",""),nativeState:"pending",error:null,authorization:{...s,generation:s.generation+1,status:t.enabled?"active":"disabled"}},await e.put(wi,n,a)})),await O(n),Di(await h((e=>e.get(wi,Ti(Ei,l,n.programId)))))}))},listPagePrograms:async function(e,t){return Ri(e,[]),E(t,"readonly",(async e=>{const t=await e.all(wi),a=t.filter((e=>e?.tag===hi&&e.namespace===l))
return{catalog:t.filter((e=>"page-candidate-v1"===e?.tag&&e.namespace===l)).map((e=>{const n=t.find((t=>"page-verification-v1"===t?.tag&&t.namespace===l&&t.candidateId===e.candidateId&&t.manifestHash===e.manifestHash))
return{candidateId:e.candidateId,programId:e.manifest.programId,revision:e.manifest.revision,manifestHash:e.manifestHash,sourceHash:e.manifest.sourceHash,pageRules:e.manifest.pageRules,stage:n?.status??"Candidate",installed:Di(a.find((t=>t.programId===e.manifest.programId))),authorizationChange:mi(a.find((t=>t.programId===e.manifest.programId))?.authorization?.scope,pi(e.manifest.pageRules))}})),installed:a.map(Di)}}))},recoverExecutions:async function(){const a=await h((async e=>(await e.all(wi)).filter((e=>"page-execution-v1"===e?.tag&&e.namespace===l&&["prepared","dispatched","outcome-unknown"].includes(e.state)))))
for(const n of a){let a=!1
try{const t=await e.webNavigation.getFrame({documentId:n.documentId})
a=null==t}catch{}const r=await t.transaction([wi],yi,(async e=>{const t=await e.get(wi,n.executionKey)
if(!t||!["prepared","dispatched","outcome-unknown"].includes(t.state))return null
const r={...t,state:"outcome-unknown",error:{code:vi,message:"执行期间后台中断；原效果未知，不自动重放"},result:null,finishedAt:t.finishedAt??c.now(),contextGone:t.contextGone||a}
await e.put(wi,r,n.executionKey)
const i=Ti(Ei,l,n.programId),o=await e.get(wi,i)
return o?.token===n.installationToken&&(!o.lastExecution||o.lastExecution.createdAt<=n.createdAt)&&await e.put(wi,{...o,lastExecution:r},i),r}))
r?.receiptNonce&&a&&await o.release({nonce:r.receiptNonce})}},reconcile:async function(){return w((async()=>{const e=await h((async e=>(await e.all(wi)).filter((e=>e?.tag===hi&&e.namespace===l))))
if(e.length)for(const t of e)await O(await k(t))}))},revokePermissions:function(e){const a=structuredClone(e)
return f.push(a),w((async()=>{const e=await t.transaction([wi],yi,(async e=>{const t=(await e.all(wi)).filter((e=>e?.tag===hi&&e.namespace===l&&"active"===e.authorization?.status&&Ii(e.pageRules,a)))
for(const a of t)a.token=crypto.randomUUID().replaceAll("-",""),a.authorization={...a.authorization,generation:a.authorization.generation+1,status:"suspended"},a.nativeState="blocked",a.error={code:bi,message:"访问已撤销，请主动恢复访问"},await e.put(wi,a,Ti(Ei,l,a.programId))
return t}))
for(const t of e)await O(t)}))},handleBoot:function(n,r){const o=p.then((()=>async function(n,r){Ri(n,["protocol","nativeId","token"]),P(n.protocol===Si&&r?.id===e.runtime.id&&0===r.frameId&&"string"==typeof r.documentId&&Number.isSafeInteger(r.tab?.id)&&!r.tab.incognito,"E_OWNER","仅真实顶层 USER_SCRIPT 引导消息可触发安装脚本")
const o=await h((async e=>(await e.all(wi)).find((e=>e?.tag===hi&&e.namespace===l&&e.nativeId===n.nativeId&&e.token===n.token&&e.enabled))))
P(o,bi,"页面脚本未安装、已停用或引导身份已过期"),P(I(o),bi,ki)
const d=g(o)
await b(o)
const u=await S(o),p=await y(),f=await e.tabs.get(r.tab.id),E=await e.webNavigation.getAllFrames({tabId:r.tab.id}),v=E?.find((e=>0===e.frameId&&e.documentId===r.documentId))
var O,k
P(v&&!v.errorOccurred&&(!v.documentLifecycle||"active"===v.documentLifecycle)&&f.url===v.url&&r.url===v.url&&!f.pendingUrl&&!f.incognito,"E_DOCUMENT_STALE","自动执行文档已经改变"),a(v.url),P((O=o.pageRules,k=v.url,function(e){const t=Vn(e),a=e=>{const[,t,a,n]=/^(https?|\*):\/\/([^/]+)(\/.*)$/.exec(e),[,r,i]=/^(\[[^\]]+\]|[^:]+)(?::(\*|[0-9]+))?$/.exec(a),o=r.toLowerCase(),s=o.startsWith("*."),c=s?o.slice(2):o
return e=>{const a=e.port||("https:"===e.protocol?"443":"80")
return("*"===t||e.protocol===t+":")&&("*"===o||(s?e.hostname===c||e.hostname.endsWith("."+c):e.hostname===c))&&(void 0===i||"*"===i||Number(i)===Number(a))&&(e=>{let t=0,a=0,r=-1,i=0
for(;t<e.length;)if(n[a]===e[t])t++,a++
else if("*"===n[a])r=a++,i=t
else{if(!(r>=0))return!1
a=r+1,t=++i}for(;"*"===n[a];)a++
return a===n.length})(e.pathname+e.search)}},n=t.matches.map(a),r=t.excludeMatches.map(a)
return e=>{let t
try{t=new URL(e)}catch{return!1}return["https:","http:"].includes(t.protocol)&&!t.username&&!t.password&&n.some((e=>e(t)))&&!r.some((e=>e(t)))}}(O)(k)),bi,"当前网页 URL 已离开安装范围或进入排除路径")
const T=await p.getScripts({ids:[o.nativeId]})
P(1===T.length&&A(T[0],u.script),bi,"此安装的原生引导已经改变")
const R=await p.execute({target:{tabId:f.id,documentIds:[v.documentId]},world:"USER_SCRIPT",worldId:Ai,js:[{code:"typeof "+u.marker+' === "string" ? '+u.marker+" : null"}]})
P(1===R.length&&0===R[0]?.frameId&&R[0]?.documentId===v.documentId&&void 0===R[0].error&&R[0].result===o.token,bi,"缺少匹配文档的真实安装引导标记")
const N=Ti("execution",l,o.manifestHash,v.documentId),U=crypto.randomUUID(),D=await t.transaction([wi],yi,(async e=>{const t=await e.get(wi,Ti(Ei,l,o.programId))
return P(t&&I(t)&&t.token===o.token&&g(o)===d,bi,ki),!(await e.get(wi,N))&&(P((await e.all(wi)).filter((e=>"page-execution-v1"===e?.tag)).length<4096,"E_QUOTA","页面执行回执已达上限；保留原始证据后再维护"),await e.put(wi,{tag:"page-execution-v1",namespace:l,receiptId:U,programId:o.programId,revision:o.revision,manifestHash:o.manifestHash,sourceHash:o.sourceHash,installationToken:o.token,installationId:o.authorization.installationId,grantGeneration:o.authorization.generation,executionKey:N,browserSessionIncarnation:s,tabId:f.id,documentId:v.documentId,state:"prepared",createdAt:c.now()},N),!0)}))
P(D,"E_REQUEST_CONFLICT","此固定版本已在本 document 准入；不会自动重放")
const x=async()=>{const e=await h((e=>e.get(wi,Ti(Ei,l,o.programId))))
P(e&&I(e)&&e.token===o.token&&e.manifestHash===o.manifestHash&&g(o)===d,bi,ki),await b(o),await _(u.candidate,{available:!0})
const t=await h((e=>e.get(wi,Ti(Ei,l,o.programId))))
P(t&&I(t)&&t.token===o.token&&g(o)===d,bi,ki)},L=(e,a)=>w((async()=>{await x(),await t.transaction([wi,"runs"],yi,(async t=>{const a=await t.get(wi,Ti(Ei,l,o.programId)),n=await t.get(wi,N)
P(a&&I(a)&&a.token===o.token&&a.manifestHash===o.manifestHash&&g(o)===d&&"prepared"===n?.state&&n.receiptNonce===e&&n.browserSessionIncarnation===s,bi,ki)
const r=await t.get("runs","@slot")
P(!r?.currentRunId&&r?.preview?.nonce===e&&r.preview.executionKey===N&&r.preview.browserSessionIncarnation===s,"E_OWNER","最终派发前共享执行入口已经改变"),await t.put(wi,{...n,state:"dispatched",dispatchedAt:c.now()},N)})),P(g(o)===d,bi,ki)
const n=Promise.resolve(a())
return n.catch((()=>{})),{completion:n}}))
let H,M
try{H=await i.executeInstalled({...u,target:{tabId:f.id,frameId:0,documentId:v.documentId,expectedUrl:v.url,expectedWindowId:f.windowId},installation:{...o,executionKey:N}},x,L)}catch(m){M={code:m.code||vi,message:(m.message||m)+"",...m.effectConfirmed?{effectConfirmed:!0}:{},...m.pageAccessLost?{pageAccessLost:!0}:{}}}if(await t.transaction([wi],yi,(async e=>{const t=Ti(Ei,l,o.programId),a=await e.get(wi,t)
M||a&&I(a)&&a.token===o.token&&g(o)===d||(M={code:bi,message:"原网页执行已完成，但安装授权已改变；不交付旧授权的成功结果",effectConfirmed:!0})
const n={...await e.get(wi,N),state:M?M.code===vi?"outcome-unknown":"failed":"completed",result:M?null:H??null,error:M??null,effectConfirmed:!!H||!0===M?.effectConfirmed,finishedAt:c.now()}
await e.put(wi,n,N),a?.token===o.token&&await e.put(wi,{...a,lastExecution:n},t)})),M)throw Object.assign(new C(M.code,M.message),M.pageAccessLost?{pageAccessLost:!0}:{})
return{receiptId:U,state:"completed"}}(n,r))).catch((async e=>{throw"E_USER_SCRIPTS_UNAVAILABLE"!==e.code&&"E_PAGE_ENVIRONMENT"!==e.code&&!0!==e.pageAccessLost||await w((async()=>{const a=await t.transaction([wi],yi,(async t=>{const a=(await t.all(wi)).find((e=>e?.tag===hi&&e.namespace===l&&e.nativeId===n.nativeId&&e.token===n.token&&"active"===e.authorization?.status))
if(!a)return null
const r={...a,token:crypto.randomUUID().replaceAll("-",""),nativeState:"blocked",error:{code:e.code,message:"E_PAGE_ENVIRONMENT"===e.code?e.message:ki},authorization:{...a.authorization,generation:a.authorization.generation+1,status:"suspended"}}
return await t.put(wi,r,Ti(Ei,l,a.programId)),r}))
a&&await O(a)})),e}))
return p=o.catch((()=>{})),o}})}({api:e,storage:u,assertHost:I.assertHost,dependencies:E,preview:y,admission:I.pagePreviewAdmission,session:l,clock:i}),v=function({sdk:e,authority:t}){return async(a,n)=>{try{return await e.request(a,n)}catch(r){if("E_EFFECT_UNKNOWN"===r?.code)try{const e=await t.lookupSdkInvocation(a,n)
e&&(r.invocation=e.invocation)}catch{}throw r}}}({sdk:h,authority:I})
await I.recover(),d||w.attach(),await w.reconcilePending()
const A=c?.attach({storage:u,api:e,session:l,authority:I,downloads:w,entitlement:f,emitToHost:g,background:e=>Promise.resolve(e).catch((e=>console.error(`[foundation ${e.code||"E_EFFECT_UNKNOWN"}] ${e.message}`)))})
await Fi({api:e,storage:u,session:l,authority:I,consumer:A}),await(A?.reconcileRetirements()),await b.recoverExecutions(),await b.reconcile()
const O={...Hi(I,["commitControllerScript","getControllerScript","listControllerScripts","startControllerRun","controllerOperation","stopControllerRun","finishControllerRun","snapshotControllerRun","retireControllerTarget","tombstoneControllerScript","garbageCollectControllerScript","importTaskPackage","listTaskCatalog","getTaskCandidate","verifyTaskCandidate","makeTaskAvailable","installTask","setInstalledTaskEnabled","uninstallTask","resolveInstalledTask","grantSdk","inspectSdkGrant","revokeSdkGrant","registerHost"]),...Hi(E,["importPageCandidate","getPageCandidate"]),...Hi(b,["listPagePrograms","verifyPageCandidate","makePageAvailable","installPageProgram","setInstalledPageEnabled"]),...Hi(w,["prepareArtifact","prepareAttempt","retirePreparedArtifact","dispatchDownload","reconcileDownload","recordResourceRelease"]),previewPageScript:(e,t)=>y.preview(e,t),retirePagePreview:(e,t)=>y.retire(e,t),inspectPageDependencies:(e,t)=>E.inspect(e,t),preparePageDependencies:(e,t)=>E.prepare(e,t),approvePageDependencies:(e,t)=>E.approve(e,t),installSdk:Mi({authority:I,api:e}),registerHost:async(t,a)=>(await Fi({api:e,storage:u,session:l,authority:I,consumer:A}),I.registerHost(t,a)),async readArtifact(e,t){const{artifact:a,bytes:n}=await w.readArtifact(e,t),r=[]
for(let i=0;i<n.length;i+=N.maxRawFrameBytes)r.push(fe(n.slice(i,i+N.maxRawFrameBytes)))
return r.length||r.push(fe(new Uint8Array)),{artifact:a,blocks:r}},async getGestureTicket(){const{foundationGestureTicketId:t}=await e.storage.session.get("foundationGestureTicketId")
return{gestureTicketId:t??null}},...A?.routes}
return{handle:async function(t,a){if(P(t?.protocol===R,"E_VERSION","Unknown foundation protocol"),"SDK_HELLO"===t.type)return h.hello(t.payload,a)
if("SDK_REQUEST"===t.type)return v(t.payload,a)
if(H(t.payload??{},{maxDepth:["startControllerRun","controllerOperation","finishControllerRun"].includes(t.type)?48:12}),"BOOTSTRAP_READY"===t.type)return A?A.bootstrapReady(t.payload,a):p()
if("TARGET_READY"===t.type)return A?A.agentReady(t.payload,a):p()
if(["AGENT_READY","PAGE_DATA","PAGE_END","PAGE_EFFECT","PAGE_ERROR","SOURCE_RESULT","SOURCE_PREVIEW_DATA","SOURCE_PREVIEW_END","SOURCE_ERROR"].includes(t.type))return A?A.handleAgentMessage(t,a):p()
a=await o(e,a),P(r(e,a),"E_OWNER","Only actual packaged tool documents may invoke foundation services"),!A&&Li.has(t.type)&&p()
const n=Object.hasOwn(O,t.type)?O[t.type]:void 0
P(n,"E_CAPABILITY","Unknown or unavailable foundation operation"),"registerHost"!==t.type&&await((e,t)=>I.assertHost(t,e.registrationId))(t,a)
const i=t.payload??{}
return i.identity&&p(),n(i,a)},issueGestureTicket:async function(t){P(t&&!t.incognito&&Number.isInteger(t.id),"E_PERMISSION","Action source tab unavailable")
const n=a(t.url),r=D()
return await u.transaction(["commandJournal"],"readwrite",(e=>e.put("commandJournal",{tag:"gesture-ticket",gestureTicketId:r,sourceTabId:t.id,sourceUrl:n.href,origin:n.origin,gestureAt:new Date(i.now()).toISOString(),browserSessionIncarnation:l,consumed:!1},"gesture:"+r))),await e.storage.session.set({foundationGestureTicketId:r}),r},disconnectHost:async function(t,a){await ji({api:e,authority:I,consumer:A,downloads:w},t,a)},recoverHostTab:t=>async function({api:e,storage:t,session:a,authority:n,consumer:r,downloads:i},o){if(!Number.isSafeInteger(o)||"function"!=typeof e.runtime.getContexts)return[]
const s=await t.transaction(["commandJournal"],"readonly",(async e=>(await e.all("commandJournal")).filter((e=>"host"===e?.tag&&e.active&&e.hostTabId===o&&e.browserSessionIncarnation===a)))),c=[]
for(const d of s){const t=await qi({api:e},d.hostDocumentId)
if("live"===t){c.push({registrationId:d.registrationId,state:"live"})
continue}if("unknown"===t){c.push({registrationId:d.registrationId,state:"unknown"})
continue}const a=await ji({api:e,authority:n,consumer:r,downloads:i},d.registrationId,d.hostDocumentId)
c.push({registrationId:d.registrationId,state:a?"retired":"live"})}return c}({api:e,storage:u,session:l,authority:I,consumer:A,downloads:w},t),handleInstalledPageBoot:b.handleBoot,reconcileInstalledPages:b.reconcile,revokeInstalledPagePermissions:b.revokePermissions,cleanupPagePreviewWorlds:y.cleanupWorlds,authority:I,storage:u,pagePort:A?.pagePort,targets:A?.targets,downloads:w,entitlement:f,session:l,emitToHost:g,sdk:h}}({api:chrome,ports:d,downloadEventsAttached:!0})
let u
function p(e,t){l.then((a=>Promise.all([a.authority.revokeSdkGrants("navigation"===e&&0===t.frameId?{tabId:t.tabId,reason:e}:{...t,documentId:"navigation"===e?void 0:t.documentId,reason:e}),a.authority.invalidateControllerTarget("permission-removed"===e?{permissionRemoved:!0,origins:t.origins||[]}:"tab-removed"===e?{tabId:t.tabId,removed:!0}:{tabId:t.tabId,frameId:t.frameId||0,documentId:t.documentId})]))).catch((e=>console.error("SDK lifecycle",e)))}!function(e,t){const a=e=>a=>{t.then((t=>t.downloads[e](a))).catch((e=>console.error(`[download event ${e?.code||"E_EFFECT_UNKNOWN"}] ${e?.message??e+""}`)))},n=a("handleCreated"),r=a("handleChanged")
e.downloads.onCreated.addListener(n),e.downloads.onChanged.addListener(r)}(chrome,l),l.then((e=>{u=e})).catch((()=>{})),l.catch((e=>console.error("foundation startup",e))),i?.start((async()=>{if(s||i.nativePending)return!1
const e=await l,t=await chrome.storage.local.get("opendesk.native-agent.ledger.v1")
return!Object.values(t["opendesk.native-agent.ledger.v1"]||{}).some((e=>"OUTCOME_UNKNOWN"===e.state))&&e.storage.transaction(["runs","commandJournal"],"readonly",(async e=>{const t=await e.get("runs","@slot")
return!t?.currentRunId&&!t?.preview&&!(await e.all("commandJournal")).some((e=>["dispatched","remove-dispatched","effect_unknown","OUTCOME_UNKNOWN","outcome-unknown"].includes(e.state)))}))})),chrome.webNavigation.onCommitted.addListener((e=>{p("navigation",{tabId:e.tabId,frameId:e.frameId,documentId:e.documentId}),0===e.frameId&&l.then((t=>t.cleanupPagePreviewWorlds({tabId:e.tabId,documentId:e.documentId}))).catch((e=>console.error(`[page preview cleanup ${e.code||"E_WORLD_ISOLATION"}] ${e.message}`)))})),chrome.permissions.onRemoved.addListener((e=>{p("permission-removed",{origins:e.origins,permissions:e.permissions}),(u?u.revokeInstalledPagePermissions(e):l.then((t=>t.revokeInstalledPagePermissions(e)))).catch((e=>console.error("Page permission revocation",e)))})),chrome.permissions.onAdded?.addListener((()=>{l.then((e=>e.reconcileInstalledPages())).catch((e=>console.error("Page registration reconciliation",e)))})),chrome.runtime.onInstalled?.addListener((e=>{"update"===e.reason&&l.then((e=>e.reconcileInstalledPages())).catch((e=>console.error("Page update reconciliation",e)))})),chrome.runtime.onUserScriptMessage?.addListener(((e,t,a)=>e?.protocol===Si&&(i?.held?(a({ok:!1,error:{code:"E_DEV_RELOADING",message:"开发更新正在核对空闲宿主；本次自动执行未派发"}}),!1):(s++,l.then((a=>a.handleInstalledPageBoot(e,t))).then((e=>a({ok:!0,data:e})),(e=>a({ok:!1,error:U(e)}))).finally((()=>s--)),!0)))),chrome.action.onClicked.addListener((e=>{const t=e&&!e.incognito&&e.url&&/^https?:/.test(e.url)?{tabId:e.id,origin:a(e.url).origin}:null
chrome.storage.session.set({environmentSource:t}).then((async()=>{if(t)try{await(await l).issueGestureTicket(e)}catch(a){console.error("foundation action",a)}})).catch((e=>console.error(e.message)))})),chrome.tabs.onRemoved.addListener((e=>{c.forgetTab(e),p("tab-removed",{tabId:e}),l.then((t=>t.recoverHostTab(e))).catch((e=>console.error(`[foundation host tab ${e.code||"E_OWNER"}] ${e.message}`))),l.then((t=>t.cleanupPagePreviewWorlds({tabId:e,removed:!0}))).catch((e=>console.error(`[page preview cleanup ${e.code||"E_WORLD_ISOLATION"}] ${e.message}`)))})),chrome.tabs.onUpdated.addListener(((e,t)=>{"loading"===t.status&&c.forgetTab(e)})),chrome.runtime.onMessage.addListener(((a,n,d)=>a?.protocol===R?i?.held?(d({ok:!1,error:{code:"E_DEV_RELOADING",message:"开发更新正在核对空闲宿主；请求未执行，请等待更新完成"}}),!1):(s++,l.then((e=>e.handle(a,n))).then((e=>d({ok:!0,data:e})),(e=>d({ok:!1,error:U(e)}))).finally((()=>s--)),!0):a?.protocol===e&&(async function(){if("AGENT_READY"===a.type)return c.rememberReady(a,n)
if(n=await o(chrome,n),!r(chrome,n))throw new t("E_TARGET","仅包内工具窗口可调用环境检查")
switch(a.type){case"CREATE_HEALTH_TARGET":return c.createTarget(a.url)
case"CHECK_HEALTH":return c.ping(a.target)
case"CHECK_SOURCE":{const{environmentSource:e}=await chrome.storage.session.get("environmentSource")
if(!e)throw new t("E_TARGET","请从 HTTP(S) 原页面点击扩展入口")
return c.bind(e.tabId,e.origin)}default:throw new t("E_CAPABILITY","环境阶段未实现该操作")}}().then((e=>d({ok:!0,data:e})),(e=>d({ok:!1,error:{code:e.code||"E_TARGET",message:e.message||"环境检查失败"}}))),!0))),chrome.runtime.onConnect.addListener((e=>{if(e.name!==R)return
const a=o(chrome,e.sender)
let n
a.catch((()=>e.disconnect()))
let r,i=!1
e.onMessage.addListener((o=>{"bind-host"===o?.type&&"string"==typeof o.registrationId&&l.then((async s=>{const c=await a
n=c.documentId
const l=await s.authority.assertHost(c,o.registrationId)
if(i)return s.disconnectHost(l.registrationId,n)
const u=d.get(n)
if(u&&u!==e)throw new t("E_OWNER","宿主端口已绑定")
if(r&&r!==l.registrationId)throw new t("E_OWNER","端口不能替换宿主身份")
r=l.registrationId,e.registrationId=r,d.set(n,e),e.postMessage({type:"host-bound",registrationId:r})})).catch((t=>{console.error(`[foundation port ${t.code||"E_OWNER"}] ${t.message}`),i||e.disconnect()}))})),e.onDisconnect.addListener((()=>{i=!0,d.get(n)===e&&(d.delete(n),r&&l.then((e=>e.disconnectHost(r,n))).catch((e=>console.error(`[foundation disconnect ${e.code||"E_OWNER"}] ${e.message}`))))}))}))}({development:null}),Wi instanceof Promise&&console.warn("The background's main() function return a promise, but it must be synchronous")}catch(zi){throw zi}return Wi}()
